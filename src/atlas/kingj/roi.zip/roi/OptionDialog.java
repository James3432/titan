package atlas.kingj.roi;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.text.DecimalFormat;

import javax.imageio.ImageIO;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import atlas.kingj.roi.Machine.Model;

import javax.swing.border.BevelBorder;
import javax.swing.border.EtchedBorder;

public class OptionDialog extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public JButton btnOk;
	private Production p;
	public JPanel pnlAdvanced;
	public JLabel label;
	public JLabel label_1;
	public JLabel label_2;
	public JTextField txtAccel;
	public JTextField txtDecel;
	public JTextField txtSpeedClamp;
	public JLabel label_3;
	public JTextField txtSyncDiam;
	public JLabel label_4;
	public JTextField txtAccelDelta;
	public JButton btnCancel;
	public JPanel pnlOptions;
	public JPanel pnlBasic;
	public JLabel lblOther_1;
	public JTextField txtFileName;
	public JTabbedPane tabs;
	public JPanel pnlViews;
	public JPanel pnlCharts;
	public JPanel pnlTimings;
	public JComboBox cmbMachineType;
	public JLabel lblMachineType;
	public JTextField txtSet1;
	public JTextField txtLoad1;
	public JTextField txtDiam1;
	public JTextField txtAlign1;
	public JTextField txtPos1;
	public JTextField txtSplice1;
	public JTextField txtCut1;
	public JTextField txtTapet1;
	public JTextField txtTapec1;
	public JTextField txtLoadr1;
	public JTextField txtUnloadr1;
	public JTextField txtAlignr1;
	public JLabel lblStandard;
	public JLabel lblWithOptions;
	public JTextField txtSet2;
	public JTextField txtLoad2;
	public JTextField txtDiam2;
	public JTextField txtAlign2;
	public JTextField txtPos2;
	public JTextField txtSplice2;
	public JTextField txtCut2;
	public JTextField txtTapet2;
	public JTextField txtTapec2;
	public JTextField txtLoadr2;
	public JTextField txtUnloadr2;
	public JTextField txtAlignr2;
	public JLabel lblConfigureMachine;
	public JLabel lblLoadUnwind;
	public JLabel lblAlignUnwind;
	public JLabel lblPositionKnives;
	public JLabel lblSpliceRoll;
	public JLabel lblCutRewind;
	public JLabel lblTapeRewindTail;
	public JLabel lblTapeRewindCore;
	public JLabel lblLoadRewind;
	public JLabel lblUnloadRewind;
	public JLabel lblAlignRewind;
	public JLabel lbls;
	public JLabel label_7;
	public JLabel label_8;
	public JLabel label_10;
	public JLabel label_11;
	public JLabel label_12;
	public JLabel label_13;
	public JLabel label_14;
	public JLabel label_15;
	public JLabel label_16;
	public JLabel label_17;
	public JLabel label_18;
	public JLabel label_19;
	public JLabel label_20;
	public JLabel label_21;
	public JLabel label_22;
	public JLabel label_23;
	public JLabel label_24;
	public JLabel label_25;
	public JLabel label_26;
	public JLabel label_27;
	public JLabel label_28;
	public JLabel label_29;
	public JLabel label_30;
	
	private JTextField[] TimingsBoxes1;
	private JTextField[] TimingsBoxes2;
	public JLabel lblChangeRewindDiam;
	public JLabel lblOptionsNotYet;
	public JPanel pnlLock;
	public JLabel lblLock;
	public JLabel lblM;
	public JLabel lblMm;
	public JLabel lblS;
	public JLabel lblMmins_1;
	public JLabel lblMmins;
	public JCheckBox chckbxSaveSettings;
	public JButton btnUnlock;
	public JSlider slide1;
	public JSlider slide2;
	public JSlider slide3;
	public JLabel lblPc3;
	public JLabel lblPc2;
	public JLabel lblPc1;
	public JLabel lblGlobalAdjustment;
	public JLabel lblCustomMachines;
	public JLabel lblTitanMachines;
	public JLabel lblAdvancedOptionsPlease;
	public JLabel lblAdv2;
	public JLabel lblAdv3;
	public JLabel lblResetOptions;
	public JButton btnResetAdvancedOptions;
	public JButton btnResetManualTimings;
	public JComboBox cmbResetManual;
	public JButton btnResetAutoTimings;
	public JComboBox cmbResetAuto;
	public JButton btnResetEfficiencySliders;
	public JLabel lblNoteResetsTake;
	public JLabel lblBeReverted;
	public JCheckBox chckbxSaveSchedule;
	public JButton btnResetAllSettings;
	
	private Machine m;

	/**
	 * Create the dialog.
	 */
	public OptionDialog(Production p, Machine m) {
		setResizable(false);
		this.p = p;
		this.m = m;
		setTitle("Options");
		try {	
			setIconImage(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/logo.png")));
		} catch (NullPointerException e111) {
			System.out.println("Image load error");
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setModal(true);
		setBounds(100, 100, 316, 427);
		setLocationRelativeTo(null);
		getContentPane().setLayout(null);
		
		btnOk = new JButton("OK");
		btnOk.setToolTipText("Save and close");
		btnOk.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				btnOK();
			}
		});
		btnOk.setBounds(140, 370, 75, 25);
		getContentPane().add(btnOk);
		
		btnCancel = new JButton("Cancel");
		btnCancel.setToolTipText("Cancel");
		btnCancel.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
		btnCancel.setBounds(225, 370, 75, 25);
		getContentPane().add(btnCancel);
		
		tabs = new JTabbedPane(JTabbedPane.TOP);
		tabs.setBounds(10, 11, 290, 356);
		getContentPane().add(tabs);
		
		pnlOptions = new JPanel();
		tabs.addTab("System", null, pnlOptions, null);
		pnlOptions.setBackground(Color.WHITE);
		pnlOptions.setLayout(null);
		
		pnlAdvanced = new JPanel();
		pnlAdvanced.setBounds(10, 142, 266, 168);
		pnlOptions.add(pnlAdvanced);
		pnlAdvanced.setBackground(Color.WHITE);
		pnlAdvanced.setLayout(null);
		pnlAdvanced.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Machine Defaults", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		
		label = new JLabel("Acceleration:");
		label.setToolTipText("Override default machine acceleration");
		label.setHorizontalAlignment(SwingConstants.RIGHT);
		label.setBounds(33, 32, 108, 14);
		pnlAdvanced.add(label);
		
		label_1 = new JLabel("Deceleration:");
		label_1.setToolTipText("Override default machine deceleration");
		label_1.setHorizontalAlignment(SwingConstants.RIGHT);
		label_1.setBounds(33, 57, 108, 14);
		pnlAdvanced.add(label_1);
		
		label_2 = new JLabel("Speed Clamp:");
		label_2.setToolTipText("Speed clamp distance");
		label_2.setHorizontalAlignment(SwingConstants.RIGHT);
		label_2.setBounds(18, 133, 123, 14);
		pnlAdvanced.add(label_2);
		
		txtAccel = new JTextField();
		txtAccel.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent arg0) {
				txtAccel.selectAll();
			}
		});
		txtAccel.setToolTipText("Override default machine acceleration");
		txtAccel.setColumns(10);
		txtAccel.setBounds(151, 29, 55, 20);
		pnlAdvanced.add(txtAccel);
		
		txtDecel = new JTextField();
		txtDecel.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				txtDecel.selectAll();
			}
		});
		txtDecel.setToolTipText("Override default machine deceleration");
		txtDecel.setColumns(10);
		txtDecel.setBounds(151, 54, 55, 20);
		pnlAdvanced.add(txtDecel);
		
		txtSpeedClamp = new JTextField();
		txtSpeedClamp.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				txtSpeedClamp.selectAll();
			}
		});
		txtSpeedClamp.setToolTipText("Speed clamp distance");
		txtSpeedClamp.setColumns(10);
		txtSpeedClamp.setBounds(151, 130, 55, 20);
		pnlAdvanced.add(txtSpeedClamp);
		
		label_3 = new JLabel("Sync Diameter:");
		label_3.setToolTipText("Sync diameter");
		label_3.setBounds(67, 108, 75, 14);
		pnlAdvanced.add(label_3);
		
		txtSyncDiam = new JTextField();
		txtSyncDiam.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				txtSyncDiam.selectAll();
			}
		});
		txtSyncDiam.setToolTipText("Sync diameter");
		txtSyncDiam.setColumns(10);
		txtSyncDiam.setBounds(151, 105, 55, 20);
		pnlAdvanced.add(txtSyncDiam);
		
		label_4 = new JLabel("Acceleration change:");
		label_4.setToolTipText("Time taken to reach full acceleration");
		label_4.setBounds(39, 82, 101, 14);
		pnlAdvanced.add(label_4);
		
		txtAccelDelta = new JTextField();
		txtAccelDelta.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				txtAccelDelta.selectAll();
			}
		});
		txtAccelDelta.setToolTipText("Time taken to reach full acceleration");
		txtAccelDelta.setColumns(10);
		txtAccelDelta.setBounds(151, 79, 55, 20);
		pnlAdvanced.add(txtAccelDelta);
		
		pnlBasic = new JPanel();
		pnlBasic.setLayout(null);
		pnlBasic.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Basic Options", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		pnlBasic.setBackground(Color.WHITE);
		pnlBasic.setBounds(10, 11, 266, 120);
		pnlOptions.add(pnlBasic);
		
		lblOther_1 = new JLabel("File name:");
		lblOther_1.setBounds(52, 83, 59, 14);
		pnlBasic.add(lblOther_1);
		
		txtFileName = new JTextField();
		txtFileName.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				/*if(!txtFileName.isEnabled()){
					txtFileName.setEnabled(false/*true);
					chckbxSaveSettings.setSelected(true);
				}*/
			}
		});
		txtFileName.setText(p.SaveFileName);
		txtFileName.setEnabled(false/*p.SaveOnClose*/);
		txtFileName.setColumns(10);
		txtFileName.setBounds(108, 80, 97, 20);
		pnlBasic.add(txtFileName);
		
		chckbxSaveSettings = new JCheckBox("Save settings on close");
		chckbxSaveSettings.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(chckbxSaveSettings.isSelected()){
					txtFileName.setEnabled(false/*true*/);
					chckbxSaveSchedule.setEnabled(true);
				}else{
					txtFileName.setEnabled(false);
					chckbxSaveSchedule.setEnabled(false);
				}
			}
		});
		chckbxSaveSettings.setSelected(p.SaveOnClose);
		chckbxSaveSettings.setBackground(Color.WHITE);
		chckbxSaveSettings.setBounds(46, 23, 155, 23);
		pnlBasic.add(chckbxSaveSettings);
		
		chckbxSaveSchedule = new JCheckBox("Including job schedule");
		chckbxSaveSchedule.setBackground(Color.WHITE);
		chckbxSaveSchedule.setBounds(46, 49, 131, 23);
		chckbxSaveSchedule.setSelected(p.SaveSchedule);
		chckbxSaveSchedule.setEnabled(p.SaveOnClose);
		pnlBasic.add(chckbxSaveSchedule);
		
		pnlTimings = new JPanel();
		pnlTimings.setBackground(Color.WHITE);
		tabs.addTab("Timings", null, pnlTimings, null);
		pnlTimings.setLayout(null);
		
		cmbMachineType = new JComboBox();
		cmbMachineType.setToolTipText("Select the machine type to edit");
		cmbMachineType.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent arg0) {
				SaveTimings();
			}
		});
		cmbMachineType.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UpdateTimeOptions();
			}
		});
		cmbMachineType.setModel(new DefaultComboBoxModel(new String[] {"ER610", "SR9-DS", "SR9-DT", "SR800", "Custom"}));
		cmbMachineType.setBounds(112, 11, 146, 20);
		pnlTimings.add(cmbMachineType);
		
		lblMachineType = new JLabel("Machine Type:");
		lblMachineType.setToolTipText("Select the machine type to edit");
		lblMachineType.setBounds(10, 14, 75, 14);
		pnlTimings.add(lblMachineType);
		
		txtSet1 = new JTextField();
		txtSet1.setToolTipText("Time taken to enter job settings into the machine");
		txtSet1.setBounds(112, 62, 61, 20);
		pnlTimings.add(txtSet1);
		txtSet1.setColumns(10);
		
		txtLoad1 = new JTextField();
		txtLoad1.setToolTipText("Total time taken to change a mother roll");
		txtLoad1.setColumns(10);
		txtLoad1.setBounds(112, 84, 61, 20);
		pnlTimings.add(txtLoad1);
		
		txtDiam1 = new JTextField();
		txtDiam1.setToolTipText("Total time to change the rewind core diameter on all shafts");
		txtDiam1.setColumns(10);
		txtDiam1.setBounds(112, 304, 61, 20);
		pnlTimings.add(txtDiam1);
		
		txtAlign1 = new JTextField();
		txtAlign1.setToolTipText("Time to adjust and align a new mother roll after it is loaded");
		txtAlign1.setColumns(10);
		txtAlign1.setBounds(112, 106, 61, 20);
		pnlTimings.add(txtAlign1);
		
		txtPos1 = new JTextField();
		txtPos1.setToolTipText("The time taken PER KNIFE to position for a new job");
		txtPos1.setColumns(10);
		txtPos1.setBounds(112, 128, 61, 20);
		pnlTimings.add(txtPos1);
		
		txtSplice1 = new JTextField();
		txtSplice1.setToolTipText("Total time taken to detect a flag and splice the web");
		txtSplice1.setColumns(10);
		txtSplice1.setBounds(112, 150, 61, 20);
		pnlTimings.add(txtSplice1);
		
		txtCut1 = new JTextField();
		txtCut1.setToolTipText("Time PER REEL to cut the web after a run");
		txtCut1.setColumns(10);
		txtCut1.setBounds(112, 172, 61, 20);
		pnlTimings.add(txtCut1);
		
		txtTapet1 = new JTextField();
		txtTapet1.setToolTipText("Time PER REEL to tape down tails");
		txtTapet1.setColumns(10);
		txtTapet1.setBounds(112, 194, 61, 20);
		pnlTimings.add(txtTapet1);
		
		txtTapec1 = new JTextField();
		txtTapec1.setToolTipText("Time PER REEL to apply tape to new cores");
		txtTapec1.setColumns(10);
		txtTapec1.setBounds(112, 216, 61, 20);
		pnlTimings.add(txtTapec1);
		
		txtLoadr1 = new JTextField();
		txtLoadr1.setToolTipText("Time PER REEL to load a new reel before a run");
		txtLoadr1.setColumns(10);
		txtLoadr1.setBounds(112, 238, 61, 20);
		pnlTimings.add(txtLoadr1);
		
		txtUnloadr1 = new JTextField();
		txtUnloadr1.setToolTipText("Time PER REEL to unload completed reel from shaft");
		txtUnloadr1.setColumns(10);
		txtUnloadr1.setBounds(112, 260, 61, 20);
		pnlTimings.add(txtUnloadr1);
		
		txtAlignr1 = new JTextField();
		txtAlignr1.setToolTipText("Time PER REEL to align a new core");
		txtAlignr1.setColumns(10);
		txtAlignr1.setBounds(112, 282, 61, 20);
		pnlTimings.add(txtAlignr1);
		
		lblStandard = new JLabel("Manual");
		lblStandard.setToolTipText("Manual timings");
		lblStandard.setBounds(112, 42, 46, 14);
		pnlTimings.add(lblStandard);
		
		lblWithOptions = new JLabel("Auto/upgraded");
		lblWithOptions.setToolTipText("Timings with automation (locked by default)");
		lblWithOptions.setBounds(197, 42, 88, 14);
		pnlTimings.add(lblWithOptions);
		
		txtSet2 = new JTextField();
		txtSet2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				OpenPasswordDialog();
			}
		});
		txtSet2.setEnabled(false);
		txtSet2.setColumns(10);
		txtSet2.setBounds(197, 62, 61, 20);
		pnlTimings.add(txtSet2);
		
		txtLoad2 = new JTextField();
		txtLoad2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				OpenPasswordDialog();
			}
		});
		txtLoad2.setEnabled(false);
		txtLoad2.setColumns(10);
		txtLoad2.setBounds(197, 84, 61, 20);
		pnlTimings.add(txtLoad2);
		
		txtDiam2 = new JTextField();
		txtDiam2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				OpenPasswordDialog();
			}
		});
		txtDiam2.setEnabled(false);
		txtDiam2.setColumns(10);
		txtDiam2.setBounds(197, 304, 61, 20);
		pnlTimings.add(txtDiam2);
		
		txtAlign2 = new JTextField();
		txtAlign2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				OpenPasswordDialog();
			}
		});
		txtAlign2.setEnabled(false);
		txtAlign2.setColumns(10);
		txtAlign2.setBounds(197, 106, 61, 20);
		pnlTimings.add(txtAlign2);
		
		txtPos2 = new JTextField();
		txtPos2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				OpenPasswordDialog();
			}
		});
		txtPos2.setEnabled(false);
		txtPos2.setColumns(10);
		txtPos2.setBounds(197, 128, 61, 20);
		pnlTimings.add(txtPos2);
		
		txtSplice2 = new JTextField();
		txtSplice2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				OpenPasswordDialog();
			}
		});
		
		txtSplice2.setEnabled(false);
		txtSplice2.setColumns(10);
		txtSplice2.setBounds(197, 150, 61, 20);
		pnlTimings.add(txtSplice2);
		
		txtCut2 = new JTextField();
		txtCut2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				OpenPasswordDialog();
			}
		});
		txtCut2.setEnabled(false);
		txtCut2.setColumns(10);
		txtCut2.setBounds(197, 172, 61, 20);
		pnlTimings.add(txtCut2);
		
		txtTapet2 = new JTextField();
		txtTapet2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				OpenPasswordDialog();
			}
		});
		txtTapet2.setEnabled(false);
		txtTapet2.setColumns(10);
		txtTapet2.setBounds(197, 194, 61, 20);
		pnlTimings.add(txtTapet2);
		
		txtTapec2 = new JTextField();
		txtTapec2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				OpenPasswordDialog();
			}
		});
		txtTapec2.setEnabled(false);
		txtTapec2.setColumns(10);
		txtTapec2.setBounds(197, 216, 61, 20);
		pnlTimings.add(txtTapec2);
		
		txtLoadr2 = new JTextField();
		txtLoadr2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				OpenPasswordDialog();
			}
		});
		txtLoadr2.setEnabled(false);
		txtLoadr2.setColumns(10);
		txtLoadr2.setBounds(197, 238, 61, 20);
		pnlTimings.add(txtLoadr2);
		
		txtUnloadr2 = new JTextField();
		txtUnloadr2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				OpenPasswordDialog();
			}
		});
		txtUnloadr2.setEnabled(false);
		txtUnloadr2.setColumns(10);
		txtUnloadr2.setBounds(197, 260, 61, 20);
		pnlTimings.add(txtUnloadr2);
		
		txtAlignr2 = new JTextField();
		txtAlignr2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				OpenPasswordDialog();
			}
		});
		txtAlignr2.setEnabled(false);
		txtAlignr2.setColumns(10);
		txtAlignr2.setBounds(197, 282, 61, 20);
		pnlTimings.add(txtAlignr2);
		
		lblConfigureMachine = new JLabel("Configure machine:");
		lblConfigureMachine.setToolTipText("Time taken to enter job settings into the machine");
		lblConfigureMachine.setBounds(10, 65, 95, 14);
		pnlTimings.add(lblConfigureMachine);
		
		lblLoadUnwind = new JLabel("Mother change:");
		lblLoadUnwind.setToolTipText("Total time taken to change a mother roll");
		lblLoadUnwind.setBounds(10, 87, 92, 14);
		pnlTimings.add(lblLoadUnwind);
		
		lblAlignUnwind = new JLabel("Adjust/align mother:");
		lblAlignUnwind.setToolTipText("Time to adjust and align a new mother roll after it is loaded");
		lblAlignUnwind.setBounds(10, 109, 105, 14);
		pnlTimings.add(lblAlignUnwind);
		
		lblPositionKnives = new JLabel("Position knives:");
		lblPositionKnives.setToolTipText("The time taken PER KNIFE to position for a new job");
		lblPositionKnives.setBounds(10, 131, 92, 14);
		pnlTimings.add(lblPositionKnives);
		
		lblSpliceRoll = new JLabel("Complete splice:");
		lblSpliceRoll.setToolTipText("Total time taken to detect a flag and splice the web");
		lblSpliceRoll.setBounds(10, 153, 92, 14);
		pnlTimings.add(lblSpliceRoll);
		
		lblCutRewind = new JLabel("Cut rewind:");
		lblCutRewind.setToolTipText("Time PER REEL to cut the web after a run");
		lblCutRewind.setBounds(10, 175, 92, 14);
		pnlTimings.add(lblCutRewind);
		
		lblTapeRewindTail = new JLabel("Tape rewind tail:");
		lblTapeRewindTail.setToolTipText("Time PER REEL to tape down tails");
		lblTapeRewindTail.setBounds(10, 197, 92, 14);
		pnlTimings.add(lblTapeRewindTail);
		
		lblTapeRewindCore = new JLabel("Tape rewind core:");
		lblTapeRewindCore.setToolTipText("Time PER REEL to apply tape to new cores");
		lblTapeRewindCore.setBounds(10, 219, 92, 14);
		pnlTimings.add(lblTapeRewindCore);
		
		lblLoadRewind = new JLabel("Load rewind:");
		lblLoadRewind.setToolTipText("Time PER REEL to load a new reel before a run");
		lblLoadRewind.setBounds(10, 241, 92, 14);
		pnlTimings.add(lblLoadRewind);
		
		lblUnloadRewind = new JLabel("Unload rewind:");
		lblUnloadRewind.setToolTipText("Time PER REEL to unload completed reel from shaft");
		lblUnloadRewind.setBounds(10, 263, 92, 14);
		pnlTimings.add(lblUnloadRewind);
		
		lblAlignRewind = new JLabel("Align rewind:");
		lblAlignRewind.setToolTipText("Time PER REEL to align a new core");
		lblAlignRewind.setBounds(10, 285, 92, 14);
		pnlTimings.add(lblAlignRewind);
		
		lbls = new JLabel("(s)");
		lbls.setBounds(259, 65, 16, 14);
		pnlTimings.add(lbls);
		
		label_7 = new JLabel("(s)");
		label_7.setBounds(259, 87, 16, 14);
		pnlTimings.add(label_7);
		
		label_8 = new JLabel("(s)");
		label_8.setBounds(259, 307, 16, 14);
		pnlTimings.add(label_8);
		
		label_10 = new JLabel("(s)");
		label_10.setBounds(259, 109, 16, 14);
		pnlTimings.add(label_10);
		
		label_11 = new JLabel("(s)");
		label_11.setBounds(259, 131, 16, 14);
		pnlTimings.add(label_11);
		
		label_12 = new JLabel("(s)");
		label_12.setBounds(259, 153, 16, 14);
		pnlTimings.add(label_12);
		
		label_13 = new JLabel("(s)");
		label_13.setBounds(259, 175, 16, 14);
		pnlTimings.add(label_13);
		
		label_14 = new JLabel("(s)");
		label_14.setBounds(259, 197, 16, 14);
		pnlTimings.add(label_14);
		
		label_15 = new JLabel("(s)");
		label_15.setBounds(259, 219, 16, 14);
		pnlTimings.add(label_15);
		
		label_16 = new JLabel("(s)");
		label_16.setBounds(259, 241, 16, 14);
		pnlTimings.add(label_16);
		
		label_17 = new JLabel("(s)");
		label_17.setBounds(259, 263, 16, 14);
		pnlTimings.add(label_17);
		
		label_18 = new JLabel("(s)");
		label_18.setBounds(259, 285, 16, 14);
		pnlTimings.add(label_18);
		
		label_19 = new JLabel("(s)");
		label_19.setBounds(174, 65, 16, 14);
		pnlTimings.add(label_19);
		
		label_20 = new JLabel("(s)");
		label_20.setBounds(174, 87, 16, 14);
		pnlTimings.add(label_20);
		
		label_21 = new JLabel("(s)");
		label_21.setBounds(174, 307, 16, 14);
		pnlTimings.add(label_21);
		
		label_22 = new JLabel("(s)");
		label_22.setBounds(174, 109, 16, 14);
		pnlTimings.add(label_22);
		
		label_23 = new JLabel("(s)");
		label_23.setBounds(174, 285, 16, 14);
		pnlTimings.add(label_23);
		
		label_24 = new JLabel("(s)");
		label_24.setBounds(174, 153, 16, 14);
		pnlTimings.add(label_24);
		
		label_25 = new JLabel("(s)");
		label_25.setBounds(174, 241, 16, 14);
		pnlTimings.add(label_25);
		
		label_26 = new JLabel("(s)");
		label_26.setBounds(174, 131, 16, 14);
		pnlTimings.add(label_26);
		
		label_27 = new JLabel("(s)");
		label_27.setBounds(174, 175, 16, 14);
		pnlTimings.add(label_27);
		
		label_28 = new JLabel("(s)");
		label_28.setBounds(174, 197, 16, 14);
		pnlTimings.add(label_28);
		
		label_29 = new JLabel("(s)");
		label_29.setBounds(174, 219, 16, 14);
		pnlTimings.add(label_29);
		
		label_30 = new JLabel("(s)");
		label_30.setBounds(174, 263, 16, 14);
		pnlTimings.add(label_30);
		
		lblChangeRewindDiam = new JLabel("Change rewind diam:");
		lblChangeRewindDiam.setToolTipText("Total time to change the rewind core diameter on all shafts");
		lblChangeRewindDiam.setBounds(10, 307, 105, 14);
		pnlTimings.add(lblChangeRewindDiam);
		
		pnlViews = new JPanel();
		pnlViews.setBackground(Color.WHITE);
		tabs.addTab("Advanced", null, pnlViews, null);
		pnlViews.setLayout(null);
		
		lblOptionsNotYet = new JLabel("These options are locked");
		lblOptionsNotYet.setFont(new Font("Tahoma", Font.ITALIC, 11));
		lblOptionsNotYet.setForeground(Color.RED);
		lblOptionsNotYet.setBounds(74, 25, 126, 14);
		pnlViews.add(lblOptionsNotYet);
		
		btnUnlock = new JButton("Unlock");
		btnUnlock.setToolTipText("Unlock advanced options");
		btnUnlock.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				OpenPasswordDialog();
			}
		});
		btnUnlock.setBounds(90, 50, 89, 23);
		pnlViews.add(btnUnlock);
		
		slide1 = new JSlider();
		slide1.setToolTipText("Slide to adjust");
		slide1.setMaximum(1000);
		slide1.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				if(slide1.isVisible()){
					try{
						lblPc1.setText(Double.toString(slide1.getValue() / 10.) + "%");
					}catch(NullPointerException e2){}
				}
			}
		});
		slide1.setVisible(false);
		slide1.setValue((int)(p.TitanEfficiency*1000));
		slide1.setMinorTickSpacing(100);
		slide1.setPaintTicks(true);
		slide1.setBackground(Color.WHITE);
		slide1.setBounds(29, 120, 208, 36);
		pnlViews.add(slide1);
		
		slide2 = new JSlider();
		slide2.setToolTipText("Slide to adjust");
		slide2.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				if(slide2.isVisible()){
					try{
						lblPc2.setText(Double.toString(slide2.getValue() / 10.) + "%");
					}catch(NullPointerException e2){}
				}
			}
		});
		slide2.setMaximum(1000);
		slide2.setVisible(false);
		slide2.setValue((int)(p.CustomEfficiency*1000));
		slide2.setMinorTickSpacing(100);
		slide2.setPaintTicks(true);
		slide2.setBackground(Color.WHITE);
		slide2.setBounds(29, 190, 208, 36);
		pnlViews.add(slide2);
		
		slide3 = new JSlider();
		slide3.setToolTipText("Slide to adjust");
		slide3.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				if(slide3.isVisible()){
					try{
						lblPc3.setText(Double.toString(slide3.getValue() / 10.) + "%");
					}catch(NullPointerException e2){}
				}
			}
		});
		slide3.setMaximum(1000);
		slide3.setVisible(false);
		slide3.setMinorTickSpacing(100);
		slide3.setPaintTicks(true);
		slide3.setValue((int)(p.GlobalEfficiency*1000));
		slide3.setBackground(Color.WHITE);
		slide3.setBounds(29, 260, 208, 36);
		pnlViews.add(slide3);
		
		lblPc3 = new JLabel(Double.toString(p.GlobalEfficiency*100) + "%");
		lblPc3.setVisible(false);
		lblPc3.setBounds(191, 240, 46, 14);
		pnlViews.add(lblPc3);
		
		lblPc2 = new JLabel(Double.toString(p.CustomEfficiency*100) + "%");
		lblPc2.setVisible(false);
		lblPc2.setBounds(191, 170, 46, 14);
		pnlViews.add(lblPc2);
		
		lblPc1 = new JLabel(Double.toString(p.TitanEfficiency*100) + "%");
		lblPc1.setVisible(false);
		lblPc1.setBounds(191, 100, 46, 14);
		pnlViews.add(lblPc1);
		
		lblGlobalAdjustment = new JLabel("Global adjustment:");
		lblGlobalAdjustment.setVisible(false);
		lblGlobalAdjustment.setBounds(29, 240, 97, 14);
		pnlViews.add(lblGlobalAdjustment);
		
		lblCustomMachines = new JLabel("Custom machines:");
		lblCustomMachines.setVisible(false);
		lblCustomMachines.setBounds(29, 170, 97, 14);
		pnlViews.add(lblCustomMachines);
		
		lblTitanMachines = new JLabel("Titan machines:");
		lblTitanMachines.setVisible(false);
		lblTitanMachines.setBounds(29, 100, 97, 14);
		pnlViews.add(lblTitanMachines);
		
		lblAdvancedOptionsPlease = new JLabel("Efficiency factor adjustment");
		lblAdvancedOptionsPlease.setVisible(false);
		lblAdvancedOptionsPlease.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblAdvancedOptionsPlease.setBounds(29, 23, 221, 18);
		pnlViews.add(lblAdvancedOptionsPlease);
		
		lblAdv2 = new JLabel("Adjust these sliders to change the efficiency");
		lblAdv2.setVisible(false);
		lblAdv2.setForeground(Color.GRAY);
		lblAdv2.setBounds(29, 50, 216, 14);
		pnlViews.add(lblAdv2);
		
		lblAdv3 = new JLabel("scaling factors applied to all calculations.");
		lblAdv3.setVisible(false);
		lblAdv3.setForeground(Color.GRAY);
		lblAdv3.setBounds(29, 65, 216, 14);
		pnlViews.add(lblAdv3);
		
		pnlCharts = new JPanel();
		pnlCharts.setBackground(Color.WHITE);
		tabs.addTab("Reset", null, pnlCharts, null);
		pnlCharts.setLayout(null);
		
		lblResetOptions = new JLabel("Reset options");
		lblResetOptions.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblResetOptions.setBounds(29, 23, 189, 18);
		pnlCharts.add(lblResetOptions);
		
		btnResetAdvancedOptions = new JButton("Reset machine defaults");
		btnResetAdvancedOptions.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ResetAdvanced();
			}
		});
		btnResetAdvancedOptions.setToolTipText("Reset the various advanced options such as acceleration and sync diameter");
		btnResetAdvancedOptions.setBounds(29, 64, 225, 23);
		pnlCharts.add(btnResetAdvancedOptions);
		
		btnResetManualTimings = new JButton("Reset manual timings");
		btnResetManualTimings.setToolTipText("Reset manual timings for the specified machine");
		btnResetManualTimings.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ResetManual();
			}
		});
		btnResetManualTimings.setBounds(29, 107, 133, 23);
		pnlCharts.add(btnResetManualTimings);
		
		cmbResetManual = new JComboBox();
		cmbResetManual.setToolTipText("Select a machine to reset timings");
		cmbResetManual.setModel(new DefaultComboBoxModel(new String[] {"All", "ER610", "SR9-DS", "SR9-DT", "SR800", "Custom"}));
		cmbResetManual.setBounds(172, 107, 82, 23);
		pnlCharts.add(cmbResetManual);
		
		btnResetAutoTimings = new JButton("Reset auto timings");
		btnResetAutoTimings.setToolTipText("Reset automatic timings for the specified machine");
		btnResetAutoTimings.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ResetAuto();
			}
		});
		btnResetAutoTimings.setEnabled(false);
		btnResetAutoTimings.setBounds(29, 141, 133, 23);
		pnlCharts.add(btnResetAutoTimings);
		
		cmbResetAuto = new JComboBox();
		cmbResetAuto.setToolTipText("Select a machine to reset timings");
		cmbResetAuto.setEnabled(false);
		cmbResetAuto.setModel(new DefaultComboBoxModel(new String[] {"All", "ER610", "SR9-DS", "SR9-DT", "SR800", "Custom"}));
		cmbResetAuto.setBounds(172, 141, 82, 23);
		pnlCharts.add(cmbResetAuto);
		
		btnResetEfficiencySliders = new JButton("Reset efficiency sliders");
		btnResetEfficiencySliders.setToolTipText("Reset all efficiency values");
		btnResetEfficiencySliders.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ResetSliders();
			}
		});
		btnResetEfficiencySliders.setEnabled(false);
		btnResetEfficiencySliders.setBounds(29, 184, 225, 23);
		pnlCharts.add(btnResetEfficiencySliders);
		
		lblNoteResetsTake = new JLabel("Note: resets take place instantly and cannot");
		lblNoteResetsTake.setForeground(Color.GRAY);
		lblNoteResetsTake.setBounds(29, 279, 225, 14);
		pnlCharts.add(lblNoteResetsTake);
		
		lblBeReverted = new JLabel("be reverted.");
		lblBeReverted.setForeground(Color.GRAY);
		lblBeReverted.setBounds(29, 295, 82, 14);
		pnlCharts.add(lblBeReverted);
		
		btnResetAllSettings = new JButton("Reset all settings");
		btnResetAllSettings.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ShowResetHelp();
			}
		});
		btnResetAllSettings.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnResetAllSettings.setBounds(29, 231, 225, 23);
		pnlCharts.add(btnResetAllSettings);
		
		TimingsBoxes1 = new JTextField[OperatorTimings.length];
		TimingsBoxes2 = new JTextField[OperatorTimings.length];
		
		TimingsBoxes1[0] = txtSet1;
		TimingsBoxes1[1] = txtLoad1;
		TimingsBoxes1[2] = txtAlign1;
		TimingsBoxes1[3] = txtPos1;
		TimingsBoxes1[4] = txtSplice1;
		TimingsBoxes1[5] = txtCut1;
		TimingsBoxes1[6] = txtTapet1;
		TimingsBoxes1[7] = txtTapec1;
		TimingsBoxes1[8] = txtLoadr1;
		TimingsBoxes1[9] = txtUnloadr1; 
		TimingsBoxes1[10] = txtAlignr1;
		TimingsBoxes1[11] = txtDiam1;
		
		TimingsBoxes2[0] = txtSet2;
		TimingsBoxes2[1] = txtLoad2;
		TimingsBoxes2[2] = txtAlign2;
		TimingsBoxes2[3] = txtPos2;
		TimingsBoxes2[4] = txtSplice2;
		TimingsBoxes2[5] = txtCut2;
		TimingsBoxes2[6] = txtTapet2;
		TimingsBoxes2[7] = txtTapec2;
		TimingsBoxes2[8] = txtLoadr2;
		TimingsBoxes2[9] = txtUnloadr2; 
		TimingsBoxes2[10] = txtAlignr2;
		TimingsBoxes2[11] = txtDiam2;
		
		for(int i=0; i<TimingsBoxes1.length; ++i){
			TimingsBoxes1[i].addFocusListener(new FocusAdapter() {
				@Override
				public void focusGained(FocusEvent arg0) {
					((JTextField)arg0.getSource()).selectAll();
				}
			});
			TimingsBoxes2[i].addFocusListener(new FocusAdapter() {
				@Override
				public void focusGained(FocusEvent arg0) {
					((JTextField)arg0.getSource()).selectAll();
				}
			});
		}
		
		if(m != null){
			switch(m.model){
				case ER610: cmbMachineType.setSelectedIndex(0); break;
				case SR9DS: cmbMachineType.setSelectedIndex(1); break;
				case SR9DT: cmbMachineType.setSelectedIndex(2); break;
				case SR800: cmbMachineType.setSelectedIndex(3); break;
				case OTHER: cmbMachineType.setSelectedIndex(4); break;
				default: cmbMachineType.setSelectedIndex(0); break;
			}
		}

		UpdateTimeOptions();
		txtAccel.setText(Double.toString(roundTwoDecimals(p.accel / Consts.MIN_TO_S)));
		txtDecel.setText(Double.toString(roundTwoDecimals(p.decel / Consts.MIN_TO_S)));
		txtAccelDelta.setText(Double.toString(roundTwoDecimals(p.accel_delta)));
		txtSyncDiam.setText(Double.toString(roundTwoDecimals(p.sync_diam)));
		txtSpeedClamp.setText(Double.toString(roundTwoDecimals(p.speed_clamp)));
		
		lblM = new JLabel("m");
		lblM.setBounds(210, 133, 46, 14);
		pnlAdvanced.add(lblM);
		
		lblMm = new JLabel("mm");
		lblMm.setBounds(210, 108, 46, 14);
		pnlAdvanced.add(lblMm);
		
		lblS = new JLabel("s");
		lblS.setBounds(210, 85, 46, 14);
		pnlAdvanced.add(lblS);
		
		lblMmins_1 = new JLabel("m/min/s");
		lblMmins_1.setBounds(210, 57, 46, 14);
		pnlAdvanced.add(lblMmins_1);
		
		lblMmins = new JLabel("m/min/s");
		lblMmins.setBounds(210, 32, 46, 14);
		pnlAdvanced.add(lblMmins);
		
		pnlLock = new JPanel();
		pnlLock.setToolTipText("Administrator controls lock status");
		pnlLock.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				OpenPasswordDialog();
			}
		});
		pnlLock.setBackground(Color.RED);
		pnlLock.setBounds(10, 375, 15, 15);
		getContentPane().add(pnlLock);
		
		lblLock = new JLabel("Locked");
		lblLock.setToolTipText("Administrator controls lock status");
		lblLock.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				OpenPasswordDialog();
			}
		});
		lblLock.setBounds(32, 375, 75, 14);
		getContentPane().add(lblLock);
		
		UpdateLock();
	}
	
	private void UpdateLock(){
		if(p.Unlocked){
			pnlLock.setBackground(Color.GREEN);
			lblLock.setText("Unlocked");
			
			txtAlign2.setEnabled(true);
			txtAlignr2.setEnabled(true);
			txtCut2.setEnabled(true);
			txtDiam2.setEnabled(true);
			txtLoad2.setEnabled(true);
			txtLoadr2.setEnabled(true);
			txtPos2.setEnabled(true);
			txtSet2.setEnabled(true);
			txtSplice2.setEnabled(true);
			txtTapec2.setEnabled(true);
			txtTapet2.setEnabled(true);
			txtUnloadr2.setEnabled(true);
			
			lblAdvancedOptionsPlease.setVisible(true);
			lblAdv2.setVisible(true);
			lblAdv3.setVisible(true);
			lblCustomMachines.setVisible(true);
			lblTitanMachines.setVisible(true);
			lblGlobalAdjustment.setVisible(true);
			lblPc1.setVisible(true);
			lblPc2.setVisible(true);
			lblPc3.setVisible(true);
			slide1.setVisible(true);
			slide2.setVisible(true);
			slide3.setVisible(true);

			btnUnlock.setVisible(false);
			lblOptionsNotYet.setVisible(false);
			
			btnResetAutoTimings.setEnabled(true);
			cmbResetAuto.setEnabled(true);
			btnResetEfficiencySliders.setEnabled(true);
		}else{
			pnlLock.setBackground(Color.RED);
			lblLock.setText("Locked");
			
			txtAlign2.setEnabled(false);
			txtAlignr2.setEnabled(false);
			txtCut2.setEnabled(false);
			txtDiam2.setEnabled(false);
			txtLoad2.setEnabled(false);
			txtLoadr2.setEnabled(false);
			txtPos2.setEnabled(false);
			txtSet2.setEnabled(false);
			txtSplice2.setEnabled(false);
			txtTapec2.setEnabled(false);
			txtTapet2.setEnabled(false);
			txtUnloadr2.setEnabled(false);
			
			lblAdvancedOptionsPlease.setVisible(false);
			lblAdv2.setVisible(false);
			lblAdv3.setVisible(false);
			lblCustomMachines.setVisible(false);
			lblTitanMachines.setVisible(false);
			lblGlobalAdjustment.setVisible(false);
			lblPc1.setVisible(false);
			lblPc2.setVisible(false);
			lblPc3.setVisible(false);
			slide1.setVisible(false);
			slide2.setVisible(false);
			slide3.setVisible(false);

			btnUnlock.setVisible(true);
			lblOptionsNotYet.setVisible(true);
			
			btnResetAutoTimings.setEnabled(false);
			cmbResetAuto.setEnabled(false);
			btnResetEfficiencySliders.setEnabled(false);
		}
	}
	
	private void ResetManual(){
		Machine.Model model = null;
		switch(cmbResetManual.getSelectedIndex()){
			case 0: model = null; break;
			case 1: model = Model.ER610; break;
			case 2: model = Model.SR9DS; break;
			case 3: model = Model.SR9DT; break;
			case 4: model = Model.SR800; break;
			case 5: model = Model.OTHER; break;
		}
		p.timings.ResetTimes(model, true, (cmbResetManual.getSelectedIndex()==0 ? true : false));
		UpdateTimeOptions();
	}
	private void ResetAuto(){
		Machine.Model model = null;
		switch(cmbResetAuto.getSelectedIndex()){
			case 0: model = null; break;
			case 1: model = Model.ER610; break;
			case 2: model = Model.SR9DS; break;
			case 3: model = Model.SR9DT; break;
			case 4: model = Model.SR800; break;
			case 5: model = Model.OTHER; break;
		}
		p.timings.ResetTimes(model, false, (cmbResetAuto.getSelectedIndex()==0 ? true : false));
		UpdateTimeOptions();
	}
	
	private void ShowResetHelp(){
		JOptionPane.showMessageDialog(this, "To clear all settings, de-select the \"Save settings on close\" option on the first options screen, then close and re-start the application.");
	}
	
	private void ResetAdvanced(){
		p.accel = Consts.DEFAULT_ACCEL;
		p.decel = Consts.DEFAULT_DECEL;
		p.sync_diam = Consts.DEFAULT_SYNC;
		p.speed_clamp = Consts.DEFAULT_SCLAMP;
		p.accel_delta = Consts.DEFAULT_ADELTA;
		txtAccel.setText(Double.toString(roundTwoDecimals(p.accel / Consts.MIN_TO_S)));
		txtDecel.setText(Double.toString(roundTwoDecimals(p.decel / Consts.MIN_TO_S)));
		txtAccelDelta.setText(Double.toString(roundTwoDecimals(p.accel_delta)));
		txtSyncDiam.setText(Double.toString(roundTwoDecimals(p.sync_diam)));
		txtSpeedClamp.setText(Double.toString(roundTwoDecimals(p.speed_clamp)));
	}
	
	private void ResetSliders(){
		slide1.setValue((int)(Consts.TITAN_EFF*1000));
		slide2.setValue((int)(Consts.CUSTOM_EFF*1000));
		slide3.setValue((int)(Consts.GLOBAL_EFF*1000));
		p.TitanEfficiency = Consts.TITAN_EFF;
		p.CustomEfficiency = Consts.CUSTOM_EFF;
		p.GlobalEfficiency = Consts.GLOBAL_EFF;
		lblPc1.setText(Double.toString(Consts.TITAN_EFF*100)+"%");
		lblPc2.setText(Double.toString(Consts.CUSTOM_EFF*100)+"%");
		lblPc3.setText(Double.toString(Consts.GLOBAL_EFF*100)+"%");
	}
	
	private void btnOK(){
		p.accel = Double.parseDouble(txtAccel.getText()) * Consts.MIN_TO_S;
		p.decel = Double.parseDouble(txtDecel.getText()) * Consts.MIN_TO_S;
		p.accel_delta = Double.parseDouble(txtAccelDelta.getText());
		
		SaveTimings();
		
		if(chckbxSaveSettings.isSelected()){
			p.SaveOnClose = true;
			p.SaveSchedule = chckbxSaveSchedule.isSelected();

		}else{
			p.SaveOnClose = false;
			p.SaveSchedule = false;
		}
		p.SaveFileName = txtFileName.getText();
		
		p.TitanEfficiency = slide1.getValue() / 1000.;
		p.CustomEfficiency = slide2.getValue() / 1000.;
		p.GlobalEfficiency = slide3.getValue() / 1000.;
		
		dispose();
	}
	
	private void UpdateTimeOptions(){
		if(cmbMachineType.getSelectedItem().toString().equals("ER610")){
			PopulateTimings(p.timings.ER610_BASIC, p.timings.ER610_OPTNS);
		}else if(cmbMachineType.getSelectedItem().toString().equals("SR9-DS")){
			PopulateTimings(p.timings.SR9DS_BASIC, p.timings.SR9DS_OPTNS);
		}else if(cmbMachineType.getSelectedItem().toString().equals("SR9-DT")){
			PopulateTimings(p.timings.SR9DT_BASIC, p.timings.SR9DT_OPTNS);
		}else if(cmbMachineType.getSelectedItem().toString().equals("SR800")){
			PopulateTimings(p.timings.SR800_BASIC, p.timings.SR800_OPTNS);
		}else if(cmbMachineType.getSelectedItem().toString().equals("Custom")){
			PopulateTimings(p.timings.CUSTOM_BASIC, p.timings.CUSTOM_OPTNS);
		}
	}
	
	private void SaveTimings(){
		double[][] TimeGridBasic = {p.timings.ER610_BASIC, p.timings.SR9DS_BASIC, p.timings.SR9DT_BASIC, p.timings.SR800_BASIC, p.timings.CUSTOM_BASIC};
		double[][] TimeGridOpts  = {p.timings.ER610_OPTNS, p.timings.SR9DS_OPTNS, p.timings.SR9DT_OPTNS, p.timings.SR800_OPTNS, p.timings.CUSTOM_OPTNS};
		int index = 0;
		
		if(cmbMachineType.getSelectedItem().toString().equals("ER610")){
			index = 0;
		}else if(cmbMachineType.getSelectedItem().toString().equals("SR9-DS")){
			index = 1;
		}else if(cmbMachineType.getSelectedItem().toString().equals("SR9-DT")){
			index = 2;
		}else if(cmbMachineType.getSelectedItem().toString().equals("SR800")){
			index = 3;
		}else if(cmbMachineType.getSelectedItem().toString().equals("Custom")){
			index = 4;
		}

		for(int i=0; i < OperatorTimings.length; ++i){
			TimeGridBasic[index][i] = Double.parseDouble(TimingsBoxes1[i].getText());
			TimeGridOpts[index][i] = Double.parseDouble(TimingsBoxes2[i].getText());
		}
		
	}
	
	private void OpenPasswordDialog(){
		if(! p.Unlocked){
			PasswordDialog pw = new PasswordDialog(p);
			pw.addWindowListener(new WindowAdapter() {
			    @Override
			    public void windowClosed(WindowEvent e) {
			        UpdateLock();
			    }
			});
			pw.setVisible(true);
		}
	}	
	
	private void PopulateTimings(double[] basic, double[] opts){
		
		for(int i=0; i < OperatorTimings.length; ++i){
			TimingsBoxes1[i].setText(Double.toString(roundTwoDecimals(basic[i])));
			TimingsBoxes2[i].setText(Double.toString(roundTwoDecimals(opts[i])));
			if(m != null && cmbMachineType.getSelectedItem().toString().toLowerCase().equals(m.model.toString().toLowerCase())){
				if(! UpgradeSelected(m, i)){
					TimingsBoxes1[i].setBorder(new BevelBorder(BevelBorder.LOWERED, Color.GREEN, new Color(0, 102, 0), new Color(0, 102, 0), Color.GREEN));
					TimingsBoxes2[i].setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
				}else{
					TimingsBoxes2[i].setBorder(new BevelBorder(BevelBorder.LOWERED, Color.GREEN, new Color(0, 102, 0), new Color(0, 102, 0), Color.GREEN));
					TimingsBoxes1[i].setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
				}
			}else{
				TimingsBoxes1[i].setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
				TimingsBoxes2[i].setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
			}
		}
	}
	
	private boolean UpgradeSelected(Machine m, int textbox){
		boolean result = false;
		switch(textbox){
			case 0: // machine config
				if(m.model != Machine.Model.OTHER)
					result = true;
				break;
			case 1: // mother change
				
				break;
			case 2: // align mother
				if(m.alignment)
					result = true;
				break;
			case 3: // knife pos
				if(m.knives == Machine.Knives.AUTO)
					result = true;
				break;
			case 4: // splice
				if(m.splice_table || m.flags)
					result = true;
				break;
			case 5: // cut
				if(m.cutoff)
					result = true;
				break;
			case 6: // tape tail
				if(m.tapetail)
					result = true;
				break;
			case 7: // tape core
				if(m.tapecore)
					result = true;
				break;
			case 8: // load rewind
				
				break;
			case 9: // unload rewind
				if(m.autostrip)
					result = true;
				break;
			case 10: // align rewind
				if(m.corepos != Machine.Corepos.MANUAL)
					result = true;
				break;
			case 11: // change diam
				
				break;
			default: break;
		}
		return result;
	}
	
	private double roundTwoDecimals(double d) {
        DecimalFormat twoDForm = new DecimalFormat("#.##");
	    return Double.valueOf(twoDForm.format(d));
	}
}
