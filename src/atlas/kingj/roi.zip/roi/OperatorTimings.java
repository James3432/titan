package atlas.kingj.roi;

import java.io.Serializable;

public class OperatorTimings implements Serializable {
	
	/*   
	 * 
	 * Measured operator timings for each machine, with and without all options enabled.
	 * 
	 * All values are public to allow overriding from environment settings.
	 * 
	 * All times in seconds. Fractions are permitted.
	 *
	 */
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static int length = 12;
	
	// TODO as of 19/08/13, only sr9dt timings were actually measured
	
								   //    0           1             2          3         4           5            6                7            8            9             10           11
	                               // SetMachine  ChangeMother  AlignMother  KnifePos  FlagSplice  RewindCut  RewindTapeTail  RewindUnload  RewindLoad  RewindTapeCore  RewindAlign  ChangeDiam
	public double[] ER610_BASIC = {      20,         240,          150,         20,       300,         10,          4,             10,          6,          5,            6,      		300		};
	public double[] ER610_OPTNS = {      20,         240,          120,         3,        250,         10,          1,             5,           3,          1,            3,     		300		};
	
	public double[] SR9DS_BASIC = {      20,         240,          150,         20,       300,         10,          4,             11,          6,          4,            6,      		300		};
	public double[] SR9DS_OPTNS = {      20,         240,          120,         3,        260,         10,          1,             6,           3,          1,            3,      		300		};
	
	public double[] SR9DT_BASIC = {      20,         240,          150,         20,       300,         35,          2,             0,           0,          3,            0,      		300		};
	public double[] SR9DT_OPTNS = {      20,         240,          120,         3,        240,         35,          0,             0,           0,          0,            0,      		300		};
	
	public double[] SR800_BASIC = {      20,         240,          150,         20,       300,         10,          4,             12,          6,          5,            6,     		300		};
	public double[] SR800_OPTNS = {      20,         240,          120,         3,        260,         10,          1,             6,           3,          1,            3,      		300		};
	
	public double[] CUSTOM_BASIC = {     40,         300,          150,         20,       300,         10,          4,             12,          6,          4,            6,     		300		};
	public double[] CUSTOM_OPTNS = {     40,         300,          120,         3,        250,         10,          1,             6,           3,          2,            3,     		300		};
	
	
	// Backup default timings: these need to be manually kept up-to-date
	
	   									//    0           1             2          3         4           5            6                7            8            9             10           11
    									// SetMachine  ChangeMother  AlignMother  KnifePos  FlagSplice  RewindCut  RewindTapeTail  RewindUnload  RewindLoad  RewindTapeCore  RewindAlign  ChangeDiam
	private double[] ER610_BASIC_BACKUP = {      20,         240,          150,         20,       300,         10,          4,             10,          6,          5,            6,      		300		};
	private double[] ER610_OPTNS_BACKUP = {      20,         240,          120,         3,        250,         10,          1,             5,           3,          1,            3,     		300		};
	
	private double[] SR9DS_BASIC_BACKUP = {      20,         240,          150,         20,       300,         10,          4,             11,          6,          4,            6,      		300		};
	private double[] SR9DS_OPTNS_BACKUP = {      20,         240,          120,         3,        260,         10,          1,             6,           3,          1,            3,      		300		};
	
	private double[] SR9DT_BASIC_BACKUP = {      20,         240,          150,         20,       300,         35,          2,             0,           0,          3,            0,      		300		};
	private double[] SR9DT_OPTNS_BACKUP = {      20,         240,          120,         3,        240,         35,          0,             0,           0,          0,            0,      		300		};
	
	private double[] SR800_BASIC_BACKUP = {      20,         240,          150,         20,       300,         10,          4,             12,          6,          5,            6,     		300		};
	private double[] SR800_OPTNS_BACKUP = {      20,         240,          120,         3,        260,         10,          1,             6,           3,          1,            3,      		300		};
	
	private double[] CUSTOM_BASIC_BACKUP = {     40,         300,          150,         20,       300,         10,          4,             12,          6,          4,            6,     		300		};
	private double[] CUSTOM_OPTNS_BACKUP = {     40,         300,          120,         3,        250,         10,          1,             6,           3,          2,            3,     		300		};
	
	
	// Operations required for different types of changeover  (by index in above table)
	public int[] START =         { 0, 1, 2, 3                          };
	public int[] REEL_CHANGE =   { 5, 6, 7, 8, 9, 10                   };
	public int[] MOTHER_CHANGE = { 1, 2                                };
	public int[] JOB_CHANGE =    { 0, 3, 1, 2, 5, 6, 7, 8, 9, 10       };
	public int[] FLAG_SPLICE =   { 4                                   };
	public int[] FINISH =        { 5, 6, 7, 11                         };
	
	// Fixed, measured timings
	public static double efficiency = 0.95;
	   							
								   //    0           1             2          3         4           5            6                7            8            9             10           11
    							   // TotSetChange  ChangeMother  AlignMother  KnifePos  FlagSplice  Rewin
	public static double[] SR9DT = {     35                };
	// TODO SR9DS set change should be around 2.50, but obtain by adding up options in the above
	
	public void ResetTimes(Machine.Model model, boolean basic, boolean all){
		if(model == Machine.Model.ER610 || all){
			if(basic)
				ER610_BASIC = ER610_BASIC_BACKUP.clone();
			else
				ER610_OPTNS = ER610_OPTNS_BACKUP.clone();
		}
		if(model == Machine.Model.SR9DS || all){
			if(basic)
				SR9DS_BASIC = SR9DS_BASIC_BACKUP.clone();
			else
				SR9DS_OPTNS = SR9DS_OPTNS_BACKUP.clone();
		}
		if(model == Machine.Model.SR9DT || all){
			if(basic)
				SR9DT_BASIC = SR9DT_BASIC_BACKUP.clone();
			else
				SR9DT_OPTNS = SR9DT_OPTNS_BACKUP.clone();
		}
		if(model == Machine.Model.SR800 || all){
			if(basic)
				SR800_BASIC = SR800_BASIC_BACKUP.clone();
			else
				SR800_OPTNS = SR800_OPTNS_BACKUP.clone();
		}
		if(model == Machine.Model.OTHER || all){
			if(basic)
				CUSTOM_BASIC = CUSTOM_BASIC_BACKUP.clone();
			else
				CUSTOM_OPTNS = CUSTOM_OPTNS_BACKUP.clone();
		}
	}
	
	public double getJobChangeTime(Machine machine, int slits){
		Machine.Model mach = machine.model;
		double[] times = null;
		switch(mach){
			case ER610: times = BuildTimes(machine, ER610_BASIC, ER610_OPTNS, slits); break;
			case SR9DS: times = BuildTimes(machine, SR9DS_BASIC, SR9DS_OPTNS, slits); break;
			case SR9DT: times = BuildTimes(machine, SR9DT_BASIC, SR9DT_OPTNS, slits); break;
			case SR800: times = BuildTimes(machine, SR800_BASIC, SR800_OPTNS, slits); break;
			case OTHER: times = BuildTimes(machine, CUSTOM_BASIC, CUSTOM_OPTNS, slits); break;
		}
		double time = 0.;
		for(int i=0; i<JOB_CHANGE.length; ++i){
			time += times[JOB_CHANGE[i]];
		}
		return time;
	}
	public double getSetChangeTime(Machine machine, int slits){
		Machine.Model mach = machine.model;
		double[] times = null;
		switch(mach){
			case ER610: times = BuildTimes(machine, ER610_BASIC, ER610_OPTNS, slits); break;
			case SR9DS: times = BuildTimes(machine, SR9DS_BASIC, SR9DS_OPTNS, slits); break;
			case SR9DT: times = BuildTimes(machine, SR9DT_BASIC, SR9DT_OPTNS, slits); break;
			case SR800: times = BuildTimes(machine, SR800_BASIC, SR800_OPTNS, slits); break;
			case OTHER: times = BuildTimes(machine, CUSTOM_BASIC, CUSTOM_OPTNS, slits); break;
		}
		double time = 0.;
		for(int i=0; i<REEL_CHANGE.length; ++i){
			time += times[REEL_CHANGE[i]];
		}
		return time;
	}
	public double getMotherChangeTime(Machine machine, int slits){
		Machine.Model mach = machine.model;
		double[] times = null;
		switch(mach){
			case ER610: times = BuildTimes(machine, ER610_BASIC, ER610_OPTNS, slits); break;
			case SR9DS: times = BuildTimes(machine, SR9DS_BASIC, SR9DS_OPTNS, slits); break;
			case SR9DT: times = BuildTimes(machine, SR9DT_BASIC, SR9DT_OPTNS, slits); break;
			case SR800: times = BuildTimes(machine, SR800_BASIC, SR800_OPTNS, slits); break;
			case OTHER: times = BuildTimes(machine, CUSTOM_BASIC, CUSTOM_OPTNS, slits); break;
		}
		double time = 0.;
		for(int i=0; i<MOTHER_CHANGE.length; ++i){
			time += times[MOTHER_CHANGE[i]];
		}
		return time;
	}
	public double getSpliceTime(Machine machine, int slits){
		Machine.Model mach = machine.model;
		double[] times = null;
		switch(mach){
			case ER610: times = BuildTimes(machine, ER610_BASIC, ER610_OPTNS, slits); break;
			case SR9DS: times = BuildTimes(machine, SR9DS_BASIC, SR9DS_OPTNS, slits); break;
			case SR9DT: times = BuildTimes(machine, SR9DT_BASIC, SR9DT_OPTNS, slits); break;
			case SR800: times = BuildTimes(machine, SR800_BASIC, SR800_OPTNS, slits); break;
			case OTHER: times = BuildTimes(machine, CUSTOM_BASIC, CUSTOM_OPTNS, slits); break;
		}
		double time = 0.;
		for(int i=0; i<FLAG_SPLICE.length; ++i){
			time += times[FLAG_SPLICE[i]];
		}
		return time;
	}
	
	private double[] BuildTimes(Machine m, double[] basic, double[] optns, int slits){
		double[] result = new double[basic.length];
		
		//SetMachine  
		result[0] = basic[0];
		//ChangeMother  
		result[1] = basic[1];
		//AlignMother  
		if(m.alignment)
			result[2] = optns[2];
		else
			result[2] = basic[2];
		//KnifePos  
		int knives = slits + 1;
		if(m.knives == Machine.Knives.AUTO)
			result[3] = optns[3] * knives;
		if(m.knives == Machine.Knives.STACKED)
			result[3] = basic[3] * knives;
		if(m.knives == Machine.Knives.INFLATABLE)
			result[3] = basic[3] * knives;
		//FlagSplice 
		if(m.splice_table || m.flags)
			result[4] = optns[4];
		else
			result[4] = basic[4];
		//RewindCut  
		int cores = slits;
		if(m.cutoff)
			result[5] = optns[5] * cores;
		else
			result[5] = basic[5] * cores;
		//RewindTapeTail  
		if(m.tapetail)
			result[6] = optns[6] * cores;
		else
			result[6] = basic[6] * cores;
		//RewindUnload  
		if(m.unloader==Machine.Unloader.ELECTRIC || m.autostrip)
			result[7] = optns[7] * cores;
		else
			result[7] = basic[7] * cores;
		//RewindLoad  
		if(m.corepos == Machine.Corepos.SERVO)
			result[8] = optns[8] * cores;
		if(m.corepos == Machine.Corepos.LASER)
			result[8] = optns[8] * cores;
		if(m.corepos == Machine.Corepos.MANUAL)
			result[8] = basic[8] * cores;
		//RewindTapeCore  
		if(m.tapecore)
			result[9] = optns[9] * cores;
		else
			result[9] = basic[9] * cores;
		//RewindAlign
		result[10] = basic[10] * cores;
		//ChangeDiam
		result[11] = basic[11];
		
		return result;
	}
	
}
