package atlas.kingj.roi;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import atlas.kingj.roi.ResultSet.ResultTime;
import atlas.kingj.roi.ResultSet.ResultType;

/*
 *  Class to compare machine setups given job and production details
 */
public class Comparator {

	//private JFreeChart graph;
	//private JFreeChart timingGraph;
	private JobSchedule schedule;
	private ResultSet results;
	private CategoryDataset dataset;
	private Production prod; // Needed for interpretation of results over different scales of analysis
	private int MODEL_VERSION;
	
	public Comparator(Machine m[], Production p, int model){
		super();
		
		schedule = p.getSchedule();
		
		if(schedule.getSize() < 1)
			return;
		
		results = new ResultSet();
		for(int i=0; i<m.length; ++i){
			results.add(results.new Result(m[i].name));
		}
		
		MODEL_VERSION = model;
		prod = p;
		// dataset for 1 run under job #1
		dataset = compute(m, schedule, p.timings);
		
		results.HrsPerDay = p.HrsPerDay;
		results.HrsPerWeek = p.HrsPerWeek;
		results.HrsPerYear = p.HrsPerYear;
		results.HrsPerShift = p.HrsPerShift;
		
		// TODO graph labels need changing, and make each graph type, imperial units graphs??
		results.setTimeGraph(ChartFactory.createBarChart("Production Time Comparison", "Machine", "Time / schedule (hrs)", dataset, PlotOrientation.VERTICAL, true, true, false));
		results.setEffGraph(ChartFactory.createBarChart("Efficiency Comparison", "Machine", "Efficiency (%)", results.CreateDataset(results, ResultType.EFF, ResultTime.HOUR), PlotOrientation.VERTICAL, true, true, false));
		results.setProdGraph(ChartFactory.createBarChart("Productivity Comparison", "Machine", "Length / year (km)", results.CreateDataset(results, ResultType.LENGTH, ResultTime.YEAR), PlotOrientation.VERTICAL, true, true, false));
		results.setRateGraph(ChartFactory.createBarChart("Production Rate Comparison", "Machine", "Metres / hour (m/hr)", results.CreateDataset(results, ResultType.LENGTH, ResultTime.HOUR), PlotOrientation.VERTICAL, true, true, false));
		results.setProdWGraph(ChartFactory.createBarChart("Productivity Comparison", "Machine", "Weight / year (tonnes)", results.CreateDataset(results, ResultType.WEIGHT, ResultTime.YEAR), PlotOrientation.VERTICAL, true, true, false));
		results.setRateWGraph(ChartFactory.createBarChart("Production Rate Comparison", "Machine", "Weight / hour (kg)", results.CreateDataset(results, ResultType.WEIGHT, ResultTime.HOUR), PlotOrientation.VERTICAL, true, true, false));
		
		//CategoryPlot plot = graph.getCategoryPlot();
		/*plot.setBackgroundPaint(Color.lightGray);
		plot.setDirection(Rotation.CLOCKWISE);
		plot.setForegroundAlpha(0.5f);*/
	}
	
	private CategoryDataset compute(Machine m[], JobSchedule js, OperatorTimings times){
		
		DefaultCategoryDataset data = new DefaultCategoryDataset();
		String series1 = "Time";
		
		int jobCount = js.getSize();
		
		// FOR TIMING
		XYSeries[] timeDataSeries = new XYSeries[m.length];
        final XYSeriesCollection timeData = new XYSeriesCollection();

        // Foreach machine
		for(int i=0; i<m.length; ++i){
			
			double vMach = m[i].getSpeed();
			
			double time = 0.;
			double idealTime = 0.;
			
			timeDataSeries[i] = new XYSeries(m[i].name);
			
			// Foreach job
			for(int j=0; j<jobCount; ++j){
				
				Job job = js.getJob(j);
			
				double vLimit = 0, vFinal = 0;
				
				// reset vmach in case only some jobs have speed limits
				vMach = m[i].getSpeed();
				
				if(job.isSpeedLimited() && job.getSpeedLimitSI() < vMach)
					vMach = job.getSpeedLimitSI();
				
				// TODO: this needs updating for v2.
				if(MODEL_VERSION == 1)
					vLimit = Core.getLimitingVelocity(job.getRewindLengthSI(), m[i].getAccel(), m[i].getDecel());
				if(MODEL_VERSION == 2)
					vLimit = Core.getLimitingVelocityV2(job.getRewindLengthSI(), vMach, m[i].getAccel(), m[i].getDecel(), m[i].max_rewind_rps, m[i].max_unwind_rps, job.getThicknessSI(), job.getRewindCoreSI(), job.getUnwindCoreSI(), job.getUnwindLengthSI());
	
				//System.out.println("vLimit: "+vLimit);
				
				vFinal = Core.getMaxVelocity(vMach, vLimit);
				//System.out.println("vFinal: "+vFinal);
				// Get run time of machine for a single set
				DataPoint[] res = null;
				if(MODEL_VERSION == 1)
					res = Core.MachineRunTime(job.getRewindLengthSI(), vFinal, m[i].getAccel(), m[i].getDecel());
				else if(MODEL_VERSION == 2)
					res = Core.MachineRunTimeV2(job.getRewindLengthSI(), vFinal, m[i].getAccel(), m[i].getDecel(), m[i].max_rewind_rps, m[i].max_unwind_rps, job.getThicknessSI(), job.getRewindCoreSI(), job.getUnwindCoreSI(), job.getUnwindLengthSI());
				//time = res[res.length - 1].x;
				
				/////  Changes for job scheduling: timeData is for run timing: we only need to change the value of time here.
				time += Core.JobRunTime(m[i], job, vMach, times, true);
				idealTime += Core.JobRunTime(m[i], job, vMach, times, false);
				
				if(j < jobCount - 1) // if not last job
					time += prod.timings.getJobChangeTime(m[i], job.getSlits()); // add job changeover delay
				
				// !!!!! TODO: add on in-between-job times, move data.addValue to outer loop
				
				///// End of changes
				// TODO: don't wan't to calculate timeData for every job... move out of loop
				
				//String name =  m[i].model.toString() +": "+ m[i].name;
				//String category1 = testMachine.model.toString() +": "+ testMachine.name;
				//data.addValue(time, series1, name);
	
				if(j==0){
					//// TIMING DATA (first job only)
					for(int z=0; z<res.length; ++z){
						DataPoint dp = res[z];
						timeDataSeries[i].add(dp.x, dp.y);
					}
				}
				
			}
			
			// TODO time measured in s, but results in hrs
			results.get(i).ScheduleTime = time / 3600;
			results.get(i).ScheduleLength = js.getTotalLength();
			results.get(i).ScheduleWeight = js.getTotalWeight();
			results.get(i).IdealMtPerHour = 3600 * js.getTotalLength() / idealTime;
			results.get(i).MtPerHour = 3600 * js.getTotalLength() / time;
			
			String name =  m[i].model.toString() +": "+ m[i].name;
			data.addValue(time / 3600, series1, name);
			
			timeData.addSeries(timeDataSeries[i]);
			
		}
		
		//// DRAW TIMING DIAGRAM
		final JFreeChart chart = ChartFactory.createXYLineChart(
	            "Machine Run Timing Diagram",    // chart title
	            "Time to run " + js.getJob(0).getRewindLengthSI() + "m (s)",   // x axis label
	            "Linear Speed (m/s)",            // y axis label
	            timeData,                        // data
	            PlotOrientation.VERTICAL,
	            true,                            // include legend
	            true,                            // tooltips
	            false                            // urls
	        );
		
		results.setTimingGraph(chart);
		
		return data;
	}
	
	//public JFreeChart getGraph()        { return graph;       }
	//public JFreeChart getTimings()      { return timingGraph; }
	public CategoryDataset getDataset() { return dataset;     }
	public ResultSet getResults()       { return results;     }
	public Production getProd()         { return prod;        }

	// TODO: this is replaced by ResultSet class
	/*class Numerics {
		double TonsPerDay;
		double LengthPerDay;
		TimeDomain frequency;
		public Numerics(double tpd, double lpd, TimeDomain t){
			TonsPerDay = tpd;
			LengthPerDay = lpd;
			frequency = t;
		}
	}
*/
	
	/*
	 *  BACKUP OF COMPUTE FUNCTION, 13/08/2013
	 * 
	private CategoryDataset compute(Machine m[], JobSchedule js, Production p){
		
		Job j = js.getJob(0);
		
		DefaultCategoryDataset data = new DefaultCategoryDataset();
		String series1 = "Time";
		
		// FOR TIMING
		XYSeries[] timeDataSeries = new XYSeries[m.length];
        final XYSeriesCollection timeData = new XYSeriesCollection();

		for(int i=0; i<m.length; ++i){
			
			double vMach = m[i].speed.speed;
			double vLimit = 0, vFinal = 0;
			
			if(j.isSpeedLimited() && j.getSpeedLimitSI() < vMach)
				vMach = j.getSpeedLimitSI();
			
			// TODO: this needs updating for v2.
			if(MODEL_VERSION == 1)
				vLimit = Core.getLimitingVelocity(j.getRewindLengthSI(), m[i].accel, m[i].decel);
			if(MODEL_VERSION == 2)
				vLimit = Core.getLimitingVelocityV2(j.getRewindLengthSI(), vMach, m[i].accel, m[i].decel, m[i].max_rewind_rps, m[i].max_unwind_rps, j.getThicknessSI(), j.getRewindCoreSI(), j.getUnwindCoreSI(), j.getUnwindLengthSI());

			//System.out.println("vLimit: "+vLimit);
			
			vFinal = Core.getMaxVelocity(vMach, vLimit);
			//System.out.println("vFinal: "+vFinal);
			// Get run time of machine for a single set
			DataPoint[] res = null;
			if(MODEL_VERSION == 1)
				res = Core.MachineRunTime(j.getRewindLengthSI(), vFinal, m[i].accel, m[i].decel);
			else if(MODEL_VERSION == 2)
				res = Core.MachineRunTimeV2(j.getRewindLengthSI(), vFinal, m[i].accel, m[i].decel, m[i].max_rewind_rps, m[i].max_unwind_rps, j.getThicknessSI(), j.getRewindCoreSI(), j.getUnwindCoreSI(), j.getUnwindLengthSI());
			double time = res[res.length - 1].x;
			
			// Simple model: add additional time for less automated machines
			if(m[i].model.toString().equals("ER610") || m[i].model.toString().equals("Other"))
				time += p.TimeLoad;
			
			String name =  m[i].model.toString() +": "+ m[i].name;
			//String category1 = testMachine.model.toString() +": "+ testMachine.name;
			data.addValue(time, series1, name);
			
			
			//// TIMING DATA
			timeDataSeries[i] = new XYSeries(name);
			
			for(int z=0; z<res.length; ++z){
				DataPoint dp = res[z];
				timeDataSeries[i].add(dp.x, dp.y);
			}
			
			/*timeDataSeries[i].add(0.0, 0.0);
			timeDataSeries[i].add(Core.MachineRunTimeT1(j.RewindLength, vFinal, p.accel, p.decel), vFinal);
			timeDataSeries[i].add(Core.MachineRunTimeT2(j.RewindLength, vFinal, p.accel, p.decel), vFinal);
			timeDataSeries[i].add(time, 0.0);*/
		/*	
	        timeData.addSeries(timeDataSeries[i]);

		}
		
		//// DRAW TIMING DIAGRAM
		final JFreeChart chart = ChartFactory.createXYLineChart(
	            "Machine Run Timing Diagram",    // chart title
	            "Time (s)",                      // x axis label
	            "Linear Speed (m/s)",            // y axis label
	            timeData,                        // data
	            PlotOrientation.VERTICAL,
	            true,                            // include legend
	            true,                            // tooltips
	            false                            // urls
	        );
		
		timingGraph = chart;*/
		/*JFrame popGraph = new JFrame();
		
		ChartPanel cpanel = new ChartPanel(chart);
		cpanel.setPreferredSize(new java.awt.Dimension(500, 300));
		popGraph.setContentPane(cpanel);
		try{
		popGraph.setIconImage(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/logo.png")));
		}catch(NullPointerException e11){
			System.out.println("Image load error");
		} catch (IOException e) {
			e.printStackTrace();
		}
		popGraph.setTitle("Timing Diagram");
		popGraph.setSize(450, 300);
		
		popGraph.pack();
		popGraph.setVisible(true);
		popGraph.setLocationRelativeTo(null);*/
		//// END TIMING DIAGRAM
		
		/*results = new Numerics(0, 0, TimeDomain.Reel);
		
		return data;*/
	//}

}
