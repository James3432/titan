package atlas.kingj.roi;

import java.io.Serializable;

/*
 *  Class to represent machine instances in particular configurations.
 */
public class Machine implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private boolean custom = false;
	private CustomMachine customMach = null;
	
	public boolean isCustom(){ return custom; }
	public void setCustom(boolean f){ custom = f; }
	public CustomMachine getCustomMachine(){ return customMach; }
	public void setCustomMachine(CustomMachine c){ customMach = c; }

	// Model of machine
	public enum Model{
    	ER610("ER610"), SR9DS("SR9-DS"), SR9DT("SR9-DT"), SR800("SR800"), OTHER("Other");
    	String m;
    	Model(String m){
    		this.m = m;
    	}
    	public String toString(){
    		return m;
    	}
    }
	
	// Machine max speed
	public enum Speed {
		A(450), B(550), C(1000);
		double speed;
		double orig_speed;
		Speed(int a){
			speed = a * Consts.MIN_TO_S;
			orig_speed = a;
		}
		public String toString(){
    		return Double.toString(orig_speed);
    	}
	}
	
	public double max_rewind_rps = 1200. / 60; // TODO work out where to set these, and may need to be set for "other" machines
	public double max_unwind_rps = 1267. / 60;
	
	// Knife setup
	public enum Knives {
		AUTO("Auto"), INFLATABLE("Manual (Inflatable)"), STACKED("Manual (Stacked)");
		String s;
		Knives(String s){ this.s = s; }
		public String toString(){  return s; }
	}
	
	// Core positioning system
	public enum Corepos {
		MANUAL, LASER, SERVO
	}
	
	// Reel unloader mechanism
	public enum Unloader {
		MANUAL, PNEUMATIC, ELECTRIC
	}
	
	// Unwind motors
	public enum Unwind {
		SINGLE, DOUBLE
	}
	
	// Rewind control loop
	public enum Rewind {
		OPEN, CLOSED
	}
	
	// VARIANTS
	
	public Model model;
	public Speed speed;
	public Knives knives;
	public Corepos corepos;
	public Unloader unloader;
	public Unwind unwind;
	public Rewind rewind;
	
	// OPTIONS
	
	// Splice table
	public boolean splice_table;
	// Auto alignment guide
	public boolean alignment;
	// Roll conditioning (ovular correction)
	public boolean roll_cond;
	// Turret support (FOR SR9-DT ONLY)
	public boolean turret;
	// Auto reel removal
	public boolean autostrip;
	// Flag detection camera
	public boolean flags;
	// Auto cut-off at reels
	public boolean cutoff;
	// Auto taping of core
	public boolean tapecore;
	// Auto taping of tail (end of reel)
	public boolean tapetail;
	// 850mm rewind diameter support
	public boolean extrarewind;
	
	public double accel = 10./60;
	public double decel = 10./60;
	
	// User-given name for this machine instance
	public String name;
	
	public Machine() {
		super();
	}
	
	public Machine(String n) {
		super();
		name = n;
		model = Model.ER610;
		knives = Knives.AUTO;
		corepos = Corepos.MANUAL;
		unloader = Unloader.MANUAL;
		unwind = Unwind.SINGLE;
		rewind = Rewind.CLOSED;
		speed = Speed.A;
	}
	
	public Machine(String n, Model m, String spd, String k, String c, String u, String uw, String r, boolean[] options) {
		super();
		
		name = n;
		//TODO add null cases for ""
		model = m;
		speed = (spd.equals("450") ? Speed.A : (spd.equals("550") ? Speed.B : (spd.equals("1000") ? Speed.C : null)));
		knives = (k.equals("Auto") ? Knives.AUTO : (k.equals("Manual (Stacked)") ? Knives.STACKED : (k.equals("Manual (Inflatable)") ? Knives.INFLATABLE : null)));
		corepos = (c.equals("Manual") ? Corepos.MANUAL : (c.equals("Laser") ? Corepos.LASER : (c.equals("Servo") ? Corepos.SERVO : null)));
		unloader = (u.equals("Manual") ? Unloader.MANUAL : (u.equals("Electric") ? Unloader.ELECTRIC : (u.equals("Pneumatic") ? Unloader.PNEUMATIC : null)));
		unwind = (uw.equals("Single") ? Unwind.SINGLE :  (uw.equals("Double") ? Unwind.DOUBLE : null));
		rewind = (r.equals("Open") ? Rewind.OPEN : (r.equals("Closed") ? Rewind.CLOSED : null));
		
		splice_table = options[0];
		alignment = options[1];
		roll_cond = options[2];
		turret = options[3];
		autostrip = options[4];
		flags = options[5];
		cutoff = options[6];
		tapecore = options[7];
		tapetail = options[8];
		extrarewind = options[9];
	}
	
	public Machine(String n, Model m, Speed spd, Knives k, Corepos c, Unloader u, Unwind uw, Rewind r, boolean[] options) {
		super();
		
		name = n;
		
		model = m;
		speed = spd;
		knives = k;
		corepos = c;
		unloader = u;
		unwind = uw;
		rewind = r;
		
		splice_table = options[0];
		alignment = options[1];
		roll_cond = options[2];
		turret = options[3];
		autostrip = options[4];
		flags = options[5];
		cutoff = options[6];
		tapecore = options[7];
		tapetail = options[8];
		extrarewind = options[9];
	}
	
	public Machine(String n, CustomMachine m){
		super();
		
		name = n;
		model = Model.OTHER;
		custom = true;
		customMach = m;
	}
	
	public double getSpeed(){
		if(custom && customMach != null)
			return customMach.speed;
		else
			return speed.speed;
	}
	public double getAccel(){
		if(custom && customMach != null)
			return customMach.accel;
		else
			return accel;
	}
	public double getDecel(){
		if(custom && customMach != null)
			return customMach.accel; //TODO approximation
		else
			return decel;
	}
	
	public void update(String n, Model m, String spd, String k, String c, String u, String uw, String r, boolean[] options) {
		name = n;
		//TODO add null cases for ""
		model = m;
		speed = (spd.equals("450") ? Speed.A : (spd.equals("550") ? Speed.B : (spd.equals("1000") ? Speed.C : null)));
		knives = (k.equals("Auto") ? Knives.AUTO : (k.equals("Manual (Stacked)") ? Knives.STACKED : (k.equals("Manual (Inflatable)") ? Knives.INFLATABLE : null)));
		corepos = (c.equals("Manual") ? Corepos.MANUAL : (c.equals("Laser") ? Corepos.LASER : (c.equals("Servo") ? Corepos.SERVO : null)));
		unloader = (u.equals("Manual") ? Unloader.MANUAL : (u.equals("Electric") ? Unloader.ELECTRIC : (u.equals("Pneumatic") ? Unloader.PNEUMATIC : null)));
		unwind = (uw.equals("Single") ? Unwind.SINGLE :  (uw.equals("Double") ? Unwind.DOUBLE : null));
		rewind = (r.equals("Open") ? Rewind.OPEN : (r.equals("Closed") ? Rewind.CLOSED : null));
		
		splice_table = options[0];
		alignment = options[1];
		roll_cond = options[2];
		turret = options[3];
		autostrip = options[4];
		flags = options[5];
		cutoff = options[6];
		tapecore = options[7];
		tapetail = options[8];
		extrarewind = options[9];
	}
	
	// Provide a toString() method so we can display machines neatly in a list
	@Override
	public String toString(){
		String mod = "";
		switch (model) {
			case ER610: mod = "ER610";
				break;
			case SR9DS: mod = "SR9-DS";
				break;
			case SR9DT: mod = "SR9-DT";
				break;
			case SR800: mod = "SR800";
				break;
			case OTHER: mod = "Other";
				break;
			default: mod = "Other";
				break;
		}
		return mod + ": " + name;
	}
	
	public class CustomMachine implements Serializable {
		
		private static final long serialVersionUID = 1L;
		String descriptor;
		double speed;
		double accel;
		double change_mother;
		double change_job;
		double change_diam;
		double splice;
		double align_rewind;
		                    // SettingRecall FlagDetect AutoTape AutoTapeCore DualTurret AutoCut  AutoLoad AutoUnload  DiffRewind LockCore QuickLock SlessUnwind 
		boolean[] options = {    false,        false,     false,    false,      false,    false,    false,   false,      false,    false,    false,     false    };
		
		public CustomMachine(){
			descriptor = "Custom Machine";
			speed = 500. /60;
			accel = 10. /60;
			change_mother = 300;
			change_job = 300;
			change_diam = 300;
			splice = 300;
			align_rewind = 50;
		}
	}
	
}