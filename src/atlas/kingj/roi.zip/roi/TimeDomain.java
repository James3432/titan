package atlas.kingj.roi;

public enum TimeDomain {
	Reel, Set, Shift, Day, Week, Year
}
