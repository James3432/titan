package atlas.kingj.roi;

import java.util.LinkedList;
import java.util.List;

import org.jfree.chart.JFreeChart;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;

public class ResultSet {
	// TODO: what about units, and different time scales, and the choice of length, weight, etc.?
	private List<Result> results;
	public boolean isError;
	public String ErrorMsg;
	
	// Charts
	private JFreeChart timeGraph;      // Time/schedule
	private JFreeChart productGraph;   // Length/year
	private JFreeChart productWGraph;  // Weight/year
	private JFreeChart rateGraph;      // Length/hour
	private JFreeChart rateWGraph;     // Weight/hour
	private JFreeChart efficiencyGraph;// Efficiency
	private JFreeChart RunTimings;     // Detailed timing diagram for 1 run
	
	// Seconds per time unit, from the environment settings
	public double HrsPerShift;
	public double HrsPerDay;
	public double HrsPerWeek;
	public double HrsPerYear;
	
	public ResultSet(){
		results = new LinkedList<Result>();
	}
	public ResultSet(Result r){
		results = new LinkedList<Result>();
		results.add(r);
	}
	
	public void add(Result r){
		results.add(r);
	}
	
	public Result get(int i){
		return results.get(i);
	}
	
	public int getSize(){
		return results.size();
	}
	
	public CategoryDataset CreateDataset(ResultSet results, ResultType type, ResultTime time){
		DefaultCategoryDataset data = new DefaultCategoryDataset();
		String series1 = "Time";
		double val = 0.;
		String name = "";
		for(int i=0; i < results.getSize(); ++i){
			// TODO if all values > 10000, div by 1000
			
			/*switch(type){
			case EFF:
				break;
			case LENGTH: switch(time){ case YEAR: break; case HOUR: break; default: break; }
				break;
			case WEIGHT: switch(time){ case YEAR: break; case HOUR: break; default: break; }
				break;
			default:
				break;
			}*/
			
			val = results.get(i).getResult(type, time);
			
			if(time == ResultTime.YEAR)
				val = val / 1000;
			
			name = results.get(i).getName();
			data.addValue(val, series1, name);
		}
		return data;
	}
	
	public List<Result> getList(){ return results; }
	public JFreeChart getTimeGraph(){ return timeGraph; }
	public JFreeChart getProdGraph(){ return productGraph; }
	public JFreeChart getProdWGraph(){ return productWGraph; }
	public JFreeChart getRateGraph(){ return rateGraph; }
	public JFreeChart getRateWGraph(){ return rateWGraph; }
	public JFreeChart getEffGraph(){ return efficiencyGraph; }
	public JFreeChart getTimingGraph(){ return RunTimings; }
	public void setTimeGraph(JFreeChart g){ timeGraph = g; }
	public void setProdGraph(JFreeChart g){ productGraph = g; }
	public void setProdWGraph(JFreeChart g){ productWGraph = g; }
	public void setRateGraph(JFreeChart g){ rateGraph = g; }
	public void setRateWGraph(JFreeChart g){ rateWGraph = g; }
	public void setEffGraph(JFreeChart g){ efficiencyGraph = g; }
	public void setTimingGraph(JFreeChart g){ RunTimings = g; }
	
	public class Result {
		private String MachineName;
		
		public double ScheduleLength; // m
		public double ScheduleTime;   // hrs
		public double ScheduleWeight; // kg
		
		public double MtPerHour;
		public double IdealMtPerHour; //TODO
		//private double KgPerHour;
		
		//private double AvgLengthPerRun;
		//private double AvgTimePerRun;
		
		public String getName(){ return MachineName; }
		
		public Result(String MachineName){
			this.MachineName = MachineName;
		}
		
		public double getResult(ResultType type, ResultTime time){
			double res = 0.;
			
			switch(type){
				case LENGTH: res = TimeScale(ScheduleLength, time); break;
				case WEIGHT: res = TimeScale(ScheduleWeight, time); break;
				case RATE: res = MtPerHour; break;
				case EFF: res = (IdealMtPerHour==0 ? 0 : 100 * MtPerHour / IdealMtPerHour); break;
			}
			
			return res;
		}
		
		private double TimeScale(double quant, ResultTime time){
			double res = 0.;
			
			if(ScheduleTime > 0){
				switch(time){
					case SCHEDULE: res = quant; break;
					case YEAR: res = HrsPerYear * quant / ScheduleTime; break;
					case HOUR: res = quant / ScheduleTime; break;
					case SHIFT: res = HrsPerShift * quant / ScheduleTime; break;
					case DAY: res = HrsPerDay * quant / ScheduleTime; break;
					case WEEK: res = HrsPerWeek * quant / ScheduleTime; break;
				}
			}
			
			return res;
		}
	}
	
	public enum ResultType {
		LENGTH, WEIGHT, RATE, EFF
	}
	
	public enum ResultTime {
		SCHEDULE, YEAR, HOUR, SHIFT, DAY, WEEK
	}
}
