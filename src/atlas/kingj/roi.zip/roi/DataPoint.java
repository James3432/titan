package atlas.kingj.roi;

public class DataPoint {
	double x;
	double y;
	public DataPoint(double x, double y){
		this.x = x;
		this.y = y;
	}
}