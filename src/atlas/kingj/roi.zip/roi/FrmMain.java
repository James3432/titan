package atlas.kingj.roi;

import java.awt.AWTEvent;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.HashSet;
import java.util.Set;

import javax.imageio.ImageIO;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.DefaultListSelectionModel;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.border.BevelBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.filechooser.FileFilter;

import org.apache.commons.lang3.text.WordUtils;
import org.eclipse.wb.swing.FocusTraversalOnArray;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;

import atlas.kingj.roi.JobSchedule.JobItem;
import atlas.kingj.roi.ResultSet.Result;
import atlas.kingj.roi.ResultSet.ResultTime;
import atlas.kingj.roi.ResultSet.ResultType;

/*
 *  Main class for the Titan ROI Calculator
 */
public class FrmMain {

	private JFrame frmTitanRoiCalculator;
	/**
	 * @wbp.nonvisual location=42,549
	 */
	private final ButtonGroup btnsUnits = new ButtonGroup();
	private final ButtonGroup rdbtnsMachines = new ButtonGroup();
	private final ButtonGroup rdbtnsModel = new ButtonGroup();
	
	private boolean metric = true;
	
	private boolean formReady = false;
	private boolean jobFormReady = false;
	
	Set<String> machNames;
	Set<String> jobNames;

	private JButton btnMachDelete;
	public JRadioButton rdbtnER610;
	public JTextField txtMachName;
	private JLabel lblMachName;
	public JCheckBox chckbxFlag;
	public JComboBox cmbCorepos;
	public JComboBox cmbKnives;
	private JLabel lblKnifeControl;
	private JLabel lblCorePositioning;
	public JCheckBox chckbxSpliceTable;
	public JCheckBox chckbxAlignmentGuide;
	public JCheckBox chckbxRollConditioning;
	public JCheckBox chckbxTurretSupport;
	public JCheckBox chckbxAutostripping;
	public JCheckBox chckbxExtraRewind;
	public JCheckBox chckbxAutoCutoff;
	public JCheckBox chckbxAutoTapeCore;
	public JCheckBox chckbxAutoTapeTail;
	public JComboBox cmbUnloader;
	private JLabel lblUnloader;
	public JComboBox cmbUnwindDrive;
	private JLabel lblUnwindDrive;
	public JComboBox cmbRewindCtrl;
	private JLabel lblRewindControlLoop;
	private JLabel lblSpeed;
	public JComboBox cmbSpeed;
	private JPanel pnlResults;
	private JPanel pnlProdGraph;
	JList listMachines;
	private JButton btnMachUp;
	private JButton btnMachDown;
	private JButton btnMachReset;
	public JRadioButton rdbtnSR9DS;
	public JRadioButton rdbtnSR9DT;
	private JPanel grpMachines;
	private JPanel grpVariants;
	private JPanel grpOptions;
	private JButton btnCustomMachine;
	
	OBJfilter objfilter;
	
	DefaultListModel jobModel;
	DefaultListModel listModel;
	DefaultListModel scheduleModel;
	
	public int MODEL_VERSION = 2;
	
	ChartPanel pnlGraph;
	JFreeChart chart;
	DefaultPieDataset dataset;
	
	int oldUnwindIndex = 0;
	int oldRewindIndex = 0;
	int oldTotalsIndex = 0;
	int SetReelType = 0;
	int jobIndex = 0;
	int oldMachineIndex = 0;
	
	Comparator comp;
	Job job;
	Production environment;
	ResultSet results;
	
	Machine machine;
	
	JFileChooser fc = new JFileChooser(){
	    /**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		@Override
	    public void approveSelection(){
	        File f = getSelectedFile();
	        if((f.exists() || addExt(f,".png").exists() || addExt(f,".ser").exists()) && getDialogType() == SAVE_DIALOG){
	            int result = JOptionPane.showConfirmDialog(this,"The file already exists, overwrite?","Existing file",JOptionPane.YES_NO_CANCEL_OPTION);
	            switch(result){
	                case JOptionPane.YES_OPTION:
	                    super.approveSelection();
	                    return;
	                case JOptionPane.NO_OPTION:
	                    return;
	                case JOptionPane.CLOSED_OPTION:
	                    return;
	                case JOptionPane.CANCEL_OPTION:
	                    cancelSelection();
	                    return;
	            }
	        }
	        super.approveSelection();
	    }
	};

	Machine.Model model = Machine.Model.ER610;
	
	private JLabel lblOutputLength;
	private JLabel lblOutputWeight;
	JLabel lblStatus;
	public JComboBox cmbMaterials;
	private JLabel lblPresets;
    public JLabel lblmmin;
	private JLabel lblThickness_1;
	private JLabel lblDensity_1;
	public JTextField txtThickness;
	public JTextField txtDensity;
	private JPanel pnlUnwinds;
	public JTextField txtUnwindAmount;
	private JLabel lblSlitCount;
	private JLabel lblTrimtotal;
	public JTextField txtSlits;
	public JTextField txtSlitWidth;
	public JTextField txtRewindAmount;
	public JLabel lblTrim;
	public JTextField txtShiftLength;
	public JTextField txtShiftCount;
	public JTextField txtDaysYear;
	public JLabel lblDaysPerWeek;
	public JTextField txtDaysWeek;
	public JComboBox cmbTimeRef;
	public JLabel lblPer;
	public JMenu mnModel;
	public JRadioButtonMenuItem rdbtnmntmPrototype;
	public JRadioButtonMenuItem rdbtnmntmStandard;
	public JRadioButtonMenuItem rdbtnmntmAdvanced;
	public JLabel lblWebWidthmm;
	public JLabel lblRewindCoremm;
	public JComboBox cmbRewindCore;
	public JLabel lblUnwindCoremm;
	public JComboBox cmbUnwindCore;
	private JLabel lblmicro0;
	private JLabel lblgm3;
	private JLabel label_3;
	private JLabel lblPer_1;
	public JComboBox cmbJobDomain;
	private JLabel lblmm3;
	private JLabel lblmm2;
	private JLabel lblmm0;
	private JLabel lblmm1;
	private JLabel lblDayLength2;
	private JLabel lblHoursYear;
	private JLabel lblHoursYear2;
	public JLabel lblHrs;
	public JList listCompare;
	public JLabel picLabel;
	
	private static FrmMain window;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		} catch (Throwable e) {
			e.printStackTrace();
		}
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					window = new FrmMain();
					window.frmTitanRoiCalculator.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public FrmMain() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		 		
		frmTitanRoiCalculator = new JFrame();
		frmTitanRoiCalculator.setFont(new Font("Arial", Font.ITALIC, 7));
		frmTitanRoiCalculator.addWindowListener(new FrmTitanRoiCalculatorWindowListener());
		frmTitanRoiCalculator.setResizable(false);
		frmTitanRoiCalculator.setTitle("Titan ROI Calculator");
		try{
			frmTitanRoiCalculator.setIconImage(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/logo.png")));//Toolkit.getDefaultToolkit().getImage(FrmMain.class.getResource("/atlas/logo.png")));
		}catch(NullPointerException e){
			System.out.println("Image load error");
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		frmTitanRoiCalculator.setBounds(100, 100, 800, 600);
		frmTitanRoiCalculator.setLocationRelativeTo(null);
		frmTitanRoiCalculator.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JMenuBar menuBar = new JMenuBar();
		frmTitanRoiCalculator.setJMenuBar(menuBar);
		
		JMenu mnFile = new JMenu("File");
		mnFile.setMnemonic('F');
		menuBar.add(mnFile);
		
		mntmOpen = new JMenuItem("Open...");
		mntmOpen.setMnemonic('O');
		mntmOpen.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, InputEvent.CTRL_MASK));
		mntmOpen.addActionListener(new MntmOpenActionListener());
		mnFile.add(mntmOpen);
		
		mntmSave = new JMenuItem("Save...");
		mntmSave.setMnemonic('S');
		mntmSave.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, InputEvent.CTRL_MASK));
		mntmSave.addActionListener(new MntmSaveActionListener());
		mnFile.add(mntmSave);
		
		JMenuItem mntmExit = new JMenuItem("Exit");
		mntmExit.setMnemonic('X');
		mntmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				chart = null;
				System.exit(0);
			}
		});
		mnFile.add(mntmExit);
		
		JMenu mnView = new JMenu("View");
		mnView.setMnemonic('V');
		menuBar.add(mnView);
		
		mntmUnitConverter = new JMenuItem("Unit Converter");
		mntmUnitConverter.setMnemonic('C');
		mntmUnitConverter.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_U, InputEvent.CTRL_MASK));
		mntmUnitConverter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new UnitConverter();
			}
		});
		mnView.add(mntmUnitConverter);
		
		JMenuItem mntmOptions = new JMenuItem("Toolbars");
		mntmOptions.setEnabled(false);
		mnView.add(mntmOptions);
		
		JMenu mnSettings = new JMenu("Settings");
		mnSettings.setMnemonic('E');
		menuBar.add(mnSettings);
		
		JMenu mnUnits = new JMenu("Units");
		mnUnits.setMnemonic('U');
		mnSettings.add(mnUnits);
		
		JRadioButtonMenuItem rdbtnmntmImperial = new JRadioButtonMenuItem("Imperial");
		rdbtnmntmImperial.setMnemonic('I');
		rdbtnmntmImperial.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_I, InputEvent.CTRL_MASK));
		rdbtnmntmImperial.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(metric){
					// Change units from metric to imperial
					ChangeUnits();
				}
			}
		});
		mnUnits.add(rdbtnmntmImperial);
		
		JRadioButtonMenuItem rdbtnmntmMetric = new JRadioButtonMenuItem("Metric");
		rdbtnmntmMetric.setMnemonic('M');
		rdbtnmntmMetric.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_M, InputEvent.CTRL_MASK));
		rdbtnmntmMetric.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!metric){
					// Change units from imperial to metric
					ChangeUnits();
				}
			}
		});
		rdbtnmntmMetric.setSelected(true);
		mnUnits.add(rdbtnmntmMetric);
		
		btnsUnits.add(rdbtnmntmMetric);
		btnsUnits.add(rdbtnmntmImperial);
		
		mnModel = new JMenu("Model");
		mnModel.setMnemonic('M');
		mnSettings.add(mnModel);
		
		rdbtnmntmPrototype = new JRadioButtonMenuItem("Prototype");
		rdbtnmntmPrototype.setMnemonic('P');
		rdbtnmntmPrototype.addActionListener(new RdbtnmntmPrototypeActionListener());
		mnModel.add(rdbtnmntmPrototype);
		
		rdbtnmntmStandard = new JRadioButtonMenuItem("Standard");
		rdbtnmntmStandard.setMnemonic('S');
		rdbtnmntmStandard.addActionListener(new RdbtnmntmStandardActionListener());
		rdbtnmntmStandard.setSelected(true);
		mnModel.add(rdbtnmntmStandard);
		
		rdbtnmntmAdvanced = new JRadioButtonMenuItem("Advanced");
		rdbtnmntmAdvanced.setEnabled(false);
		mnModel.add(rdbtnmntmAdvanced);
		
		rdbtnsModel.add(rdbtnmntmPrototype);
		rdbtnsModel.add(rdbtnmntmStandard);
		rdbtnsModel.add(rdbtnmntmAdvanced);
		
		JMenuItem mntmOptions_1 = new JMenuItem("Options...");
		mntmOptions_1.setMnemonic('O');
		mntmOptions_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Machine machine = null;
				if(listMachines.getSelectedIndex() > -1)
					machine = (Machine) listMachines.getSelectedValue();
				OptionDialog options = new OptionDialog(environment, machine);
				options.setVisible(true);
			}
		});
		mnSettings.add(mntmOptions_1);
		
		JMenu mnHelp = new JMenu("Help");
		mnHelp.setMnemonic('H');
		menuBar.add(mnHelp);
		
		JMenuItem mntmInstructions = new JMenuItem("Instructions");
		mntmInstructions.setMnemonic('I');
		mntmInstructions.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				InstructDialog instructions = new InstructDialog();
				instructions.setVisible(true);
			}
		});
		mnHelp.add(mntmInstructions);
		
		JMenuItem mntmAbout = new JMenuItem("About");
		mntmAbout.setMnemonic('A');
		mntmAbout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AboutDialog about = new AboutDialog();
				//about.pack();
				about.setVisible(true);
			}
		});
		mnHelp.add(mntmAbout);
		
		tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.addChangeListener(TabChangeListener);
		frmTitanRoiCalculator.getContentPane().add(tabbedPane, BorderLayout.CENTER);
		
		pnlMachine = new JPanel();
		tabbedPane.addTab("Machine Selection", null, pnlMachine, "Add and configure machine setups");
		tabbedPane.setEnabledAt(0, true);
		pnlMachine.setLayout(null);
		
		grpMachines = new JPanel();
		grpMachines.setBounds(20, 72, 182, 256);
		grpMachines.setBorder(new TitledBorder(null, "Machine Type", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		pnlMachine.add(grpMachines);
		grpMachines.setLayout(null);
		
		try{
			rdbtnER610 = new JRadioButton(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/er610.png"))));
			rdbtnER610.setDisabledIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/er610_dis.png"))));
			rdbtnER610.setDisabledSelectedIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/er610_dis.png"))));
			rdbtnER610.setEnabled(false);
			rdbtnER610.setToolTipText("Titan ER610");
		}catch(NullPointerException e1){
			System.out.println("Image load error");
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		rdbtnER610.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rdbtnClick("ER610");
				UpdateMachine();
				listMachines.repaint();
			}
		});
		rdbtnER610.setSelected(true);
		rdbtnER610.setBounds(13, 25, 155, 40);
		try{
			rdbtnER610.setPressedIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/er610_down.png"))));
			rdbtnER610.setRolloverEnabled(true);
			rdbtnER610.setRolloverIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/er610_over.png"))));
			rdbtnER610.setSelectedIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/er610_select.png"))));
		}catch(NullPointerException e11){
			System.out.println("Image load error");
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		grpMachines.add(rdbtnER610);
		
		try{
		rdbtnSR9DS = new JRadioButton(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/sr9ds.png"))));
		rdbtnSR9DS.setDisabledIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/sr9ds_dis.png"))));
		rdbtnSR9DS.setEnabled(false);
		rdbtnSR9DS.setToolTipText("Titan SR9-DS");
	}catch(NullPointerException e11){
		System.out.println("Image load error");
	} catch (IOException e1) {
		e1.printStackTrace();
	}
		rdbtnSR9DS.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rdbtnClick("SR9DS");
				UpdateMachine();
				listMachines.repaint();
			}
		});
		
		try{
		rdbtnSR9DS.setPressedIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/sr9ds_down.png"))));
		rdbtnSR9DS.setRolloverEnabled(true);
		rdbtnSR9DS.setRolloverIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/sr9ds_over.png"))));
		rdbtnSR9DS.setSelectedIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/sr9ds_select.png"))));
		rdbtnSR9DS.setBounds(13, 68, 155, 40);
		grpMachines.add(rdbtnSR9DS);
		
		rdbtnSR9DT = new JRadioButton(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/sr9dt.png"))));
		rdbtnSR9DT.setDisabledIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/sr9dt_dis.png"))));
		rdbtnSR9DT.setEnabled(false);
		rdbtnSR9DT.setToolTipText("Titan SR9-DT");
		}catch(NullPointerException e11){
			System.out.println("Image load error");
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		rdbtnSR9DT.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rdbtnClick("SR9DT");
				UpdateMachine();
				listMachines.repaint();
			}
		});
		rdbtnSR9DT.setBounds(13, 111, 155, 40);
		try{
		rdbtnSR9DT.setPressedIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/sr9dt_down.png"))));
		rdbtnSR9DT.setRolloverEnabled(true);
		rdbtnSR9DT.setRolloverIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/sr9dt_over.png"))));
		rdbtnSR9DT.setSelectedIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/sr9dt_select.png"))));
		}catch(NullPointerException e11){
			System.out.println("Image load error");
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		grpMachines.add(rdbtnSR9DT);
		
		
		try {
			rdbtnSR800 = new JRadioButton(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/sr800.png"))));
			rdbtnSR800.setDisabledIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/sr800_dis.png"))));
			rdbtnSR800.setEnabled(false);
			rdbtnSR800.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					rdbtnClick("SR800");
					UpdateMachine();
					listMachines.repaint();
				}
			});
			rdbtnSR800.setPressedIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/sr800_down.png"))));
			rdbtnSR800.setRolloverEnabled(true);
			rdbtnSR800.setRolloverIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/sr800_over.png"))));
			rdbtnSR800.setSelectedIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/sr800_select.png"))));
		} catch (IOException e2) {
			e2.printStackTrace();
		}
		rdbtnSR800.setToolTipText("Titan SR800");
		rdbtnSR800.setRolloverEnabled(true);
		rdbtnSR800.setBounds(13, 154, 155, 40);
		grpMachines.add(rdbtnSR800);
		
		try {
			rdbtnCustom = new JRadioButton(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/custom.png"))));
			rdbtnCustom.setDisabledIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/custom_dis.png"))));
			rdbtnCustom.setEnabled(false);
			rdbtnCustom.setPressedIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/custom_down.png"))));
			rdbtnCustom.setRolloverEnabled(true);
			rdbtnCustom.setRolloverIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/custom_over.png"))));
			rdbtnCustom.setSelectedIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/custom_select.png"))));
		} catch (IOException e2) {
			e2.printStackTrace();
		}
		rdbtnCustom.setToolTipText("Custom Machine");
		rdbtnCustom.setRolloverEnabled(true);
		rdbtnCustom.setBounds(13, 200, 155, 40);
		grpMachines.add(rdbtnCustom);
		rdbtnCustom.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				rdbtnClick("Custom");
				UpdateMachine();
				ResetStatusLabel();
				listMachines.repaint();
			}
		});
		
		rdbtnsMachines.add(rdbtnER610);
		rdbtnsMachines.add(rdbtnSR9DS);
		rdbtnsMachines.add(rdbtnSR9DT);
		rdbtnsMachines.add(rdbtnSR800);
		rdbtnsMachines.add(rdbtnCustom);
		
		grpVariants = new JPanel();
		grpVariants.setBounds(20, 339, 482, 112);
		grpVariants.setBorder(new TitledBorder(null, "Variants", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		pnlMachine.add(grpVariants);
		grpVariants.setLayout(null);
		
		cmbCorepos = new JComboBox();
		cmbCorepos.setToolTipText("Set the core positioning system");
		cmbCorepos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(formReady)
					UpdateMachine();
			}
		});
		cmbCorepos.setEnabled(false);
		cmbCorepos.setBounds(104, 70, 122, 20);
		grpVariants.add(cmbCorepos);
		cmbCorepos.setModel(new DefaultComboBoxModel(new String[] {"Manual", "Laser"}));
		
		lblCorePositioning = new JLabel("Core Positioning:");
		lblCorePositioning.setToolTipText("Set the core positioning system");
		lblCorePositioning.setEnabled(false);
		lblCorePositioning.setHorizontalAlignment(SwingConstants.RIGHT);
		lblCorePositioning.setBounds(12, 73, 88, 14);
		grpVariants.add(lblCorePositioning);
		
		lblKnifeControl = new JLabel("Knife Control:");
		lblKnifeControl.setToolTipText("Set the type of knife positioning system");
		lblKnifeControl.setEnabled(false);
		lblKnifeControl.setHorizontalAlignment(SwingConstants.RIGHT);
		lblKnifeControl.setBounds(22, 48, 78, 14);
		grpVariants.add(lblKnifeControl);
		
		cmbKnives = new JComboBox();
		cmbKnives.setToolTipText("Set the type of knife positioning system");
		cmbKnives.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(formReady)
					UpdateMachine();
			}
		});
		cmbKnives.setEnabled(false);
		cmbKnives.setBounds(104, 45, 122, 20);
		grpVariants.add(cmbKnives);
		cmbKnives.setModel(new DefaultComboBoxModel(new String[] {"Auto", "Manual (Stacked)", "Manual (Inflatable)"}));
		
		cmbUnloader = new JComboBox();
		cmbUnloader.setToolTipText("Set the unloader type");
		cmbUnloader.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(formReady)
					UpdateMachine();
			}
		});
		cmbUnloader.setEnabled(false);
		cmbUnloader.setBounds(350, 20, 122, 20);
		grpVariants.add(cmbUnloader);
		cmbUnloader.setModel(new DefaultComboBoxModel(new String[] {"Manual", "Pneumatic", "Electric"}));
		
		lblUnloader = new JLabel("Unloader:");
		lblUnloader.setToolTipText("Set the unloader type");
		lblUnloader.setEnabled(false);
		lblUnloader.setHorizontalAlignment(SwingConstants.RIGHT);
		lblUnloader.setBounds(259, 23, 87, 14);
		grpVariants.add(lblUnloader);
		
		cmbSpeed = new JComboBox();
		cmbSpeed.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(formReady)
					UpdateMachine();
			}
		});
		cmbSpeed.setEnabled(false);
		cmbSpeed.setToolTipText("Machine top speed in metres/min");
		cmbSpeed.setBounds(104, 20, 122, 20);
		grpVariants.add(cmbSpeed);
		cmbSpeed.setModel(new DefaultComboBoxModel(new String[] {"450", "550"}));
		
		lblSpeed = new JLabel("Speed:");
		lblSpeed.setToolTipText("Machine top speed in metres/min");
		lblSpeed.setEnabled(false);
		lblSpeed.setHorizontalAlignment(SwingConstants.RIGHT);
		lblSpeed.setBounds(54, 23, 46, 14);
		grpVariants.add(lblSpeed);
		
		cmbUnwindDrive = new JComboBox();
		cmbUnwindDrive.setToolTipText("Unwind drive type");
		cmbUnwindDrive.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(formReady)
					UpdateMachine();
			}
		});
		cmbUnwindDrive.setEnabled(false);
		cmbUnwindDrive.setBounds(350, 45, 122, 20);
		grpVariants.add(cmbUnwindDrive);
		cmbUnwindDrive.setModel(new DefaultComboBoxModel(new String[] {"Single", "Double"}));
		
		lblUnwindDrive = new JLabel("Unwind Drive:");
		lblUnwindDrive.setToolTipText("Unwind drive type");
		lblUnwindDrive.setEnabled(false);
		lblUnwindDrive.setHorizontalAlignment(SwingConstants.RIGHT);
		lblUnwindDrive.setBounds(259, 48, 87, 14);
		grpVariants.add(lblUnwindDrive);
		
		lblRewindControlLoop = new JLabel("Rewind Control Loop:");
		lblRewindControlLoop.setToolTipText("Rewind control loop type");
		lblRewindControlLoop.setEnabled(false);
		lblRewindControlLoop.setHorizontalAlignment(SwingConstants.RIGHT);
		lblRewindControlLoop.setBounds(224, 73, 122, 14);
		grpVariants.add(lblRewindControlLoop);
		
		cmbRewindCtrl = new JComboBox();
		cmbRewindCtrl.setToolTipText("Rewind control loop type");
		cmbRewindCtrl.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(formReady)
					UpdateMachine();
			}
		});
		cmbRewindCtrl.setEnabled(false);
		cmbRewindCtrl.setBounds(350, 70, 122, 20);
		grpVariants.add(cmbRewindCtrl);
		cmbRewindCtrl.setModel(new DefaultComboBoxModel(new String[] {"Open", "Closed"}));
		
		listModel = new DefaultListModel();
		jobModel = new DefaultListModel();
		scheduleModel = new DefaultListModel();
		
		//boolean[] options = {true, false, true, true, false, false, false, true, false, true };
        //listModel.addElement(new Machine("This is a test machine", Machine.Model.SR9DS, Machine.Speed.A, Machine.Knives.AUTO, Machine.Corepos.LASER, Machine.Unloader.PNEUMATIC, Machine.Unwind.DOUBLE, Machine.Rewind.CLOSED, options));
        //listModel.addElement(new Machine("Another test one", Machine.Model.SR9DS, Machine.Speed.B, Machine.Knives.AUTO, Machine.Corepos.LASER, Machine.Unloader.PNEUMATIC, Machine.Unwind.DOUBLE, Machine.Rewind.CLOSED, options));
       /* listModel.addElement("Jackson Hole, Wyoming");
        listModel.addElement("Squaw Valley, California");
        listModel.addElement("Telluride, Colorado");
        listModel.addElement("Taos, New Mexico");
        listModel.addElement("Snowbird, Utah");
        listModel.addElement("Chamonix, France");
        listModel.addElement("Banff, Canada");
        listModel.addElement("Arapahoe Basin, Colorado");
        listModel.addElement("Kirkwood, California");
        listModel.addElement("Sun Valley, Idaho");*/
 
        //Create the list and put it in a scroll pane.
        listMachines = new JList(listModel);
        listMachines.setToolTipText("Select a machine to edit options, re-order, or delete");
        listMachines.addListSelectionListener(new MachineListSelectionListener());
        
        listMachines.setCellRenderer(new MachineListRenderer());

		//listMachines = new JList();
		listMachines.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		listMachines.setFont(new Font("Tahoma", Font.PLAIN, 13));
		listModel.removeAllElements();
		/*listMachines.setModel(new AbstractListModel() {
			String[] values = new String[] {"ER610: My test 1", "SR9-DS: this is another test", "SR9-DT: third test", "ER610:  test 2", "ER610: bla bla", "SR9-DS: this is another test", "SR9-DT: hello", "SR9-DT: third test"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});*/
		listMachines.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		listMachines.setBounds(522, 44, 245, 405);
		pnlMachine.add(listMachines);
		
		JLabel lblMachines = new JLabel("Machines");
		lblMachines.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblMachines.setBounds(522, 19, 85, 14);
		pnlMachine.add(lblMachines);
		
		btnMachDelete = new JButton("");
		try{
			btnMachDelete.setIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/delete.png"))));
			btnMachDelete.setRolloverEnabled(true);
			btnMachDelete.setRolloverIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/delete_over.png"))));
			btnMachDelete.setDisabledIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/delete_dis.png"))));
			}catch(NullPointerException e11){
				System.out.println("Image load error");
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		btnMachDelete.setToolTipText("Delete machine");
		btnMachDelete.setEnabled(false);
		btnMachDelete.addActionListener(new DeleteButtonListener());
		btnMachDelete.setBounds(651, 460, 36, 36);
		pnlMachine.add(btnMachDelete);
		
		btnMachUp = new JButton("");
		btnMachUp.setToolTipText("Move machine up");
		btnMachUp.setEnabled(false);
		try{
		btnMachUp.setIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/up.png"))));
		//btnMachUp.setRolloverEnabled(true);
		//btnMachUp.setRolloverIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/up_over.png"))));
		btnMachUp.setDisabledIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/up_dis.png"))));
		}catch(NullPointerException e11){
			System.out.println("Image load error");
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		btnMachUp.addActionListener(new UpListener());
		btnMachUp.setBounds(700, 463, 30, 30);
		pnlMachine.add(btnMachUp);
		
		btnMachDown = new JButton("");
		btnMachDown.setToolTipText("Move machine down");
		btnMachDown.setEnabled(false);
		try{
		btnMachDown.setIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/down.png"))));
		//btnMachDown.setRolloverEnabled(true);
		//btnMachDown.setRolloverIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/down_over.png"))));
		btnMachDown.setDisabledIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/down_dis.png"))));
		}catch(NullPointerException e11){
			System.out.println("Image load error");
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		btnMachDown.addActionListener(new DownListener());
		btnMachDown.setBounds(737, 463, 30, 30);
		pnlMachine.add(btnMachDown);
		
		btnMachReset = new JButton("Reset");
		btnMachReset.setEnabled(false);
		btnMachReset.setToolTipText("Reset the form");
		btnMachReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ResetForm();
			}
		});
		
		btnMachReset.setBounds(20, 460, 100, 36);
		pnlMachine.add(btnMachReset);
		/*txtMachName.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				int key = e.getKeyCode();  
				if (e.getKeyCode() == KeyEvent.VK_ENTER)  
					btnAddMachine.doClick();
			}
		});*/
		
		btnNewMachine = new JButton("Add New");
		btnNewMachine.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewMachine.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				formReady = false;
				
				ResetStatusLabel();
				
				int index = listMachines.getSelectedIndex();
			    int size = listModel.getSize();
			    
			    if(size >= Consts.MACH_LIST_LIMIT){    // Max list size
			    	ShowMessage("Maximum number of machines allocated. Please delete before attempting to add more.");
			    	return;
			    }
			    
			    String newName = getUniqueName("Machine");
			    txtMachName.setText(newName);
			    machine = new Machine(newName); 
			    machNames.add(newName.toLowerCase());
			    
			    //If no selection or if item in last position is selected,
			    //add the new one to end of list, and select new one.
			    if (index == -1 || (index+1 == size)) {
			    	
			        listModel.addElement(machine);
			        listMachines.setSelectedIndex(size);
			
			    //Otherwise insert the new one after the current selection,
			    //and select new one.
			    } else {
			    	listModel.insertElementAt(machine, index + 1);
			        listMachines.setSelectedIndex(index+1);
			    }
			    
			    ResetStatusLabel();
			    //UpdateForm();  already triggered in listchanged
			    formReady = true;
			}
		});
		try {
			btnNewMachine.setIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/plus.png"))));
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		btnNewMachine.setToolTipText("Add new machine");
		btnNewMachine.setBounds(522, 460, 110, 36);
		pnlMachine.add(btnNewMachine);
		
		grpOptions = new JPanel();
		grpOptions.setBounds(212, 72, 290, 256);
		pnlMachine.add(grpOptions);
		grpOptions.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Options", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		grpOptions.setLayout(null);
		
		chckbxFlag = new JCheckBox("Flag Detection");
		chckbxFlag.setToolTipText("Whether an automatic flag detection system is used");
		chckbxFlag.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(formReady)
					UpdateMachine();
			}
		});
		chckbxFlag.setEnabled(false);
		chckbxFlag.setBounds(155, 93, 95, 23);
		grpOptions.add(chckbxFlag);
		
		chckbxSpliceTable = new JCheckBox("Splice Table");
		chckbxSpliceTable.setToolTipText("Whether a splice table is fitted");
		chckbxSpliceTable.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(formReady)
					UpdateMachine();
			}
		});
		chckbxSpliceTable.setEnabled(false);
		chckbxSpliceTable.setBounds(22, 93, 97, 23);
		grpOptions.add(chckbxSpliceTable);
		
		chckbxAlignmentGuide = new JCheckBox("Alignment Guide");
		chckbxAlignmentGuide.setToolTipText("Whether an alignment guide is fitted");
		chckbxAlignmentGuide.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(formReady)
					UpdateMachine();
			}
		});
		chckbxAlignmentGuide.setEnabled(false);
		chckbxAlignmentGuide.setBounds(22, 119, 127, 23);
		grpOptions.add(chckbxAlignmentGuide);
		
		chckbxRollConditioning = new JCheckBox("Roll Conditioning");
		chckbxRollConditioning.setToolTipText("Whether the machine supports roll conditioning");
		chckbxRollConditioning.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(formReady)
					UpdateMachine();
			}
		});
		chckbxRollConditioning.setEnabled(false);
		chckbxRollConditioning.setBounds(22, 145, 127, 23);
		grpOptions.add(chckbxRollConditioning);
		
		chckbxTurretSupport = new JCheckBox("Turret Support");
		chckbxTurretSupport.setToolTipText("For dual turret machines: extra turret support");
		chckbxTurretSupport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(formReady)
					UpdateMachine();
			}
		});
		chckbxTurretSupport.setEnabled(false);
		chckbxTurretSupport.setBounds(22, 171, 97, 23);
		grpOptions.add(chckbxTurretSupport);
		
		chckbxAutostripping = new JCheckBox("Autostripping");
		chckbxAutostripping.setToolTipText("Whether an autostripping feature is present for reel unloading");
		chckbxAutostripping.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(formReady)
					UpdateMachine();
			}
		});
		chckbxAutostripping.setEnabled(false);
		chckbxAutostripping.setBounds(22, 197, 97, 23);
		grpOptions.add(chckbxAutostripping);
		
		chckbxExtraRewind = new JCheckBox("850mm Rewind");
		chckbxExtraRewind.setToolTipText("Extra wide 850mm max diameter rewind support");
		chckbxExtraRewind.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(formReady)
					UpdateMachine();
			}
		});
		chckbxExtraRewind.setEnabled(false);
		chckbxExtraRewind.setBounds(155, 197, 97, 23);
		grpOptions.add(chckbxExtraRewind);
		
		chckbxAutoCutoff = new JCheckBox("Auto Cut-off");
		chckbxAutoCutoff.setToolTipText("Whether the web is cut automatically when a run completes");
		chckbxAutoCutoff.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(formReady)
					UpdateMachine();
			}
		});
		chckbxAutoCutoff.setEnabled(false);
		chckbxAutoCutoff.setBounds(155, 119, 97, 23);
		grpOptions.add(chckbxAutoCutoff);
		
		chckbxAutoTapeCore = new JCheckBox("Auto Tape Core");
		chckbxAutoTapeCore.setToolTipText("Whether new reels are automatically taped before a run begins");
		chckbxAutoTapeCore.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(formReady)
					UpdateMachine();
			}
		});
		chckbxAutoTapeCore.setEnabled(false);
		chckbxAutoTapeCore.setBounds(155, 145, 109, 23);
		grpOptions.add(chckbxAutoTapeCore);
		
		chckbxAutoTapeTail = new JCheckBox("Auto Tape Tail");
		chckbxAutoTapeTail.setToolTipText("Whether the tails of completed reels are automatically taped down");
		chckbxAutoTapeTail.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(formReady)
					UpdateMachine();
			}
		});
		chckbxAutoTapeTail.setEnabled(false);
		chckbxAutoTapeTail.setBounds(155, 171, 97, 23);
		grpOptions.add(chckbxAutoTapeTail);
		
		txtMachName = new JTextField();
		txtMachName.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				txtMachName.selectAll();
			}
		});
		txtMachName.getDocument().addDocumentListener(new DocumentListener() {
			@Override
			public void changedUpdate(DocumentEvent arg0) {
			}
			@Override
			public void insertUpdate(DocumentEvent arg0) {
				UpdateMachineName();
			}
			@Override
			public void removeUpdate(DocumentEvent arg0) {
				UpdateMachineName();
			}
		});
		txtMachName.setEnabled(false);
		txtMachName.setBounds(125, 38, 137, 28);
		grpOptions.add(txtMachName);
		txtMachName.getDocument().addDocumentListener(new DocumentListener() {
		public void changedUpdate(DocumentEvent e) {
		}
		public void removeUpdate(DocumentEvent e) {
		// text was deleted
		}
		public void insertUpdate(DocumentEvent e) {
		// text was inserted
		}
		});
		
			txtMachName.setToolTipText("Enter a name to refer to this particular machine by");
			txtMachName.setFont(new Font("Tahoma", Font.BOLD, 12));
			txtMachName.setColumns(10);
			
			lblMachName = new JLabel("Machine name:");
			lblMachName.setToolTipText("Enter a name to refer to this particular machine by");
			lblMachName.setEnabled(false);
			lblMachName.setBounds(26, 39, 91, 24);
			grpOptions.add(lblMachName);
			lblMachName.setFont(new Font("Tahoma", Font.PLAIN, 13));
			
			lblMachineConfiguration = new JLabel("Machine Configuration");
			lblMachineConfiguration.setFont(new Font("Tahoma", Font.BOLD, 18));
			lblMachineConfiguration.setBounds(29, 18, 269, 22);
			pnlMachine.add(lblMachineConfiguration);
			
			lblAddNewMachines = new JLabel("Add new machines to the list on the right, then configure their options and variants below");
			lblAddNewMachines.setFont(new Font("Tahoma", Font.PLAIN, 11));
			lblAddNewMachines.setBounds(29, 45, 473, 14);
			pnlMachine.add(lblAddNewMachines);
			
			btnCustomMachine = new JButton("Custom Machine Options...");
			btnCustomMachine.setBounds(322, 460, 180, 36);
			pnlMachine.add(btnCustomMachine);
			btnCustomMachine.setVisible(false);
			btnCustomMachine.setToolTipText("Edit settings for a custom machine type");
		
		
		btnCustomMachine.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ResetStatusLabel();
				//rdbtnOther.doClick();
				MachineBuilder newmach = new MachineBuilder(machine);
				newmach.setVisible(true);
			}
		});
		
		pnlJob = new JPanel();
		tabbedPane.addTab("Job Selection", null, pnlJob, "Add and configure machine jobs");
		tabbedPane.setEnabledAt(1, true);
		pnlJob.setLayout(null);
		
		JPanel pnlMaterials = new JPanel();
		pnlMaterials.setBounds(280, 72, 227, 124);
		pnlMaterials.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Material Settings", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		pnlJob.add(pnlMaterials);
		pnlMaterials.setLayout(null);
		
		Material[] materials = {new Material("Custom", 1.0, 20),
								new Material("LLDPE", 0.92, 20),
								new Material("LDPE", 0.925, 20),
								new Material("MDPE", 0.94, 20),
								new Material("HDPE", 0.955, 20),
								new Material("PP", 0.91, 20),
								new Material("Polyolefin", 0.92, 20),
								new Material("PET", 1.4, 20),
								new Material("PS", 1.04, 20),
								new Material("PA", 1.14, 20),
								new Material("PLA", 1.24, 20),
								new Material("PVC", 1.36, 20)
							};

		cmbMaterials = new JComboBox(materials);
		cmbMaterials.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(jobFormReady){
					Material m = (Material) cmbMaterials.getSelectedItem();
					if(!(m.name.equals("Custom"))){
						jobFormReady = false;
						txtThickness.setText(Double.toString(roundTwoDecimals(m.getThickness())));
						txtDensity.setText(Double.toString(roundTwoDecimals(m.getDensity())));
						if(!metric){
							txtThickness.setText(Double.toString(roundTwoDecimals(Core.MicroToMil(m.getThickness()))));
						}
						jobFormReady = true;
					}
					UpdateJob();
				}
			}
		});
		cmbMaterials.setEnabled(false);
		cmbMaterials.setSelectedIndex(0);
		cmbMaterials.setToolTipText("Choose a preset material");
		cmbMaterials.setBounds(81, 26, 117, 22);
		pnlMaterials.add(cmbMaterials);
		
		lblPresets = new JLabel("Presets:");
		lblPresets.setToolTipText("Choose a preset material");
		lblPresets.setEnabled(false);
		lblPresets.setBounds(37, 29, 40, 15);
		pnlMaterials.add(lblPresets);
		
		lblThickness_1 = new JLabel("Thickness:");
		lblThickness_1.setToolTipText("Material thickness");
		lblThickness_1.setEnabled(false);
		lblThickness_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblThickness_1.setBounds(7, 61, 70, 14);
		pnlMaterials.add(lblThickness_1);
		
		lblDensity_1 = new JLabel("Density:");
		lblDensity_1.setToolTipText("Material density (per volume, not area)");
		lblDensity_1.setEnabled(false);
		lblDensity_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblDensity_1.setBounds(31, 86, 46, 14);
		pnlMaterials.add(lblDensity_1);
		
		txtThickness = new JTextField();
		txtThickness.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				txtThickness.selectAll();
			}
		});
		txtThickness.setEnabled(false);
		txtThickness.getDocument().addDocumentListener(new JobInputChangeListener());
		
		txtThickness.setToolTipText("Material thickness");
		txtThickness.setText("20");
		txtThickness.setBounds(81, 58, 86, 20);
		pnlMaterials.add(txtThickness);
		txtThickness.setColumns(10);
		
		txtDensity = new JTextField();
		txtDensity.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				txtDensity.selectAll();
			}
		});
		txtDensity.setEnabled(false);
		txtDensity.getDocument().addDocumentListener(new JobInputChangeListener());
		
		txtDensity.setToolTipText("Material density (per volume, not area)");
		txtDensity.setText("0.92");
		txtDensity.setBounds(81, 83, 86, 20);
		pnlMaterials.add(txtDensity);
		txtDensity.setColumns(10);
		
		lblmicro0 = new JLabel("(\u00B5m)");
		lblmicro0.setEnabled(false);
		lblmicro0.setBounds(177, 61, 46, 14);
		pnlMaterials.add(lblmicro0);
		
		lblgm3 = new JLabel("(g/cm  )");
		lblgm3.setEnabled(false);
		lblgm3.setBounds(177, 86, 46, 14);
		pnlMaterials.add(lblgm3);
		
		label_3 = new JLabel("3");
		label_3.setEnabled(false);
		label_3.setFont(new Font("Tahoma", Font.PLAIN, 8));
		label_3.setBounds(204, 83, 14, 14);
		pnlMaterials.add(label_3);
		
		JPanel pnlJobs = new JPanel();
		pnlJobs.setBounds(20, 168, 250, 283);
		pnlJobs.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Rewind Settings", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		pnlJob.add(pnlJobs);
		pnlJobs.setLayout(null);
		
		lblTargetRewindLength = new JLabel("Rewind Output:");
		lblTargetRewindLength.setToolTipText("Quantity of rewind output");
		lblTargetRewindLength.setEnabled(false);
		lblTargetRewindLength.setHorizontalAlignment(SwingConstants.RIGHT);
		lblTargetRewindLength.setBounds(17, 187, 88, 14);
		pnlJobs.add(lblTargetRewindLength);
		
		lblSlitWidth = new JLabel("Slit Width:");
		lblSlitWidth.setToolTipText("Width of each output reel");
		lblSlitWidth.setEnabled(false);
		lblSlitWidth.setHorizontalAlignment(SwingConstants.RIGHT);
		lblSlitWidth.setBounds(46, 70, 59, 14);
		pnlJobs.add(lblSlitWidth);
		
		lblSlitCount = new JLabel("Slit Count:");
		lblSlitCount.setToolTipText("Number of reels per set at the output");
		lblSlitCount.setEnabled(false);
		lblSlitCount.setHorizontalAlignment(SwingConstants.RIGHT);
		lblSlitCount.setBounds(46, 39, 59, 14);
		pnlJobs.add(lblSlitCount);
		
		lblTrimtotal = new JLabel("Trim (total):");
		lblTrimtotal.setToolTipText("The trim resulting from the given slit widths");
		lblTrimtotal.setEnabled(false);
		lblTrimtotal.setHorizontalAlignment(SwingConstants.RIGHT);
		lblTrimtotal.setBounds(20, 100, 85, 14);
		pnlJobs.add(lblTrimtotal);
		
		txtSlits = new JTextField();
		txtSlits.setToolTipText("Number of reels per set at the output");
		txtSlits.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				txtSlits.selectAll();
			}
		});
		txtSlits.getDocument().addDocumentListener(new JobInputChangeListener());
		txtSlits.setEnabled(false);
		
		txtSlits.setText("1");
		txtSlits.setBounds(109, 36, 86, 20);
		pnlJobs.add(txtSlits);
		txtSlits.setColumns(10);
		
		txtSlitWidth = new JTextField();
		txtSlitWidth.setToolTipText("Width of each output reel");
		txtSlitWidth.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				txtSlitWidth.selectAll();
			}
		});
		txtSlitWidth.getDocument().addDocumentListener(new JobInputChangeListener());
		txtSlitWidth.setEnabled(false);
		
		txtSlitWidth.setText("1350");
		txtSlitWidth.setBounds(109, 67, 86, 20);
		pnlJobs.add(txtSlitWidth);
		txtSlitWidth.setColumns(10);
		
		txtRewindAmount = new JTextField();
		txtRewindAmount.setToolTipText("Quantity of rewind output");
		txtRewindAmount.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				txtRewindAmount.selectAll();
			}
		});
		txtRewindAmount.getDocument().addDocumentListener(new JobInputChangeListener());
		txtRewindAmount.setEnabled(false);
		txtRewindAmount.setName("RewindLength");
		
		txtRewindAmount.setText("1000");
		txtRewindAmount.setBounds(109, 184, 86, 20);
		pnlJobs.add(txtRewindAmount);
		txtRewindAmount.setColumns(10);
		
		lblTrim = new JLabel("0 mm");
		lblTrim.setToolTipText("The trim resulting from the given slit widths");
		lblTrim.setEnabled(false);
		lblTrim.setBounds(111, 100, 65, 14);
		pnlJobs.add(lblTrim);
		
		cmbRewindCore = new JComboBox();
		cmbRewindCore.setToolTipText("Core diameter of rewind reels");
		((JTextField) cmbRewindCore.getEditor().getEditorComponent()).getDocument().addDocumentListener(new DocumentListener() {
			@Override
			public void removeUpdate(DocumentEvent arg0) {
				UpdateJob();
			}
			@Override
			public void insertUpdate(DocumentEvent arg0) {
				UpdateJob();
			}
			@Override
			public void changedUpdate(DocumentEvent arg0) {
			}
		});
		/*cmbRewindCore.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UpdateJob(jobIndex);
			}
		});*/
		cmbRewindCore.setEnabled(false);

		cmbRewindCore.setModel(new DefaultComboBoxModel(Consts.REWIND_CORE_MM));
		cmbRewindCore.setSelectedIndex(1);
		cmbRewindCore.setBounds(109, 127, 87, 20);
		pnlJobs.add(cmbRewindCore);
		cmbRewindCore.setEditable(true);
		
		lblRewindCoremm = new JLabel("Rewind Core:");
		lblRewindCoremm.setToolTipText("Core diameter of rewind reels");
		lblRewindCoremm.setEnabled(false);
		lblRewindCoremm.setBounds(40, 130, 65, 14);
		pnlJobs.add(lblRewindCoremm);
		
		lblPer_1 = new JLabel("per:");
		lblPer_1.setToolTipText("Set whether rewind output is measured per reel or per set");
		lblPer_1.setEnabled(false);
		lblPer_1.setBounds(85, 238, 20, 14);
		pnlJobs.add(lblPer_1);
		
		cmbJobDomain = new JComboBox();
		cmbJobDomain.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UpdateSetReel();
				UpdateJob();
			}
		});
		cmbJobDomain.setEnabled(false);
		cmbJobDomain.setToolTipText("Set whether rewind output is measured per reel or per set");
		cmbJobDomain.setModel(new DefaultComboBoxModel(new String[] {"Reel", "Set"}));
		cmbJobDomain.setBounds(109, 236, 95, 20);
		pnlJobs.add(cmbJobDomain);
		
		lblmm3 = new JLabel("(mm)");
		lblmm3.setEnabled(false);
		lblmm3.setBounds(206, 69, 27, 14);
		pnlJobs.add(lblmm3);
		
		lblmm2 = new JLabel("(mm)");
		lblmm2.setEnabled(false);
		lblmm2.setBounds(206, 130, 27, 14);
		pnlJobs.add(lblmm2);
		
		pnlUnwinds = new JPanel();
		pnlUnwinds.setLayout(null);
		pnlUnwinds.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Unwind Settings", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		pnlUnwinds.setBounds(280, 207, 227, 162);
		pnlJob.add(pnlUnwinds);
		
		lblUnwindLength = new JLabel("Unwind Size:");
		lblUnwindLength.setToolTipText("Quantity of material per mother roll");
		lblUnwindLength.setEnabled(false);
		lblUnwindLength.setHorizontalAlignment(SwingConstants.RIGHT);
		lblUnwindLength.setBounds(21, 104, 66, 14);
		pnlUnwinds.add(lblUnwindLength);
		
		txtUnwindAmount = new JTextField();
		txtUnwindAmount.setToolTipText("Quantity of material per mother roll");
		txtUnwindAmount.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent arg0) {
				txtUnwindAmount.selectAll();
			}
		});
		txtUnwindAmount.getDocument().addDocumentListener(new JobInputChangeListener());
		txtUnwindAmount.setEnabled(false);
		txtUnwindAmount.setName("UnwindLength");
		txtUnwindAmount.setText("10000");
		txtUnwindAmount.setBounds(92, 100, 86, 20);
		pnlUnwinds.add(txtUnwindAmount);
		txtUnwindAmount.setColumns(10);
		
		lblWebWidthmm = new JLabel("Web Width:");
		lblWebWidthmm.setToolTipText("Width of mother rolls");
		lblWebWidthmm.setEnabled(false);
		lblWebWidthmm.setBounds(31, 29, 57, 14);
		pnlUnwinds.add(lblWebWidthmm);
		
		lblUnwindCoremm = new JLabel("Unwind Core:");
		lblUnwindCoremm.setToolTipText("Core diameter of mother rolls");
		lblUnwindCoremm.setEnabled(false);
		lblUnwindCoremm.setBounds(22, 54, 66, 14);
		pnlUnwinds.add(lblUnwindCoremm);
		
		cmbUnwindCore = new JComboBox();
		cmbUnwindCore.setToolTipText("Core diameter of mother rolls");
		((JTextField) cmbUnwindCore.getEditor().getEditorComponent()).getDocument().addDocumentListener(new DocumentListener() {
			@Override
			public void removeUpdate(DocumentEvent arg0) {
				UpdateJob();
			}
			@Override
			public void insertUpdate(DocumentEvent arg0) {
				UpdateJob();
			}
			@Override
			public void changedUpdate(DocumentEvent arg0) {
			}
		});
		cmbUnwindCore.setEnabled(false);
		
		cmbUnwindCore.setModel(new DefaultComboBoxModel(new String[] {"76", "152", "254"}));
		cmbUnwindCore.setBounds(92, 51, 86, 20);
		pnlUnwinds.add(cmbUnwindCore);
		cmbUnwindCore.setEditable(true);
		
		lblmm0 = new JLabel("(mm)");
		lblmm0.setEnabled(false);
		lblmm0.setBounds(189, 29, 32, 14);
		pnlUnwinds.add(lblmm0);
		
		lblmm1 = new JLabel("(mm)");
		lblmm1.setEnabled(false);
		lblmm1.setBounds(189, 53, 32, 14);
		pnlUnwinds.add(lblmm1);
		
		pnlEnviron = new JPanel();
		tabbedPane.addTab("Job Scheduling", null, pnlEnviron, "Edit the schedule of jobs to be analysed");
		tabbedPane.setEnabledAt(2, true);
		pnlEnviron.setLayout(null);
		
		JPanel pnlShifts = new JPanel();
		pnlShifts.setLayout(null);
		pnlShifts.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Shift Options", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		pnlShifts.setBounds(20, 72, 287, 210);
		pnlEnviron.add(pnlShifts);
		
		JLabel lblShiftLength = new JLabel("Shift Length:");
		lblShiftLength.setToolTipText("Hours per working shift");
		lblShiftLength.setHorizontalAlignment(SwingConstants.RIGHT);
		lblShiftLength.setBounds(15, 41, 108, 14);
		pnlShifts.add(lblShiftLength);
		
		JLabel lblDayLength = new JLabel("Day Length:");
		lblDayLength.setToolTipText("Working hours per day");
		lblDayLength.setHorizontalAlignment(SwingConstants.RIGHT);
		lblDayLength.setBounds(29, 91, 94, 14);
		pnlShifts.add(lblDayLength);
		
		JLabel lblShiftsDay = new JLabel("Shifts per Day:");
		lblShiftsDay.setToolTipText("Shifts per day");
		lblShiftsDay.setHorizontalAlignment(SwingConstants.RIGHT);
		lblShiftsDay.setBounds(15, 66, 108, 14);
		pnlShifts.add(lblShiftsDay);
		
		JLabel lblDays = new JLabel("Days per Year:");
		lblDays.setToolTipText("Days per year");
		lblDays.setHorizontalAlignment(SwingConstants.RIGHT);
		lblDays.setBounds(0, 141, 123, 14);
		pnlShifts.add(lblDays);
		
		txtShiftLength = new JTextField();
		txtShiftLength.setToolTipText("Hours per working shift");
		
		txtShiftLength.setText("8");
		txtShiftLength.addActionListener(new FieldUpdateListener(1));
		txtShiftLength.addFocusListener(new FieldUpdateListener(1));
		txtShiftLength.setBounds(133, 38, 86, 20);
		pnlShifts.add(txtShiftLength);
		txtShiftLength.setColumns(10);
		
		txtShiftCount = new JTextField();
		txtShiftCount.setToolTipText("Shifts per day");
		
		txtShiftCount.setText("3");
		txtShiftCount.setBounds(133, 63, 86, 20);
		txtShiftCount.addActionListener(new FieldUpdateListener(1));
		txtShiftCount.addFocusListener(new FieldUpdateListener(1));
		pnlShifts.add(txtShiftCount);
		txtShiftCount.setColumns(10);
		
		txtDaysYear = new JTextField();
		txtDaysYear.setToolTipText("Days per year");
		
		txtDaysYear.setText("250");
		txtDaysYear.addFocusListener(new FieldUpdateListener(1));
		txtDaysYear.addActionListener(new FieldUpdateListener(1));
		txtDaysYear.setBounds(133, 138, 86, 20);
		pnlShifts.add(txtDaysYear);
		txtDaysYear.setColumns(10);
		
		lblDaysPerWeek = new JLabel("Days per Week:");
		lblDaysPerWeek.setToolTipText("Days per week");
		lblDaysPerWeek.setBounds(46, 116, 77, 14);
		pnlShifts.add(lblDaysPerWeek);
		
		txtDaysWeek = new JTextField();
		txtDaysWeek.setToolTipText("Days per week");
		txtDaysWeek.addFocusListener(new FieldUpdateListener(0));
		
		txtDaysWeek.setText("5");
		txtDaysWeek.setBounds(133, 113, 86, 20);
		pnlShifts.add(txtDaysWeek);
		txtDaysWeek.setColumns(10);
		
		lblDayLength2 = new JLabel("24 hours");
		lblDayLength2.setToolTipText("Working hours per day");
		lblDayLength2.setBounds(133, 91, 86, 14);
		pnlShifts.add(lblDayLength2);
		
		lblHoursYear = new JLabel("Hours per Year:");
		lblHoursYear.setToolTipText("Working hours per year");
		lblHoursYear.setBounds(47, 166, 76, 14);
		pnlShifts.add(lblHoursYear);
		
		lblHoursYear2 = new JLabel("6000 hours");
		lblHoursYear2.setToolTipText("Working hours per year");
		lblHoursYear2.setBounds(133, 166, 86, 14);
		pnlShifts.add(lblHoursYear2);
		
		lblHrs = new JLabel("hrs");
		lblHrs.setBounds(229, 41, 46, 14);
		pnlShifts.add(lblHrs);
		
		listJobsAvail = new JList(jobModel);
		listJobsAvail.setToolTipText("Select job to be added");
		listJobsAvail.addListSelectionListener(new JobAvailSelectionListener());
		listJobsAvail.setCellRenderer(new JobListRenderer());
		listJobsAvail.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		listJobsAvail.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		listJobsAvail.setBounds(327, 44, 190, 405);
		pnlEnviron.add(listJobsAvail);
		
		btnAddAll = new JButton("Add All");
		btnAddAll.setToolTipText("Add all jobs to the schedule in order");
		btnAddAll.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnAddAll.setEnabled(false);
		btnAddAll.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for(int i=0; i < jobModel.getSize(); ++i){
					listJobsAvail.setSelectedIndex(i);
					btnAddJob.doClick();
				}
			}
		});
		btnAddAll.setBounds(327, 460, 80, 36);
		pnlEnviron.add(btnAddAll);
		
		btnAddJob = new JButton("");
		btnAddJob.setToolTipText("Add this job to the schedule");
		btnAddJob.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//AddToSchedule(listJobsAvail.getSelectedValue());
				
				ResetStatusLabel();
				
				int index = listSchedule.getSelectedIndex();
				//int source_index = listJobsAvail.getSelectedIndex();
				Job sel = (Job) listJobsAvail.getSelectedValue();
				JobItem j = environment.getSchedule().new JobItem(sel, 0, sel.getTotWeight(), sel.getTotLength());
			    int size = scheduleModel.getSize();
			    
			    // no limit now there are scroll bars
			     /* if(size >= Consts.JOB_LIST_LIMIT){    // Max list size
			    	ShowMessage("Maximum number of jobs scheduled. Please delete before attempting to add more.");
			    	return;
			    }*/
			    
			    //If no selection or if item in last position is selected,
			    //add the new one to end of list, and select new one.
			    if (index == -1 || (index+1 == size)) {
			    	
			    	scheduleModel.addElement(sel);
			    	listSchedule.setSelectedIndex(size);
			    	environment.getSchedule().addJob(j);
			
			    //Otherwise insert the new one after the current selection,
			    //and select new one.
			    } else {
			    	scheduleModel.insertElementAt(sel, index + 1);
			    	listSchedule.setSelectedIndex(index+1);
			    	environment.getSchedule().insertJob(j, index+1);
			    }
			    
				btnClearSchedule.setEnabled(true);
			}
		});
		btnAddJob.setEnabled(false);
		try {	
			btnAddJob.setIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/add_job.png"))));
			btnAddJob.setDisabledIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/add_job_dis.png"))));
			btnAddJob.setRolloverEnabled(true);
			btnAddJob.setRolloverIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/add_job_over.png"))));
		} catch (NullPointerException e111) {
			System.out.println("Image load error");
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		btnAddJob.setBounds(521, 178, 54, 54);
		pnlEnviron.add(btnAddJob);
		
		btnRemoveJob = new JButton("");
		btnRemoveJob.setToolTipText("Remove job from schedule");
		btnRemoveJob.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ResetStatusLabel();
				
				if(listSchedule.getSelectedIndex() > -1){
					Job j = (Job) listSchedule.getSelectedValue();
					String name = j.getName();
					if(!jobNames.contains(name) && !listModel.contains(j)){
						jobModel.addElement(j);
						listJobsAvail.setSelectedIndex(jobModel.size()-1);
						listJobs.setSelectedIndex(jobModel.size()-1);
					}
				}
				
	            ListSelectionModel lsm = listSchedule.getSelectionModel();
	            int firstSelected = lsm.getMinSelectionIndex();
	            int lastSelected = lsm.getMaxSelectionIndex();
	            scheduleModel.removeRange(firstSelected, lastSelected);
	            environment.getSchedule().remove(firstSelected);
	 
	            int size = scheduleModel.size();
	 
	            if (size == 0) {
	            //List is empty: disable delete, up, and down buttons.
	                btnClearSchedule.setEnabled(false);
	                btnUpSchedule.setEnabled(false);
	                btnDownSchedule.setEnabled(false);
	                listSchedule.clearSelection();
	                btnRemoveJob.setEnabled(false);
	                btnViewSchedule.setEnabled(false);
	            } else {
	            //Adjust the selection.
	                if (firstSelected == scheduleModel.getSize()) {
	                //Removed item in last position.
	                    firstSelected--;
	                }
	                listSchedule.setSelectedIndex(firstSelected);
	                
	                if(size == 21){  // No longer full list
	                	ResetStatusLabel();
	                }
	                
	            }
			}
		});
		btnRemoveJob.setEnabled(false);
		try {	
			btnRemoveJob.setIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/del_job.png"))));
			btnRemoveJob.setDisabledIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/del_job_dis.png"))));
			btnRemoveJob.setRolloverEnabled(true);
			btnRemoveJob.setRolloverIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/del_job_over.png"))));
		} catch (NullPointerException e111) {
			System.out.println("Image load error");
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		btnRemoveJob.setBounds(520, 243, 54, 54);
		pnlEnviron.add(btnRemoveJob);
		
		lblJobSchedule_1 = new JLabel("Job Schedule");
		lblJobSchedule_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblJobSchedule_1.setBounds(29, 18, 269, 22);
		pnlEnviron.add(lblJobSchedule_1);
		
		lblScheduleJobsTo = new JLabel("Schedule jobs to the right, then set shift options below");
		lblScheduleJobsTo.setBounds(29, 45, 483, 14);
		pnlEnviron.add(lblScheduleJobsTo);
		
		lblAvailableJobs_1 = new JLabel("Available Jobs");
		lblAvailableJobs_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblAvailableJobs_1.setBounds(327, 19, 137, 14);
		pnlEnviron.add(lblAvailableJobs_1);
		
		lblJobSchedule_2 = new JLabel("Job Schedule");
		lblJobSchedule_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblJobSchedule_2.setBounds(577, 19, 110, 14);
		pnlEnviron.add(lblJobSchedule_2);
		
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Schedule Options", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.setBounds(20, 298, 287, 151);
		pnlEnviron.add(panel);
		
		btnViewSchedule = new JButton("View schedule");
		btnViewSchedule.setToolTipText("View chart of schedule timings");
		btnViewSchedule.setEnabled(false);
		btnViewSchedule.setBounds(80, 39, 113, 29);
		panel.add(btnViewSchedule);
		
		btnOptions = new JButton("Options...");
		btnOptions.setToolTipText("Schedule options");
		btnOptions.setEnabled(false);
		btnOptions.setBounds(80, 79, 113, 29);
		panel.add(btnOptions);
		
		btnUpSchedule = new JButton("");
		btnUpSchedule.setToolTipText("Move job earlier in schedule");
		btnUpSchedule.addActionListener(new ScheduleUpListener());
		try{
			btnUpSchedule.setIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/up.png"))));
			//btnMachUp.setRolloverEnabled(true);
			//btnMachUp.setRolloverIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/up_over.png"))));
			btnUpSchedule.setDisabledIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/up_dis.png"))));
			}catch(NullPointerException e11){
				System.out.println("Image load error");
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		btnUpSchedule.setEnabled(false);
		btnUpSchedule.setBounds(700, 463, 30, 30);
		pnlEnviron.add(btnUpSchedule);
		
		btnDownSchedule = new JButton("");
		btnDownSchedule.setToolTipText("Move job later in schedule");
		btnDownSchedule.addActionListener(new ScheduleDownListener());
		try{
			btnDownSchedule.setIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/down.png"))));
			//btnMachUp.setRolloverEnabled(true);
			//btnMachUp.setRolloverIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/up_over.png"))));
			btnDownSchedule.setDisabledIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/down_dis.png"))));
			}catch(NullPointerException e11){
				System.out.println("Image load error");
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		btnDownSchedule.setEnabled(false);
		btnDownSchedule.setBounds(737, 463, 30, 30);
		pnlEnviron.add(btnDownSchedule);
		
		btnClearSchedule = new JButton("Clear");
		btnClearSchedule.setToolTipText("Clear all jobs from the schedule");
		btnClearSchedule.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnClearSchedule.setEnabled(false);
		btnClearSchedule.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				scheduleModel.removeAllElements();
				environment.getSchedule().empty();
			}
		});
		btnClearSchedule.setBounds(577, 460, 80, 36);
		pnlEnviron.add(btnClearSchedule);
		
		listSchedule = new JList(scheduleModel);
		listSchedule.setToolTipText("Select job to re-order or remove from schedule");
		listSchedule.addListSelectionListener(new ScheduleSelectionListener());
		listSchedule.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		listSchedule.setCellRenderer(new JobListRenderer());
		//listSchedule.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		//listSchedule.setBounds(577, 44, 190, 405);
		//pnlEnviron.add(listSchedule);
		btnViewSchedule.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ScheduleChart ch = new ScheduleChart(environment.getSchedule());
			    ch.pack();
			    try{
					ch.setIconImage(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/logo.png")));
					}catch(NullPointerException e11){
						System.out.println("Image load error");
					} catch (IOException e) {
						e.printStackTrace();
					}
			    ch.setLocationRelativeTo(null);
			    ch.setVisible(true);
			}
		});
		
		scrlSchedule = new JScrollPane(listSchedule);
		scrlSchedule.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrlSchedule.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		scrlSchedule.setBounds(577, 44, 190, 405);
		pnlEnviron.add(scrlSchedule);
		
		pnlCompare = new JPanel();
		tabbedPane.addTab("Productivity Comparison", null, pnlCompare, "Productivity comparison data & graphs");
		tabbedPane.setEnabledAt(3, true);
		pnlCompare.setLayout(null);
		
		pnlResults = new JPanel();
		pnlResults.setBorder(new TitledBorder(null, "Numerical Results", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		pnlResults.setBounds(20, 72, 479, 134);
		pnlCompare.add(pnlResults);
		pnlResults.setLayout(null);
		
		lblOutputLength = new JLabel("Output length over time period:");
		lblOutputLength.setEnabled(false);
		lblOutputLength.setToolTipText("Quantity produced");
		lblOutputLength.setBounds(220, 66, 152, 14);
		pnlResults.add(lblOutputLength);
		
		lblOutputWeight = new JLabel("Output weight over time period:");
		lblOutputWeight.setEnabled(false);
		lblOutputWeight.setToolTipText("Quantity produced");
		lblOutputWeight.setBounds(220, 91, 162, 14);
		pnlResults.add(lblOutputWeight);
		
		cmbTimeRef = new JComboBox();
		cmbTimeRef.setEnabled(false);
		cmbTimeRef.setToolTipText("Select a time range to display results over");
		cmbTimeRef.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Refresh analyses
				UpdateNumericalAnalysis();
			}
		});
		cmbTimeRef.setModel(new DefaultComboBoxModel(new String[] {"Schedule", "Year", "Hour", "Shift", "Day", "Week"}));
		cmbTimeRef.setBounds(330, 27, 115, 24);
		pnlResults.add(cmbTimeRef);
		
		lblPer = new JLabel("Per:");
		lblPer.setEnabled(false);
		lblPer.setBounds(300, 32, 20, 14);
		pnlResults.add(lblPer);
		
		lblAverageMmin = new JLabel("Average metres/hr:");
		lblAverageMmin.setEnabled(false);
		lblAverageMmin.setToolTipText("Average quantity processed");
		lblAverageMmin.setBounds(20, 66, 95, 14);
		pnlResults.add(lblAverageMmin);
		
		lblNumericsWeight = new JLabel("0.0 tons");
		lblNumericsWeight.setEnabled(false);
		lblNumericsWeight.setToolTipText("Quantity produced");
		lblNumericsWeight.setBounds(380, 91, 77, 14);
		pnlResults.add(lblNumericsWeight);
		
		lblNumericsLength = new JLabel("0.0 metres");
		lblNumericsLength.setEnabled(false);
		lblNumericsLength.setToolTipText("Quantity produced");
		lblNumericsLength.setBounds(380, 66, 77, 14);
		pnlResults.add(lblNumericsLength);
		
		lblNumericsRate = new JLabel("0.0 m/hr");
		lblNumericsRate.setEnabled(false);
		lblNumericsRate.setToolTipText("Average quantity processed");
		lblNumericsRate.setBounds(123, 66, 82, 14);
		pnlResults.add(lblNumericsRate);
		
		lblEfficiency = new JLabel("Efficiency:");
		lblEfficiency.setEnabled(false);
		lblEfficiency.setToolTipText("Machine efficiency");
		lblEfficiency.setBounds(20, 91, 65, 14);
		pnlResults.add(lblEfficiency);
		
		cmbMachines = new JComboBox();
		cmbMachines.setFont(new Font("Tahoma", Font.BOLD, 11));
		cmbMachines.setEnabled(false);
		cmbMachines.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				UpdateNumericalAnalysis();
			}
		});
		cmbMachines.setToolTipText("Select machine");
		cmbMachines.setBounds(107, 27, 162, 24);
		pnlResults.add(cmbMachines);
		
		lblMachine = new JLabel("Select Machine:");
		lblMachine.setEnabled(false);
		lblMachine.setToolTipText("Select machine");
		lblMachine.setBounds(20, 32, 77, 14);
		pnlResults.add(lblMachine);
		
		lblNumericsEff = new JLabel("0.0 %");
		lblNumericsEff.setEnabled(false);
		lblNumericsEff.setToolTipText("Machine efficiency");
		lblNumericsEff.setBounds(123, 91, 65, 14);
		pnlResults.add(lblNumericsEff);
		
		listCompare = new JList(listModel);
		listCompare.setCellRenderer(new MachineListRenderer());
		listCompare.setToolTipText("Click a machine to select it. Select multiple machines to compare their performance under the chosen job schedule.");
		listCompare.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		listCompare.setSelectionModel(new DefaultListSelectionModel() {
		    private static final long serialVersionUID = 1L;

		    boolean gestureStarted = false;

		    @Override
		    public void setSelectionInterval(int index0, int index1) {
		        if(!gestureStarted){
		            if (isSelectedIndex(index0)) {
		                super.removeSelectionInterval(index0, index1);
		            } else {
		                super.addSelectionInterval(index0, index1);
		            }
		        }
		        gestureStarted = true;
		    }

		    @Override
		    public void setValueIsAdjusting(boolean isAdjusting) {
		        if (isAdjusting == false) {
		            gestureStarted = false;
		        }
		    }

		});
		
		listCompare.setBounds(522, 44, 245, 405);
		listCompare.addListSelectionListener(new MultiSelectionListener());
		pnlCompare.add(listCompare);
		
		lblProductivityComparison = new JLabel("Productivity Comparison");
		lblProductivityComparison.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblProductivityComparison.setBounds(29, 18, 269, 22);
		pnlCompare.add(lblProductivityComparison);
		
		lblSelectMultipleMachines = new JLabel("Select multiple machines from the list on the right, then compare them below");
		lblSelectMultipleMachines.setBounds(29, 45, 433, 14);
		pnlCompare.add(lblSelectMultipleMachines);
		
		label_2 = new JLabel("Machines");
		label_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		label_2.setBounds(522, 19, 85, 14);
		pnlCompare.add(label_2);
		
		pnlProdGraph = new JPanel();
		pnlProdGraph.setBounds(20, 222, 479, 274);
		pnlCompare.add(pnlProdGraph);
		pnlProdGraph.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Graph", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		pnlProdGraph.setLayout(null);
		
		btnShowGraph = new JButton("Open Graph");
		btnShowGraph.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnShowGraph.setToolTipText("Open graph in new window");
		btnShowGraph.setEnabled(false);
		btnShowGraph.setBounds(358, 51, 99, 39);
		pnlProdGraph.add(btnShowGraph);
		
		btnSaveToFile = new JButton("Save to file...");
		btnSaveToFile.setToolTipText("Save image to disk");
		btnSaveToFile.setEnabled(false);
		btnSaveToFile.addActionListener(SaveActionListener);
		btnSaveToFile.setBounds(358, 228, 99, 24);
		pnlProdGraph.add(btnSaveToFile);
		
		pnlPreview = new JPanel();
		pnlPreview.setBackground(Color.WHITE);
		pnlPreview.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		pnlPreview.setBounds(21, 51, 314, 201);
		pnlProdGraph.add(pnlPreview);
		pnlPreview.setLayout(null);
		pnlGraph = new ChartPanel(chart);
		pnlGraph.setBounds(2, 2, 312, 199);
		//pnlGraph.setPreferredSize(new java.awt.Dimension(243, 171));
		pnlPreview.add(pnlGraph);
		try {
			picLabel = new JLabel(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/no_preview.png"))));
		} catch (IOException e2) {
			e2.printStackTrace();
		}
		picLabel.setBounds(2, 11, 312, 179);
		picLabel.setPreferredSize(new java.awt.Dimension(243, 148));
		pnlPreview.add(picLabel);
		pnlGraph.setVisible(false);
		
		lblPreview = new JLabel("Preview:");
		lblPreview.setEnabled(false);
		lblPreview.setBounds(21, 26, 46, 14);
		pnlProdGraph.add(lblPreview);
		
		lblType = new JLabel("Measure:");
		lblType.setEnabled(false);
		lblType.setToolTipText("Choose measurement type");
		lblType.setBounds(358, 178, 46, 14);
		pnlProdGraph.add(lblType);
		
		cmbGraphType = new JComboBox();
		cmbGraphType.setEnabled(false);
		cmbGraphType.setToolTipText("Choose measurement type");
		cmbGraphType.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Refresh analyses
				UpdateGraph();
			}
		});
		cmbGraphType.setModel(new DefaultComboBoxModel(new String[] {"Schedule time", "Length/year", "Weight/year", "Length/hour", "Weight/hour", "Efficiency"}));
		cmbGraphType.setSelectedIndex(0);
		cmbGraphType.setBounds(358, 194, 99, 24);
		pnlProdGraph.add(cmbGraphType);
		
		btnShowTimings = new JButton("Show Timings");
		btnShowTimings.setToolTipText("Show timing diagram for a single machine run");
		btnShowTimings.setEnabled(false);
		btnShowTimings.addActionListener(new BtnShowTimingsActionListener());
		btnShowTimings.setBounds(358, 101, 99, 39);
		pnlProdGraph.add(btnShowTimings);
		
		panel_3 = new JPanel();
		panel_3.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_3.setBounds(522, 459, 245, 37);
		pnlCompare.add(panel_3);
		panel_3.setLayout(null);
		
		btnNone = new JButton("None");
		btnNone.setEnabled(false);
		btnNone.setBounds(172, 7, 57, 23);
		panel_3.add(btnNone);
		btnNone.setToolTipText("Clear machine selection");
		
		btnAll = new JButton("All");
		btnAll.setEnabled(false);
		btnAll.setBounds(105, 7, 57, 23);
		panel_3.add(btnAll);
		btnAll.setToolTipText("Select all machines");
		
		lblSelect = new JLabel("Select:");
		lblSelect.setEnabled(false);
		lblSelect.setBounds(37, 11, 46, 14);
		panel_3.add(lblSelect);
		
		btnRefreshAnalysis = new JButton("");
		btnRefreshAnalysis.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UpdateAnalysis();
			}
		});
		btnRefreshAnalysis.setBounds(466, 22, 30, 30);
		try {	
			btnRefreshAnalysis.setIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/refresh.png"))));
		} catch (NullPointerException e111) {
			System.out.println("Image load error");
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		pnlCompare.add(btnRefreshAnalysis);
		btnAll.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int[] count = new int[listModel.size()];
				for(int i=0; i<listModel.size(); ++i)
					count[i] = i;
				listCompare.setSelectedIndices(count);
			}
		});
		btnNone.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				listCompare.clearSelection();
			}
		});
		btnShowGraph.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// TODO base on cmbGraphType: or not if just using chart
				
				/*PieChart test = new PieChart("title","this is a pie chart");
				test.pack();
				test.setVisible(true);
				test.setLocationRelativeTo(null);*/
				JFrame popGraph = new JFrame();
				
				JFreeChart chartBig = null;
				try {
					chartBig = (JFreeChart) chart.clone();
					chartBig.removeLegend();
				} catch (CloneNotSupportedException e) {
					e.printStackTrace();
				}
				//chartBig.setTitle("Productivity Comparison");
				
				ChartPanel cpanel = new ChartPanel(chartBig);
				cpanel.setPreferredSize(new java.awt.Dimension(500, 300));
				popGraph.setContentPane(cpanel);
				try{
					popGraph.setIconImage(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/logo.png")));
				}catch(NullPointerException e11){
					System.out.println("Image load error");
				} catch (IOException e) {
					e.printStackTrace();
				}
				popGraph.setTitle("Productivity Graph");
				popGraph.setSize(450, 300);
				
				popGraph.pack();
				popGraph.setVisible(true);
				popGraph.setLocationRelativeTo(null);
			}
		});
		
		pnlROI = new JPanel();
		tabbedPane.addTab("Return on Investment", (Icon) null, pnlROI, "Return on investment comparison and analysis");
		pnlROI.setLayout(null);
		tabbedPane.setEnabledAt(4, true);
		
        lblReturnOnInvestment = new JLabel("Return on Investment");
        lblReturnOnInvestment.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblReturnOnInvestment.setBounds(29, 18, 269, 22);
        pnlROI.add(lblReturnOnInvestment);
        
        lblSelectMultipleMachines_1 = new JLabel("Select multiple machines from the list on the right, then compare them below");
        lblSelectMultipleMachines_1.setBounds(29, 45, 433, 14);
        pnlROI.add(lblSelectMultipleMachines_1);
        
        lblCompareroiList = new JLabel("Machines");
        lblCompareroiList.setFont(new Font("Tahoma", Font.BOLD, 12));
        lblCompareroiList.setBounds(522, 19, 85, 14);
        pnlROI.add(lblCompareroiList);
        
        listCompareRoi = new JList(listModel);
        listCompareRoi.setToolTipText("Click a machine to select it. Select two or more machines to compare their ROI measures.");
        listCompareRoi.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
        listCompareRoi.setBounds(522, 44, 245, 405);
        listCompareRoi.setSelectionModel(listCompare.getSelectionModel());
        listCompareRoi.addListSelectionListener(new ROIListSelectionListener());
        
        listCompareRoi.setCellRenderer(new MachineListRenderer());
        /*listCompareRoi.setSelectionModel(new DefaultListSelectionModel() {
		    private static final long serialVersionUID = 1L;

		    boolean gestureStarted = false;

		    @Override
		    public void setSelectionInterval(int index0, int index1) {
		        if(!gestureStarted){
		            if (isSelectedIndex(index0)) {
		                super.removeSelectionInterval(index0, index1);
		            } else {
		                super.addSelectionInterval(index0, index1);
		            }
		        }
		        gestureStarted = true;
		    }

		    @Override
		    public void setValueIsAdjusting(boolean isAdjusting) {
		        if (isAdjusting == false) {
		            gestureStarted = false;
		        }
		    }

		});*/
        pnlROI.add(listCompareRoi);
        
        panel_4 = new JPanel();
        panel_4.setLayout(null);
        panel_4.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
        panel_4.setBounds(522, 459, 245, 37);
        pnlROI.add(panel_4);
        
        btnROIselectnone = new JButton("None");
        btnROIselectnone.setEnabled(false);
        btnROIselectnone.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		listCompareRoi.clearSelection();
        	}
        });
        btnROIselectnone.setToolTipText("Clear machine selection");
        btnROIselectnone.setBounds(172, 7, 57, 23);
        panel_4.add(btnROIselectnone);
        
        btnROIselectall = new JButton("All");
        btnROIselectall.setEnabled(false);
        btnROIselectall.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent arg0) {
        		int[] count = new int[listModel.size()];
				for(int i=0; i<listModel.size(); ++i)
					count[i] = i;
				listCompareRoi.setSelectedIndices(count);
        	}
        });
        btnROIselectall.setToolTipText("Select all machines");
        btnROIselectall.setBounds(105, 7, 57, 23);
        panel_4.add(btnROIselectall);
        
        lblROIselect = new JLabel("Select:");
        lblROIselect.setEnabled(false);
        lblROIselect.setBounds(37, 11, 46, 14);
        panel_4.add(lblROIselect);
        
        tabsROI = new JTabbedPane(JTabbedPane.TOP);
        tabsROI.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
        tabsROI.setBounds(29, 72, 470, 424);
        pnlROI.add(tabsROI);
        
        pnlProdROI = new JPanel();
        pnlProdROI.setBackground(Color.WHITE);
        tabsROI.addTab("Productivity", null, pnlProdROI, "ROI based on productivity");
        pnlProdROI.setLayout(null);
        
        lblThisToolIlllustrates = new JLabel("This tool illlustrates the long-term financial benfits of particular machines and options in");
        lblThisToolIlllustrates.setFont(new Font("Tahoma", Font.PLAIN, 11));
        lblThisToolIlllustrates.setForeground(Color.GRAY);
        lblThisToolIlllustrates.setBounds(10, 11, 439, 14);
        pnlProdROI.add(lblThisToolIlllustrates);
        
        lblInTermsOf = new JLabel("terms of productivity gains.");
        lblInTermsOf.setForeground(Color.GRAY);
        lblInTermsOf.setBounds(10, 27, 439, 14);
        pnlProdROI.add(lblInTermsOf);
        
        pnlEnergy = new JPanel();
        pnlEnergy.setBackground(Color.WHITE);
        tabsROI.addTab("Energy Efficiency", null, pnlEnergy, "ROI based on machine power usage");
        pnlEnergy.setLayout(null);
        
        lblThisToolHighlights = new JLabel("This tool highlights power consumption differences between machines, and the resulting");
        lblThisToolHighlights.setForeground(Color.GRAY);
        lblThisToolHighlights.setFont(new Font("Tahoma", Font.PLAIN, 11));
        lblThisToolHighlights.setBounds(10, 11, 439, 14);
        pnlEnergy.add(lblThisToolHighlights);
        
        lblImpactOnFinancial = new JLabel("impact on financial returns.");
        lblImpactOnFinancial.setForeground(Color.GRAY);
        lblImpactOnFinancial.setBounds(10, 27, 439, 14);
        pnlEnergy.add(lblImpactOnFinancial);
        
        pnlMaint = new JPanel();
        pnlMaint.setBackground(Color.WHITE);
        tabsROI.addTab("Maintenance", null, pnlMaint, null);
        tabsROI.setMnemonicAt(2, 65);
        pnlMaint.setLayout(null);
        
        lblThisToolDemonstrates_1 = new JLabel("This tool demonstrates the maintenance benefits of machines.");
        lblThisToolDemonstrates_1.setBounds(10, 11, 421, 14);
        lblThisToolDemonstrates_1.setForeground(Color.GRAY);
        lblThisToolDemonstrates_1.setFont(new Font("Tahoma", Font.PLAIN, 11));
        pnlMaint.add(lblThisToolDemonstrates_1);
        
        pnlWaste = new JPanel();
        pnlWaste.setBackground(Color.WHITE);
        tabsROI.addTab("Waste Reduction", null, pnlWaste, "ROI based on waste reduction");
        pnlWaste.setLayout(null);
        
        lblThisToolDemonstrates = new JLabel("This tool demonstrates the waste reduction capabilities of particular machines.");
        lblThisToolDemonstrates.setForeground(Color.GRAY);
        lblThisToolDemonstrates.setFont(new Font("Tahoma", Font.PLAIN, 11));
        lblThisToolDemonstrates.setBounds(10, 11, 439, 14);
        pnlWaste.add(lblThisToolDemonstrates);
        
        pnlQuality = new JPanel();
        pnlQuality.setBackground(Color.WHITE);
        tabsROI.addTab("Slitting Quality", null, pnlQuality, "Slitting quality comparison");
        pnlQuality.setLayout(null);
        
        lblThisToolCompares = new JLabel("This tool compares the quality scores of different machines under particular configurations.");
        lblThisToolCompares.setForeground(Color.GRAY);
        lblThisToolCompares.setFont(new Font("Tahoma", Font.PLAIN, 11));
        lblThisToolCompares.setBounds(10, 11, 439, 14);
        pnlQuality.add(lblThisToolCompares);
        
        machNames = new HashSet<String>();
        jobNames = new HashSet<String>();
	    
		lblStatus = new JLabel(" Ready.");
		lblStatus.setFont(new Font("Tahoma", Font.PLAIN, 12));
		frmTitanRoiCalculator.getContentPane().add(lblStatus, BorderLayout.SOUTH);
		
		lblmmin = new JLabel("(m/min)");
		lblmmin.setEnabled(false);
		lblmmin.setBounds(206, 158, 44, 14);
		pnlJobs.add(lblmmin);
		
		objfilter = new OBJfilter();
		
		 try {
         	FileInputStream fin = new FileInputStream(Consts.SETTINGS_FILENAME);
            ObjectInputStream ois = new ObjectInputStream(fin);
            environment = (Production) ois.readObject();
            ois.close();
            environment.Unlocked = false;
            if(environment.getSchedule() == null)
            	environment.setSchedule(new JobSchedule());
            else{
            	int size = environment.getSchedule().getSize();
            	for(int i=0; i<size; ++i){
            		scheduleModel.addElement(environment.getSchedule().getJob(i));
            	}
            	btnRemoveJob.setEnabled(true);
            	btnUpSchedule.setEnabled(true);
            	btnViewSchedule.setEnabled(true);
            	btnClearSchedule.setEnabled(true);
		    	listSchedule.setSelectedIndex(size);
            }
		 }catch(Exception e){
			 environment = new Production();
		 }
		
		// labels for unit conversion
		labs = new JLabel[7];
		labs[0] = lblmm0; labs[1] = lblmm1; labs[2] =  lblmm2; labs[3] = lblgm3; labs[4] = lblmm3; labs[5] = lblmicro0; labs[6] = lblmmin;

		
		 cmbUnwindType = new JComboBox();
		 cmbUnwindType.setToolTipText("Type of measure to use for the unwind quantity above");
		 cmbUnwindType.addActionListener(new ActionListener() {
		 	public void actionPerformed(ActionEvent e) {
		 		UpdateUnwindAmount();
		 		UpdateJob();
		 	}
		 });
		 cmbUnwindType.setEnabled(false);
		 cmbUnwindType.setModel(new DefaultComboBoxModel(new String[] {"Length (m)", "Weight (kg)", "Diameter (mm)"}));
		 cmbUnwindType.setBounds(92, 124, 95, 20);
		 pnlUnwinds.add(cmbUnwindType);
		 
		 txtWebWidth = new JTextField();
		 txtWebWidth.setToolTipText("Width of mother rolls");
		 txtWebWidth.setText("1350");
		 txtWebWidth.addFocusListener(new FocusAdapter() {
				@Override
				public void focusGained(FocusEvent arg0) {
					txtWebWidth.selectAll();
				}
			});
		 txtWebWidth.setEnabled(false);
		 txtWebWidth.getDocument().addDocumentListener(new DocumentListener() {
				@Override
				public void removeUpdate(DocumentEvent arg0) {
					UpdateJob();
				}
				@Override
				public void insertUpdate(DocumentEvent arg0) {
					UpdateJob();
				}
				@Override
				public void changedUpdate(DocumentEvent arg0) {
				}
			});
		 txtWebWidth.setBounds(92, 26, 86, 20);
		 pnlUnwinds.add(txtWebWidth);
		 txtWebWidth.setColumns(10);
		 
		 lblAverageFlags = new JLabel("Average Flags:");
		 lblAverageFlags.setToolTipText("The average number of flags in each mother roll");
		 lblAverageFlags.setEnabled(false);
		 lblAverageFlags.setBounds(14, 79, 75, 14);
		 pnlUnwinds.add(lblAverageFlags);
		 
		 txtFlagCount = new JTextField();
		 txtFlagCount.setToolTipText("The average number of flags in each mother roll");
		 txtFlagCount.addFocusListener(new FocusAdapter() {
				@Override
				public void focusGained(FocusEvent arg0) {
					txtFlagCount.selectAll();
				}
			});
		 txtFlagCount.getDocument().addDocumentListener(new JobInputChangeListener());
		 txtFlagCount.setEnabled(false);
		 txtFlagCount.setText("1");
		 txtFlagCount.setBounds(92, 76, 43, 20);
		 pnlUnwinds.add(txtFlagCount);
		 txtFlagCount.setColumns(10);
		 
		 lblPerRoll = new JLabel("per roll");
		 lblPerRoll.setEnabled(false);
		 lblPerRoll.setBounds(140, 79, 46, 14);
		 pnlUnwinds.add(lblPerRoll);
		 
		
		txtLimitRunSpeed = new JTextField();
		txtLimitRunSpeed.setToolTipText("Override for top machine speed (may be required for particular materials or environments)");
		txtLimitRunSpeed.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				txtLimitRunSpeed.setEnabled(true);
				chckbxLimitRunSpeed.setSelected(true);
				txtLimitRunSpeed.requestFocus();
				txtLimitRunSpeed.selectAll();
			}
		});
		txtLimitRunSpeed.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				txtLimitRunSpeed.selectAll();
				chckbxLimitRunSpeed.setSelected(true);
			}
		});
		txtLimitRunSpeed.getDocument().addDocumentListener(new JobInputChangeListener());
		txtLimitRunSpeed.setEnabled(false);
		
		txtLimitRunSpeed.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				chckbxLimitRunSpeed.setSelected(true);
			}
		});
		txtLimitRunSpeed.setText("800");
		txtLimitRunSpeed.setColumns(10);
		txtLimitRunSpeed.setBounds(130, 155, 65, 20);
		pnlJobs.add(txtLimitRunSpeed);
		
		cmbRewindType = new JComboBox();
		cmbRewindType.setToolTipText("Type of measure to use for rewind output above");
		cmbRewindType.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UpdateRewindAmount();
				UpdateJob();
			}
		});
		cmbRewindType.setEnabled(false);
		cmbRewindType.setModel(new DefaultComboBoxModel(new String[] {"Length (m)", "Weight (kg)", "Diameter (mm)"}));
		cmbRewindType.setBounds(109, 208, 95, 20);
		pnlJobs.add(cmbRewindType);
		
		chckbxLimitRunSpeed = new JCheckBox("");
		chckbxLimitRunSpeed.setToolTipText("Override for top machine speed (may be required for particular materials or environments)");
		chckbxLimitRunSpeed.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(chckbxLimitRunSpeed.isSelected()){	
					txtLimitRunSpeed.setEnabled(true);
					txtLimitRunSpeed.requestFocus();
					txtLimitRunSpeed.selectAll();
				}else{
					txtLimitRunSpeed.setEnabled(false);
				}
				
				UpdateJob();
			}
		});
		chckbxLimitRunSpeed.setEnabled(false);
		chckbxLimitRunSpeed.setBounds(105, 154, 20, 20);
		pnlJobs.add(chckbxLimitRunSpeed);
		
		lblLimitRunSpeed = new JLabel("Speed Limit:");
		lblLimitRunSpeed.setToolTipText("Override for top machine speed (may be required for particular materials or environments)");
		lblLimitRunSpeed.setEnabled(false);
		lblLimitRunSpeed.setBounds(47, 158, 59, 14);
		pnlJobs.add(lblLimitRunSpeed);
		
		tabbedPane.setMnemonicAt(0, KeyEvent.VK_M);
		tabbedPane.setMnemonicAt(1, KeyEvent.VK_J);
		tabbedPane.setMnemonicAt(2, KeyEvent.VK_S);
		tabbedPane.setMnemonicAt(3, KeyEvent.VK_P);
		tabbedPane.setMnemonicAt(4, KeyEvent.VK_R);
		
		tabsROI.setMnemonicAt(0, KeyEvent.VK_D);
		tabsROI.setMnemonicAt(1, KeyEvent.VK_N);
		tabsROI.setMnemonicAt(3, KeyEvent.VK_W);
		tabsROI.setMnemonicAt(4, KeyEvent.VK_L);
		
		listJobs = new JList(jobModel);
		listJobs.setToolTipText("Select a job to edit options, re-order, or delete");
		listJobs.addListSelectionListener(new JobListSelectionListener());
		listJobs.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		listJobs.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		listJobs.setBounds(522, 44, 245, 405);
		listJobs.setCellRenderer(new JobListRenderer());
		listJobs.setSelectionModel(listJobsAvail.getSelectionModel());
		pnlJob.add(listJobs);
		
		btnJobUp = new JButton("");
		btnJobUp.setToolTipText("Move job up");
		btnJobUp.addActionListener(new JobUpListener());
		try{
			btnJobUp.setIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/up.png"))));
			//btnMachUp.setRolloverEnabled(true);
			//btnMachUp.setRolloverIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/up_over.png"))));
			btnJobUp.setDisabledIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/up_dis.png"))));
			}catch(NullPointerException e11){
				System.out.println("Image load error");
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		btnJobUp.setEnabled(false);
		btnJobUp.setBounds(700, 463, 30, 30);
		pnlJob.add(btnJobUp);
		
		btnJobDown = new JButton("");
		btnJobDown.setToolTipText("Move job down");
		btnJobDown.addActionListener(new JobDownListener());
		try{
			btnJobDown.setIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/down.png"))));
			//btnMachUp.setRolloverEnabled(true);
			//btnMachUp.setRolloverIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/up_over.png"))));
			btnJobDown.setDisabledIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/down_dis.png"))));
			}catch(NullPointerException e11){
				System.out.println("Image load error");
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		btnJobDown.setEnabled(false);
		btnJobDown.setBounds(737, 463, 30, 30);
		pnlJob.add(btnJobDown);
		
		btnNewJob = new JButton("Add New");
		btnNewJob.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewJob.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jobFormReady =  false;
				ResetStatusLabel();
				
				EnableJobForm();
				
				btnJobDelete.setEnabled(true);
            	
            	btnAddAll.setEnabled(true);
                
                /*if(listJobs.getSelectedIndex() == 0)
                	btnJobUp.setEnabled(false);
                else
                	btnJobUp.setEnabled(true);
                
                if(listJobs.getSelectedIndex() == jobModel.getSize()-1)
                	btnJobDown.setEnabled(false);
                else
                	btnJobDown.setEnabled(true);*/
                
				int index = listJobs.getSelectedIndex();
			    int size = jobModel.getSize();
			    
			    if(size >= Consts.JOB_LIST_LIMIT){    // Max list size
			    	ShowMessage("Maximum number of jobs allocated. Please delete before attempting to add more.");
			    	return;
			    }
			    
			    String newName = getUniqueJobName("Job");
			    txtJobName.setText(newName);
			    job = new Job(newName); 
			    jobNames.add(newName.toLowerCase());
			    
			    //If no selection or if item in last position is selected,
			    //add the new one to end of list, and select new one.
			    if (index == -1 || (index+1 == size)) {
			    	
			    	jobModel.addElement(job);
			    	listJobs.setSelectedIndex(size);
			    	listJobsAvail.setSelectedIndex(size);
			    	if(size > 0)
			    		btnJobUp.setEnabled(true);
			
			    //Otherwise insert the new one after the current selection,
			    //and select new one.
			    } else {
			    	jobModel.insertElementAt(job, index + 1);
			    	listJobs.setSelectedIndex(index+1);
			    	listJobsAvail.setSelectedIndex(index+1);
			    }
			    
			    // TODO don't reset form, or add copy button
			    
			    ResetStatusLabel();
			    jobFormReady = true;
			    
			    UpdateJob();
			}
		});
		try {
			btnNewJob.setIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/plus.png"))));
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		btnNewJob.setToolTipText("Add new job");
		btnNewJob.setBounds(522, 460, 110, 36);
		pnlJob.add(btnNewJob);
		
		lblJobConfiguration = new JLabel("Job Configuration");
		lblJobConfiguration.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblJobConfiguration.setBounds(29, 18, 269, 22);
		pnlJob.add(lblJobConfiguration);
		
		btnJobDelete = new JButton("");
		btnJobDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ResetStatusLabel();
				 
		        Job selected = (Job) listJobs.getSelectedValue();
		        jobNames.remove(selected.getName().toLowerCase());
		        
	            ListSelectionModel lsm = listJobs.getSelectionModel();
	            int firstSelected = lsm.getMinSelectionIndex();
	            int lastSelected = lsm.getMaxSelectionIndex();
	            jobModel.removeRange(firstSelected, lastSelected);
	 
	            int size = jobModel.size();
	 
	            if (size == 0) {
	            //List is empty: disable delete, up, and down buttons.
	                /*btnJobDelete.setEnabled(false);
	                btnJobUp.setEnabled(false);
	                btnJobDown.setEnabled(false);*/
	                

	            } else {
	            //Adjust the selection.
	                if (firstSelected == jobModel.getSize()) {
	                //Removed item in last position.
	                    firstSelected--;
	                }
	                listJobs.setSelectedIndex(firstSelected);
	                
	                if(size == 21){  // No longer full list
	                	ResetStatusLabel();
	                }
	                
	                job = (Job) listJobs.getSelectedValue();
	            }
			}
		});
		
		try{
			btnJobDelete.setIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/delete.png"))));
			btnJobDelete.setRolloverEnabled(true);
			btnJobDelete.setRolloverIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/delete_over.png"))));
			btnJobDelete.setDisabledIcon(new ImageIcon(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/delete_dis.png"))));
			}catch(NullPointerException e11){
				System.out.println("Image load error");
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		btnJobDelete.setToolTipText("Delete job");
		btnJobDelete.setRolloverEnabled(true);
		btnJobDelete.setEnabled(false);
		btnJobDelete.setBounds(651, 460, 36, 36);
		pnlJob.add(btnJobDelete);
		
		lblAddNewJobs = new JLabel("Add new jobs to the list on the right, then configure unwind, rewind and material settings below");
		lblAddNewJobs.setBounds(29, 45, 483, 14);
		pnlJob.add(lblAddNewJobs);
		
		lblJobs = new JLabel("Jobs");
		lblJobs.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblJobs.setBounds(522, 19, 85, 14);
		pnlJob.add(lblJobs);
		
		panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Total Output", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_1.setBounds(280, 380, 227, 116);
		pnlJob.add(panel_1);
		
		lblTargetOutputFor = new JLabel("Target output for job:");
		lblTargetOutputFor.setEnabled(false);
		lblTargetOutputFor.setBounds(47, 27, 129, 14);
		panel_1.add(lblTargetOutputFor);
		
		txtTargetTotal = new JTextField();
		txtTargetTotal.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				txtTargetTotal.selectAll();
			}
		});
		txtTargetTotal.getDocument().addDocumentListener(new JobInputChangeListener());
		txtTargetTotal.setToolTipText("Total output quantity for this job");
		txtTargetTotal.setText("10000");
		txtTargetTotal.setEnabled(false);
		txtTargetTotal.setColumns(10);
		txtTargetTotal.setBounds(47, 48, 118, 20);
		
		panel_1.add(txtTargetTotal);
		
		cmbTargetTotal = new JComboBox();
		cmbTargetTotal.setToolTipText("Type of measure to use for output quantity above");
		cmbTargetTotal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UpdateTotalsAmount();
				UpdateJob();
			}
		});
		cmbTargetTotal.setModel(new DefaultComboBoxModel(new String[] {"Length (m)", "Weight (kg)", "Weight (tonnes)"}));
		cmbTargetTotal.setEnabled(false);
		cmbTargetTotal.setBounds(47, 74, 118, 20);
		panel_1.add(cmbTargetTotal);
		
		panel_2 = new JPanel();
		panel_2.setLayout(null);
		panel_2.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Name", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_2.setBounds(20, 72, 250, 83);
		pnlJob.add(panel_2);
		
		txtJobName = new JTextField();
		txtJobName.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				txtJobName.selectAll();
			}
		});
		txtJobName.setBounds(90, 30, 145, 28);
		panel_2.add(txtJobName);
		txtJobName.getDocument().addDocumentListener(new DocumentListener() {
			@Override
			public void changedUpdate(DocumentEvent arg0) {
			}
			@Override
			public void insertUpdate(DocumentEvent arg0) {
				UpdateJobName();
			}
			@Override
			public void removeUpdate(DocumentEvent arg0) {
				UpdateJobName();
			}
		});
		txtJobName.setToolTipText("Set the name of this job");
		txtJobName.setFont(new Font("Tahoma", Font.BOLD, 12));
		txtJobName.setEnabled(false);
		txtJobName.setColumns(10);
		
		lblJobName = new JLabel("Job name:");
		lblJobName.setToolTipText("Set the name of this job");
		lblJobName.setEnabled(false);
		lblJobName.setBounds(22, 31, 60, 24);
		panel_2.add(lblJobName);
		lblJobName.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		btnResetJobs = new JButton("Reset");
		btnResetJobs.setBounds(20, 460, 100, 36);
		pnlJob.add(btnResetJobs);
		btnResetJobs.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ResetJobForm();
				UpdateJob();
			}
		});
		btnResetJobs.setToolTipText("Reset the form");
		btnResetJobs.setEnabled(false);
		pnlJob.setFocusTraversalPolicy(new FocusTraversalOnArray(new Component[]{cmbMaterials, txtThickness, txtDensity, cmbUnwindCore, txtUnwindAmount, txtSlits, txtSlitWidth, cmbRewindCore, txtRewindAmount, cmbJobDomain, lblPresets, lblThickness_1, lblDensity_1, pnlMaterials, lblWebWidthmm, lblmm0, lblUnwindCoremm, lblmm1, lblUnwindLength, pnlUnwinds, lblmicro0, lblgm3, label_3, pnlJobs, lblTargetRewindLength, lblSlitWidth, lblSlitCount, lblTrimtotal, lblTrim, lblRewindCoremm, lblPer_1, lblmm3, lblmm2}));
		Image img = null;
		try {
			img = ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/refresh.png"));
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		BufferedImage bi = new BufferedImage(img.getWidth(null), img.getHeight(null), BufferedImage.TYPE_INT_ARGB);
		Graphics g = bi.createGraphics();
		g.drawImage(img, 0, 0, 25, 25, null);
	}
	
	double roundTwoDecimals(double d) {
        DecimalFormat twoDForm = new DecimalFormat("#.##");
	    return Double.valueOf(twoDForm.format(d));
	}
	
	double roundNDecimals(double d, int n) {
		DecimalFormat twoDForm;
		switch(n){
		case 1: twoDForm = new DecimalFormat("#.#"); break;
		case 2: twoDForm = new DecimalFormat("#.##"); break;
		case 3: twoDForm = new DecimalFormat("#.###"); break;
		case 4: twoDForm = new DecimalFormat("#.####"); break;
		case 5: twoDForm = new DecimalFormat("#.#####"); break;
		case 6: twoDForm = new DecimalFormat("#.######"); break;
		case 7: twoDForm = new DecimalFormat("#.#######"); break;
		case 8: twoDForm = new DecimalFormat("#.########"); break;
		case 9: twoDForm = new DecimalFormat("#.#########"); break;
		case 10: twoDForm = new DecimalFormat("#.##########"); break;
		default: twoDForm = new DecimalFormat("#.##"); break;
		}
		
		return Double.valueOf(twoDForm.format(d));
	}
	
	public static String getSignificant(double value, int sigFigs) {
        MathContext mc = new MathContext(sigFigs, RoundingMode.DOWN);
        BigDecimal bigDecimal = new BigDecimal(value, mc);
        return bigDecimal.toPlainString();
	}	

	
	class DeleteButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            /* 
             * This method can be called only if
             * there's a valid selection,
             * so go ahead and remove whatever's selected.
             */
        	
        	ResetStatusLabel();
 
	        Machine selected = (Machine) listMachines.getSelectedValue();
	        machNames.remove(selected.name.toLowerCase());
	        
            ListSelectionModel lsm = listMachines.getSelectionModel();
            int firstSelected = lsm.getMinSelectionIndex();
            int lastSelected = lsm.getMaxSelectionIndex();
            listModel.removeRange(firstSelected, lastSelected);
 
            int size = listModel.size();
 
            if (size == 0) {
            //List is empty: disable delete, up, and down buttons.
                btnMachDelete.setEnabled(false);
                btnMachUp.setEnabled(false);
                btnMachDown.setEnabled(false);
                listMachines.clearSelection();
                formReady = false;
                machine = null;
                UpdateForm();
            } else {
            //Adjust the selection.
                if (firstSelected == listModel.getSize()) {
                //Removed item in last position.
                    firstSelected--;
                }
                listMachines.setSelectedIndex(firstSelected);
                
                if(size == 21){  // No longer full list
                	ResetStatusLabel();
                }
                
                machine = (Machine) listMachines.getSelectedValue();
            }
        }
    }

	
	@SuppressWarnings("unused")
	private void PopulateComboBox(JComboBox c, String[] elements){
		for(int i=0; i < elements.length; ++i){
			c.addItem(elements[i]);
		}
	}
	
	/*private void ConvertComboBox(JComboBox c, double multiplier){
		Double currentVal = Double.parseDouble(((JTextField) c.getEditor().getEditorComponent()).getText());
		currentVal *= multiplier;
		
		String[] m = new String[c.getModel().getSize()];
		for(int i=0; i < c.getModel().getSize(); ++i){
			double val = Double.parseDouble(c.getModel().getElementAt(i).toString());
			val *= multiplier;
			m[i] = Double.toString(roundTwoDecimals(val));
		}
		c.setModel(new DefaultComboBoxModel(m));
		
		((JTextField) c.getEditor().getEditorComponent()).setText(Double.toString(roundTwoDecimals(currentVal)));
		
	}*/
	
	private void ConvertTextBox(JTextField t, double multiplier){
		double val = Double.parseDouble(t.getText());
		val *= multiplier;
		t.setText(Double.toString(roundTwoDecimals(val)));
	}
	
	private void ConvertLabels(JLabel[] labs, boolean toImperial){
		if(toImperial){
			// Metric -> Imperial
			for(int i=0; i < labs.length; ++i){
				if(labs[i].getText().equals("(�m)"))
					labs[i].setText("(mil)");
				if(labs[i].getText().equals("(mm)"))
					labs[i].setText("(in)");
				if(labs[i].getText().equals("(m)"))
					labs[i].setText("(ft)");
				if(labs[i].getText().equals("(kg)"))
					labs[i].setText("(lb)");
				if(labs[i].getText().equals("(g)"))
					labs[i].setText("(oz)");
				if(labs[i].getText().equals("(tonne)"))
					labs[i].setText("(US ton)");
				if(labs[i].getText().equals("(m/min)"))
					labs[i].setText("(ft/min)");
			}
		}else{
			// Imperial -> Metric
			for(int i=0; i < labs.length; ++i){
				if(labs[i].getText().equals("(mil)"))
					labs[i].setText("(�m)");
				if(labs[i].getText().equals("(in)"))
					labs[i].setText("(mm)");
				if(labs[i].getText().equals("(ft)"))
					labs[i].setText("(m)");
				if(labs[i].getText().equals("(lb)"))
					labs[i].setText("(kg)");
				if(labs[i].getText().equals("(oz)"))
					labs[i].setText("(g)");
				if(labs[i].getText().equals("(US ton)"))
					labs[i].setText("(tonne)");
				if(labs[i].getText().equals("(ft/min)"))
					labs[i].setText("(m/min)");
			}
		}
	}
	
	private void ClearComponents(){
		//cmbRewindCore.removeAllItems();
	}
	
	private void SetComponents(){
		//PopulateComboBox(cmbRewindCore, Consts.REWIND_CORE_MM);
		//lblRewindCoremm.setText(Consts.LBL_REWIND_CORE_MM);
	}
	
	@SuppressWarnings("unused")
	private void ResetComponents(){
		ClearComponents();
		SetComponents();
	}
	
	private void ChangeUnits(){
		
		boolean backup = jobFormReady;
		jobFormReady = false;
		
		if(jobModel.getSize() > 0){
		
			//ClearComponents();
			if(metric){
				// Change metric -> imperial
				//PopulateComboBox(cmbRewindCore, Consts.REWIND_CORE_IN);
				//lblRewindCoremm.setText(Consts.LBL_REWIND_CORE_IN);
				ConvertTextBox(txtThickness, Core.MicroToMil(1));
				ConvertTextBox(txtSlitWidth, Core.MMToIn(1));
				ConvertTextBox(txtWebWidth, Core.MMToIn(1));
				ConvertTextBox(txtLimitRunSpeed, Core.MToFt(1));
				ConvertTextBox(txtTargetTotal, (cmbTargetTotal.getSelectedIndex()==0 ? Core.MToFt(1) : (cmbTargetTotal.getSelectedIndex()==1 ? Core.KgToTon(1) : Core.TonneToTon(1))));
				ConvertTextBox(txtRewindAmount, (cmbRewindType.getSelectedIndex()==0 ? Core.MToFt(1) : (cmbRewindType.getSelectedIndex()==1 ? Core.KgToTon(1) : Core.MMToIn(1))));
				ConvertTextBox(txtUnwindAmount, (cmbUnwindType.getSelectedIndex()==0 ? Core.MToFt(1) : (cmbUnwindType.getSelectedIndex()==1 ? Core.KgToTon(1) : Core.MMToIn(1))));
				
				int[] indices = {cmbUnwindType.getSelectedIndex(), cmbRewindType.getSelectedIndex(), cmbTargetTotal.getSelectedIndex() };
				cmbUnwindType.setModel(new DefaultComboBoxModel(new String[] {"Length (ft)", "Weight (ton)", "Diameter (in)"}));
				cmbRewindType.setModel(new DefaultComboBoxModel(new String[] {"Length (ft)", "Weight (ton)", "Diameter (in)"}));
				cmbTargetTotal.setModel(new DefaultComboBoxModel(new String[] {"Length (ft)", "Weight (ton)"}));
				if(oldTotalsIndex==2) 
					oldTotalsIndex=1;
				cmbUnwindType.setSelectedIndex(indices[0]);
				cmbRewindType.setSelectedIndex(indices[1]);
				if(indices[2] > 1)
					indices[2] = 1;
				cmbTargetTotal.setSelectedIndex(indices[2]);
				
				//ConvertComboBox(cmbRewindCore, Core.MMToIn(1));
				//ConvertComboBox(cmbUnwindCore, Core.MMToIn(1));
				Double currVal = Double.parseDouble(((JTextField) cmbRewindCore.getEditor().getEditorComponent()).getText());
				Double currVal2 = Double.parseDouble(((JTextField) cmbUnwindCore.getEditor().getEditorComponent()).getText());
				currVal *=  Core.MMToIn(1);
				currVal2 *=  Core.MMToIn(1);
				cmbRewindCore.setModel(new DefaultComboBoxModel(Consts.REWIND_CORE_IN));
				cmbUnwindCore.setModel(new DefaultComboBoxModel(Consts.UNWIND_CORE_IN));
				((JTextField) cmbRewindCore.getEditor().getEditorComponent()).setText(Double.toString(roundTwoDecimals(currVal)));
				((JTextField) cmbUnwindCore.getEditor().getEditorComponent()).setText(Double.toString(roundTwoDecimals(currVal2)));
				
				lblTrim.setText("0 in");
			}else{
				// Change imperial -> metric
				//SetComponents();
				ConvertTextBox(txtThickness, Core.MilToMicro(1));
				ConvertTextBox(txtSlitWidth, Core.InToMM(1));
				ConvertTextBox(txtWebWidth, Core.InToMM(1));
				ConvertTextBox(txtLimitRunSpeed, Core.FtToM(1));
				ConvertTextBox(txtTargetTotal, (((Job)listJobs.getSelectedValue()).getTotalType()==0 ? Core.FtToM(1) : (((Job)listJobs.getSelectedValue()).getTotalType()==1 ? Core.TonToKg(1) : Core.TonToTonne(1))));
				ConvertTextBox(txtRewindAmount, (cmbRewindType.getSelectedIndex()==0 ? Core.FtToM(1) : (cmbRewindType.getSelectedIndex()==1 ? Core.TonToKg(1) : Core.InToMM(1))));
				ConvertTextBox(txtUnwindAmount, (cmbUnwindType.getSelectedIndex()==0 ? Core.FtToM(1) : (cmbUnwindType.getSelectedIndex()==1 ? Core.TonToKg(1) : Core.InToMM(1))));
				
				int[] indices = {cmbUnwindType.getSelectedIndex(), cmbRewindType.getSelectedIndex(), cmbTargetTotal.getSelectedIndex() };
				cmbUnwindType.setModel(new DefaultComboBoxModel(new String[] {"Length (m)", "Weight (kg)", "Diameter (mm)"}));
				cmbRewindType.setModel(new DefaultComboBoxModel(new String[] {"Length (m)", "Weight (kg)", "Diameter (mm)"}));
				cmbTargetTotal.setModel(new DefaultComboBoxModel(new String[] {"Length (m)", "Weight (kg)", "Weight (tonnes)"}));
				cmbUnwindType.setSelectedIndex(indices[0]);
				cmbRewindType.setSelectedIndex(indices[1]);
				cmbTargetTotal.setSelectedIndex(((Job)listJobs.getSelectedValue()).getTotalType());//indices[2]);
				oldTotalsIndex = ((Job)listJobs.getSelectedValue()).getTotalType();
				
				//ConvertComboBox(cmbRewindCore, Core.InToMM(1));
				//ConvertComboBox(cmbUnwindCore, Core.InToMM(1));
				Double currVal = Double.parseDouble(((JTextField) cmbRewindCore.getEditor().getEditorComponent()).getText());
				Double currVal2 = Double.parseDouble(((JTextField) cmbUnwindCore.getEditor().getEditorComponent()).getText());
				currVal *=  Core.InToMM(1);
				currVal2 *=  Core.InToMM(1);
				cmbRewindCore.setModel(new DefaultComboBoxModel(Consts.REWIND_CORE_MM));
				cmbUnwindCore.setModel(new DefaultComboBoxModel(Consts.UNWIND_CORE_MM));
				((JTextField) cmbRewindCore.getEditor().getEditorComponent()).setText(Double.toString(roundTwoDecimals(currVal)));
				((JTextField) cmbUnwindCore.getEditor().getEditorComponent()).setText(Double.toString(roundTwoDecimals(currVal2)));
				
				lblTrim.setText("0 mm");

			}
		
		}
		
		jobFormReady = backup;
		
		ConvertLabels(labs, metric);
		
		metric = !metric;
		
		if(jobModel.getSize() < 1)
			ResetJobForm();
		
		UpdateJobForm();
	
		UpdateTrim();
		
		UpdateNumericalAnalysis();
		
	}
	
	private void UpdateTrim(){
		// Update trim display on form
		Double trim = 0.;
		try{
			trim = Double.parseDouble(txtWebWidth.getText()) - Double.parseDouble(txtSlits.getText()) * Double.parseDouble(txtSlitWidth.getText());
			trim = Math.max(trim, 0.);
			if(metric)
				lblTrim.setText(Double.toString(roundTwoDecimals(trim)) + " mm");
			else
				lblTrim.setText(Double.toString(roundTwoDecimals(trim)) + " in");
		}catch(Exception e2)
		{
			if(metric)
				lblTrim.setText("0 mm");
			else
				lblTrim.setText("0 in");
		}
	}
	
	
	public void UpdateMachine(){

		if(formReady){
		
	    if (txtMachName.getText().equals("")) {
	    //User didn't type in a name...
	    	ShowMessage("Please enter a machine name.");
	    	return;
	    }
	    
	    Machine m = (Machine) listMachines.getSelectedValue();
	
	    //int index = listMachines.getSelectedIndex();
	    //int size = listModel.getSize();
	    
	    
	    if(machNames.contains(txtMachName.getText().toLowerCase()) && (!(m.name.equals(txtMachName.getText())))){
	    	ShowMessage("Duplicate machine names not allowed. Please choose a different name.");
	    	return;
	    }
	    machNames.remove(m.name.toLowerCase());
	    machNames.add(txtMachName.getText().toLowerCase());
		
	    // Option is only selected if it is applicable (ie. enabled) and selected (checked)
	    boolean[] opts = { chckbxSpliceTable.isSelected() && chckbxSpliceTable.isEnabled(), 
	    				   chckbxAlignmentGuide.isSelected() && chckbxAlignmentGuide.isEnabled(), 
	    				   chckbxRollConditioning.isSelected() && chckbxRollConditioning.isEnabled(), 
	    				   chckbxTurretSupport.isSelected() && chckbxTurretSupport.isEnabled(), 
	    				   chckbxAutostripping.isSelected() && chckbxAutostripping.isEnabled(), 
	    				   chckbxFlag.isSelected() && chckbxFlag.isEnabled(), 
	    				   chckbxAutoCutoff.isSelected() && chckbxAutoCutoff.isEnabled(), 
	    				   chckbxAutoTapeCore.isSelected() && chckbxAutoTapeCore.isEnabled(), 
	    				   chckbxAutoTapeTail.isSelected() && chckbxAutoTapeTail.isEnabled(), 
	    				   chckbxExtraRewind.isSelected() && chckbxExtraRewind.isEnabled() };
	    
	    //If no selection or if item in last position is selected,
	    //add the new one to end of list, and select new one.
	    m.update(txtMachName.getText(), 
	        		model, 
	        		cmbSpeed.isEnabled() ? (String) cmbSpeed.getSelectedItem() : "", 
    				cmbKnives.isEnabled() ? (String) cmbKnives.getSelectedItem() : "", 
					cmbCorepos.isEnabled() ? (String) cmbCorepos.getSelectedItem() : "", 
					cmbUnloader.isEnabled() ? (String) cmbUnloader.getSelectedItem() : "", 
					cmbUnwindDrive.isEnabled() ? (String) cmbUnwindDrive.getSelectedItem() : "", 
					cmbRewindCtrl.isEnabled() ? (String) cmbRewindCtrl.getSelectedItem() : "", 
    				opts);
	    
	    if(machine.isCustom()){
	    	m.setCustom(true);
	    	m.setCustomMachine(machine.getCustomMachine());
	    }
	    
	    ResetStatusLabel();
	    //btnMachReset.doClick();
	    
		}
	}
	
	class UpListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			ResetStatusLabel();
			int moveMe = listMachines.getSelectedIndex();
			 //UP ARROW BUTTON
            if (moveMe != 0) {     
            //not already at top
                swap(moveMe, moveMe-1);
                listMachines.setSelectedIndex(moveMe-1);
                listMachines.ensureIndexIsVisible(moveMe-1);
                machine = (Machine) listMachines.getSelectedValue();
            }
		}
	}
	
	//Listen for clicks on the up and down arrow buttons.
    class DownListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            //This method can be called only when
            //there's a valid selection,
            //so go ahead and move the list item.
        	ResetStatusLabel();
            int moveMe = listMachines.getSelectedIndex();
           
            //DOWN ARROW BUTTON
            if (moveMe != listModel.getSize()-1) {
            //not already at bottom
                swap(moveMe, moveMe+1);
                listMachines.setSelectedIndex(moveMe+1);
                listMachines.ensureIndexIsVisible(moveMe+1);
                machine = (Machine) listMachines.getSelectedValue();
            }
            
        }
    }
    
    class JobUpListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			ResetStatusLabel();
			int moveMe = listJobs.getSelectedIndex();
			 //UP ARROW BUTTON
            if (moveMe != 0) {     
            //not already at top
                swapJob(moveMe, moveMe-1);
                listJobs.setSelectedIndex(moveMe-1);
                listJobs.ensureIndexIsVisible(moveMe-1);
                job = (Job) listJobs.getSelectedValue();
            }
		}
	}
	
	//Listen for clicks on the up and down arrow buttons.
    class JobDownListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            //This method can be called only when
            //there's a valid selection,
            //so go ahead and move the list item.
        	ResetStatusLabel();
            int moveMe = listJobs.getSelectedIndex();
           
            //DOWN ARROW BUTTON
            if (moveMe != jobModel.getSize()-1) {
            //not already at bottom
                swapJob(moveMe, moveMe+1);
                listJobs.setSelectedIndex(moveMe+1);
                listJobs.ensureIndexIsVisible(moveMe+1);
                job = (Job) listJobs.getSelectedValue();
            }
            
        }
    }
    
    class ScheduleUpListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			ResetStatusLabel();
			int moveMe = listSchedule.getSelectedIndex();
			 //UP ARROW BUTTON
            if (moveMe != 0) {     
            //not already at top
                swapSchedule(moveMe, moveMe-1);
                listSchedule.setSelectedIndex(moveMe-1);
                listSchedule.ensureIndexIsVisible(moveMe-1);
                environment.getSchedule().swap(moveMe, moveMe-1);
            }
		}
	}
	
	//Listen for clicks on the up and down arrow buttons.
    class ScheduleDownListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            //This method can be called only when
            //there's a valid selection,
            //so go ahead and move the list item.
        	ResetStatusLabel();
            int moveMe = listSchedule.getSelectedIndex();
           
            //DOWN ARROW BUTTON
            if (moveMe != scheduleModel.getSize()-1) {
            //not already at bottom
                swapSchedule(moveMe, moveMe+1);
                listSchedule.setSelectedIndex(moveMe+1);
                listSchedule.ensureIndexIsVisible(moveMe+1);
                environment.getSchedule().swap(moveMe, moveMe+1);
            }
            
        }
    }
    
    class FieldUpdateListener implements FocusListener, ActionListener {

    	int type;
    	
    	FieldUpdateListener(int t){
    		super();
    		type = t;
    	}
    	
		@Override
		public void focusGained(FocusEvent arg0e) {
			if(arg0e.getSource() instanceof JTextField)
				//if (!(((JTextField) arg0e.getSource()).getSelectedText() == null))
					((JTextField)arg0e.getSource()).selectAll();
			}

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			UpdateLabel(arg0, type);
		}

		@Override
		public void focusLost(FocusEvent arg0) {
			UpdateLabel(arg0, type);
		}
		
		private void UpdateLabel(AWTEvent e, int type){
			int result = 0;
			
			// Shifts, hours per day etc.
			if(type==1){
				try{ 
					result = Integer.parseInt(txtShiftLength.getText()) * Integer.parseInt(txtShiftCount.getText()); 
					lblDayLength2.setText(Integer.toString(result) + " hours");
				}
				catch(Exception e2)
				{
					lblDayLength2.setText("0 hours"); 
				}
				
				try{
					result *= Integer.parseInt(txtDaysYear.getText());
					lblHoursYear2.setText(Integer.toString(result) + " hours"); 
				}
				catch(Exception e2){
					lblHoursYear2.setText("0 hours");
				}
			}
			
			// Trim, slit width etc.
			else if(type==2){
				try{
					result = Integer.parseInt(txtWebWidth.getText()) - Integer.parseInt(txtSlits.getText()) * Integer.parseInt(txtSlitWidth.getText());
					lblTrim.setText(Integer.toString(result) + " mm");
				}catch(Exception e2)
				{
					lblTrim.setText("0 mm");
				}
				UpdateJob();
			}
			
			// Rewind/output: reels required etc.
			else if(type==3){
				//double total_length = 0;
				//double total_quantity = 0;
				//TimeDomain domain = TimeDomain.valueOf(cmbJobDomain.getSelectedItem().toString());
				
				double thickness = 0.000001 * Double.parseDouble(txtThickness.getText());
				double density = 1000 * Double.parseDouble(txtDensity.getText()); // approx: kg m^-3
				double core = 0.001 * Double.parseDouble(((JTextField) cmbRewindCore.getEditor().getEditorComponent()).getText());
				double width = 0.001 * Double.parseDouble(txtWebWidth.getText());
				
				double length=0.0, diam=0.0, weight=0.0;
				
				if(e.getSource() instanceof JTextField){

					if(((JTextField)e.getSource()).getName().equals("RewindLength")){
						length = Double.parseDouble(txtRewindAmount.getText());
						diam = Core.LengthToDiam(length, thickness, core);
						weight = Core.LengthToWeight(length, thickness, width, density);
					}
					else if(((JTextField)e.getSource()).getName().equals("RewindWeight")){
						weight = 1000 * Double.parseDouble(txtRewindAmount.getText());
						length = Core.WeightToLength(weight, thickness, width, density);
						diam = Core.LengthToDiam(length, thickness, core);
					}
					else if(((JTextField)e.getSource()).getName().equals("RewindDiam")){
						diam = 0.001 * Double.parseDouble(txtRewindAmount.getText());
						length = Core.DiamToLength(diam, thickness, core);
						weight = Core.LengthToWeight(length, thickness, width, density);
					}
					
				}else if(e.getSource() instanceof JComboBox){
					
				}
				
				UpdateJob();
			
			}
			
			// Unwind length/diam etc.
			else if(type == 4){
				
				double thickness = 0.000001 * Double.parseDouble(txtThickness.getText());
				double density = 1000 * Double.parseDouble(txtDensity.getText()); // approx: kg m^-3
				double core = 0.001 * Double.parseDouble(((JTextField) cmbUnwindCore.getEditor().getEditorComponent()).getText());
				double width = 0.001 * Double.parseDouble(txtWebWidth.getText());
				
				double length=0.0, diam=0.0, weight=0.0;
				
				if(e.getSource() instanceof JTextField){

					if(((JTextField)e.getSource()).getName().equals("UnwindAmount")){
						try{
							length = Double.parseDouble(txtUnwindAmount.getText());
						}catch(NumberFormatException e1){ return; }
						if(!Double.isNaN(length) && length >= 0){
							diam = Core.LengthToDiam(length, thickness, core);
							weight = Core.LengthToWeight(length, thickness, width, density);
						}
						
					}
					else if(((JTextField)e.getSource()).getName().equals("UnwindWeight")){
						try{
							weight = Double.parseDouble(txtUnwindAmount.getText());
						}catch(NumberFormatException e1){ return; }
						if(!Double.isNaN(weight) && weight >= 0){
							length = Core.WeightToLength(weight, thickness, width, density);
							diam = Core.LengthToDiam(length, thickness, core);
						}
					}
					else if(((JTextField)e.getSource()).getName().equals("UnwindDiam")){
						try{
							diam = 0.001 * Double.parseDouble(txtUnwindAmount.getText());
						}catch(NumberFormatException e1){ return; }
						if(!Double.isNaN(diam) && diam >= 0){
							length = Core.DiamToLength(diam, thickness, core);
							weight = Core.LengthToWeight(length, thickness, width, density);
						}
					}
					
				}else if(e.getSource() instanceof JComboBox){
					
					
				}
				
				UpdateJob();
			}
		}

    }
    
    private void UpdateUnwindAmount(){
	    if(jobFormReady && (oldUnwindIndex != cmbUnwindType.getSelectedIndex())){
	 		try{
	 			
	 			Double val = Double.parseDouble(txtUnwindAmount.getText());
	 			Double newval = val;
	 			
	 			Double density = 1000 * Double.parseDouble(txtDensity.getText());
				Double thickness = 0.000001 * Double.parseDouble(txtThickness.getText());
			
				Double width = 0.001 * Double.parseDouble(txtWebWidth.getText());
				Double core = 0.001 * Double.parseDouble(((JTextField) cmbUnwindCore.getEditor().getEditorComponent()).getText());
				
				if(! metric){
					//density = density;
					thickness = thickness * 25.4;
					width = width * 25.4;
					core = core * 25.4;
				}
	 			
	 			if(cmbUnwindType.getSelectedIndex() == 0){
	 				// length
	 				if(oldUnwindIndex==1)
	 					newval = Core.WeightToLength((metric ? val : Core.TonToKg(val)), thickness, width, density);
	 				if(oldUnwindIndex==2)
	 					newval = Core.DiamToLength(0.001 * (metric ? val : Core.InToMM(val)), thickness, core);
	 				oldUnwindIndex = 0;
	 				if(!metric)
	 					newval = Core.MToFt(newval);
	 			}else if(cmbUnwindType.getSelectedIndex() == 1){
	 				// weight
	 				if(oldUnwindIndex==0)
	 					newval = Core.LengthToWeight((metric ? val : Core.FtToM(val)), thickness, width, density);
		 			if(oldUnwindIndex==2)
		 				newval = Core.LengthToWeight(Core.DiamToLength(0.001 * (metric ? val : Core.InToMM(val)), thickness, core), thickness, width, density);
		 			oldUnwindIndex = 1;
		 			if(!metric)
	 					newval = Core.KgToTon(newval);
	 			}else if(cmbUnwindType.getSelectedIndex() == 2){
	 				// diam
	 				if(oldUnwindIndex==0)
	 					newval = 1000 * Core.LengthToDiam((metric ? val : Core.FtToM(val)), thickness, core);
		 			if(oldUnwindIndex==1)
		 				newval = 1000 * Core.LengthToDiam(Core.WeightToLength((metric ? val : Core.TonToKg(val)), thickness, width, density), thickness, core);
		 			oldUnwindIndex = 2;
		 			if(!metric)
	 					newval = Core.MMToIn(newval);
	 			}
	 			jobFormReady = false;
	 			txtUnwindAmount.setText(Double.toString(roundNDecimals(newval,4)));
	 			jobFormReady = true;
	 		}catch(NumberFormatException e2){
	 			txtUnwindAmount.setText(("0"));
	 		}
		}
    }
 
    private void UpdateRewindAmount(){
	    if(jobFormReady && (oldRewindIndex != cmbRewindType.getSelectedIndex())){
	 		try{
	 			
	 			Double val = Double.parseDouble(txtRewindAmount.getText());
	 			Double newval = val;
	 			
	 			Double density = 1000 * Double.parseDouble(txtDensity.getText());
				Double thickness = 0.000001 * Double.parseDouble(txtThickness.getText());
			
				Double width = 0.001 * Double.parseDouble(txtWebWidth.getText());
				Double core = 0.001 * Double.parseDouble(((JTextField) cmbRewindCore.getEditor().getEditorComponent()).getText());
				
				if(! metric){
					//density = density;
					thickness = thickness * 25.4;
					width = width * 25.4;
					core = core * 25.4;
				}
	 			
	 			if(cmbRewindType.getSelectedIndex() == 0){
	 				// length
	 				if(oldRewindIndex==1)
	 					newval = Core.WeightToLength((metric ? val : Core.TonToKg(val)), thickness, width, density);
	 				if(oldRewindIndex==2)
	 					newval = Core.DiamToLength(0.001 * (metric ? val : Core.InToMM(val)), thickness, core);
	 				oldRewindIndex = 0;
	 				cmbJobDomain.setEnabled(true);
	 				if(!metric)
	 					newval = Core.MToFt(newval);
	 			}else if(cmbRewindType.getSelectedIndex() == 1){
	 				// weight
	 				if(oldRewindIndex==0)
	 					newval = Core.LengthToWeight((metric ? val : Core.FtToM(val)), thickness, width, density);
		 			if(oldRewindIndex==2)
		 				newval = Core.LengthToWeight(Core.DiamToLength(0.001 * (metric ? val : Core.InToMM(val)), thickness, core), thickness, width, density);
		 			oldRewindIndex = 1;
		 			cmbJobDomain.setEnabled(true);
		 			if(!metric)
	 					newval = Core.KgToTon(newval);
	 			}else if(cmbRewindType.getSelectedIndex() == 2){
	 				// diam
	 				if(oldRewindIndex==0)
	 					newval = 1000 * Core.LengthToDiam((metric ? val : Core.FtToM(val)), thickness, core);
		 			if(oldRewindIndex==1)
		 				newval = 1000 * Core.LengthToDiam(Core.WeightToLength((metric ? val : Core.TonToKg(val)), thickness, width, density), thickness, core);
		 			oldRewindIndex = 2;
		 			cmbJobDomain.setEnabled(false);
		 			if(!metric)
	 					newval = Core.MMToIn(newval);
	 			}
	 			jobFormReady = false;
	 			txtRewindAmount.setText(Double.toString(roundNDecimals(newval,4)));
	 			jobFormReady = true;
	 		}catch(NumberFormatException e2){
	 			txtRewindAmount.setText(("0"));
	 		}
		}
    }
    
    private void UpdateTotalsAmount(){
	    if(jobFormReady && (oldTotalsIndex != cmbTargetTotal.getSelectedIndex())){
	 		try{
	 			
	 			Double val = Double.parseDouble(txtTargetTotal.getText());
	 			Double newval = val;
	 			
	 			Double density = 1000 * Double.parseDouble(txtDensity.getText());
				Double thickness = 0.000001 * Double.parseDouble(txtThickness.getText());
				
				Double width = 0.001 * Double.parseDouble(txtWebWidth.getText());
				
				if(! metric){
					//density = density;
					thickness = thickness * 25.4;
					width = width * 25.4;
				}
				
	 			if(cmbTargetTotal.getSelectedIndex() == 0){
	 				// length
	 				if(oldTotalsIndex==1)
	 					newval = Core.WeightToLength((metric ? val : Core.TonToKg(val)), thickness, width, density);
	 				if(oldTotalsIndex==2)
	 					newval = Core.WeightToLength(1000 * (metric ? val : Core.TonToKg(val)), thickness, width, density);
	 				oldTotalsIndex = 0;
	 				if(!metric)
	 					newval = Core.MToFt(newval);
	 			}else if(cmbTargetTotal.getSelectedIndex() == 1){
	 				// weight
	 				if(oldTotalsIndex==0)
	 					newval = Core.LengthToWeight((metric ? val : Core.FtToM(val)), thickness, width, density);
		 			if(oldTotalsIndex==2)
		 				newval = (metric ? val : Core.TonToKg(val)) * 1000;
		 			oldTotalsIndex = 1;
		 			if(!metric)
	 					newval = Core.KgToTon(newval);
	 			}else if(cmbTargetTotal.getSelectedIndex() == 2){
	 				// weight tonnes
	 				if(oldTotalsIndex==0)
	 					newval = Core.LengthToWeight((metric ? val : Core.FtToM(val)), thickness, width, density)/1000;
		 			if(oldTotalsIndex==1)
		 				newval = (metric ? val : Core.TonToKg(val))/1000;
		 			oldTotalsIndex = 2;
		 			if(!metric)
	 					newval = Core.TonneToTon(newval);
	 			}
	 			jobFormReady = false;
	 			txtTargetTotal.setText(Double.toString(roundNDecimals(newval,4)));
	 			jobFormReady = true;
	 		}catch(NumberFormatException e2){
	 			txtTargetTotal.setText(("0"));
	 		}
		}
    }
    
    private void UpdateSetReel(){
	    if(jobFormReady && (SetReelType != cmbJobDomain.getSelectedIndex())){
			Double newval = 0., val = 0.;
			int slits = 0;
			try{
				val = Double.parseDouble(txtRewindAmount.getText());
				slits = Integer.parseInt(txtSlits.getText());
			} catch(NumberFormatException ee){
				val = 0.;
				slits = 0;
			}
			
			int index = cmbRewindType.getSelectedIndex();
			jobFormReady = false;
			
			if(cmbJobDomain.getSelectedIndex() == 0){
				newval = (slits == 0 ? 0 : val / slits);
				SetReelType = 0;
				
				if(metric)
					cmbRewindType.setModel(new DefaultComboBoxModel(new String[] {"Length (m)", "Weight (kg)", "Diameter (mm)"}));
				else
					cmbRewindType.setModel(new DefaultComboBoxModel(new String[] {"Length (ft)", "Weight (ton)", "Diameter (in)"}));
			}
			else if(cmbJobDomain.getSelectedIndex() == 1){
				newval = val * slits;
				SetReelType = 1;
				
				if(index == 2)
					index = 0;
				if(metric)
					cmbRewindType.setModel(new DefaultComboBoxModel(new String[] {"Length (m)", "Weight (kg)"}));
				else
					cmbRewindType.setModel(new DefaultComboBoxModel(new String[] {"Length (ft)", "Weight (ton)"}));
			}
			cmbRewindType.setSelectedIndex(index);
			
			txtRewindAmount.setText(Double.toString(roundTwoDecimals(newval)));
			jobFormReady = true;
			
		}
    }
    
    //Swap two elements in the list.
    private void swap(int a, int b) {
        Object aObject = listModel.getElementAt(a);
        Object bObject = listModel.getElementAt(b);
        listModel.set(a, bObject);
        listModel.set(b, aObject);
    }
    
    private void swapJob(int a, int b) {
        Object aObject = jobModel.getElementAt(a);
        Object bObject = jobModel.getElementAt(b);
        jobModel.set(a, bObject);
        jobModel.set(b, aObject);
    }
    
    private void swapSchedule(int a, int b) {
        Object aObject = scheduleModel.getElementAt(a);
        Object bObject = scheduleModel.getElementAt(b);
        scheduleModel.set(a, bObject);
        scheduleModel.set(b, aObject);
    }
    
    class ROIListSelectionListener implements ListSelectionListener {
    	@Override
    	public void valueChanged(ListSelectionEvent e){
    		// TODO
    		int[] indices = listCompareRoi.getSelectedIndices();
    		if(indices.length > 0){
    			if(indices.length == listModel.getSize())
    				btnROIselectall.setEnabled(false);
    			else
    				btnROIselectall.setEnabled(true);
    			btnROIselectnone.setEnabled(true);
    		}else{
    			btnROIselectnone.setEnabled(false);
    			if(listModel.getSize() > 0)
    				btnROIselectall.setEnabled(true);
    		}
    	}
    }
    
    // Refresh analyses
    class MultiSelectionListener implements ListSelectionListener {
    	@Override
    	public void valueChanged(ListSelectionEvent e){
    		if(! e.getValueIsAdjusting()){
    			oldMachineIndex = 0;
    			UpdateAnalysis();
    		}
    	}
    }
    private class BtnShowTimingsActionListener implements ActionListener {
    	public void actionPerformed(ActionEvent arg0) {
    		JFrame popGraph = new JFrame();
    		
    		ChartPanel cpanel = new ChartPanel(results.getTimingGraph());
    		cpanel.setPreferredSize(new java.awt.Dimension(500, 300));
    		popGraph.setContentPane(cpanel);
    		try{
    		popGraph.setIconImage(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/logo.png")));
    		}catch(NullPointerException e11){
    			System.out.println("Image load error");
    		} catch (IOException e) {
    			e.printStackTrace();
    		}
    		popGraph.setTitle("Timing Diagram");
    		popGraph.setSize(450, 300);
    		
    		popGraph.pack();
    		popGraph.setVisible(true);
    		popGraph.setLocationRelativeTo(null);
    	}
    }
    private class RdbtnmntmPrototypeActionListener implements ActionListener {
    	public void actionPerformed(ActionEvent arg0) {
    		MODEL_VERSION = 1;
    		UpdateAnalysis();
    	}
    }
    private class RdbtnmntmStandardActionListener implements ActionListener {
    	public void actionPerformed(ActionEvent e) {
    		MODEL_VERSION = 2;
    		UpdateAnalysis();
    	}
    }
    private class FrmTitanRoiCalculatorWindowListener extends WindowAdapter {
    	@Override
    	public void windowClosing(WindowEvent arg0) {
			chart = null;
			if(environment.SaveOnClose)
				SaveSettings(environment.SaveFileName, environment);
			else
				DeleteFile(environment.SaveFileName);
    	}
    }
    private void SaveSettings(String filename, Production prod){
    	Production p = null;
		try {
			p = (Production) prod.clone();
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	if(! p.SaveSchedule)
    		p.setSchedule(null);
    	
        String extension = ".ser";
        File file;
        
        if(!filename.endsWith(extension))
          file = new File(filename + extension);
        else
        	file = new File(filename);

        try {
        	FileOutputStream fout = new FileOutputStream(file);
            ObjectOutputStream oos = new ObjectOutputStream(fout);
            oos.writeObject(p);
            oos.close();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
    }
    private void DeleteFile(String filename){
    	try{
	    	File f = new File(filename);
	
	        // Check file exists
	        if (f.exists()){
	
	        	// Check file not write protected
		        if (f.canWrite()){
		
		        	// Check not a directory
			        if (! f.isDirectory()) {
			        	
			        	// Attempt to delete it
				        f.delete();
			        }
		        }
	        }
    	}catch(Exception e){}
    }
    private class MntmSaveActionListener implements ActionListener {
    	public void actionPerformed(ActionEvent e) {
    		ResetStatusLabel();
    		
    		if(tabbedPane.getSelectedIndex() == 0){
    			// Machine save
    		
	    		if(listMachines.getSelectedIndex() == -1){
	    			ShowMessage("Please select a machine to save.");
	    		}else{
	    			
	    			Machine m = (Machine) listMachines.getSelectedValue();
	    			
	    			fc.setFileFilter(objfilter);
	    			
	    			int returnVal = fc.showSaveDialog(frmTitanRoiCalculator);
	    			if (returnVal == JFileChooser.APPROVE_OPTION) {
	    				
	    	            File file = fc.getSelectedFile();
	    	            
	    	            String path = file.getAbsolutePath();
	
	    	            String extension = ".ser";
	
	    	            if(!path.endsWith(extension))
	    	            {
	    	              file = new File(path + extension);
	    	            }
	
	    	            try {
	    	            	FileOutputStream fout = new FileOutputStream(file);
	    	                ObjectOutputStream oos = new ObjectOutputStream(fout);
	    	                oos.writeObject(m);
	    	                oos.close();
	    				} catch (IOException e1) {
	    					e1.printStackTrace();
	    				}
	    			}
	    		}
    		}
    		
    		else if(tabbedPane.getSelectedIndex() == 1){
    			// Job save
    			
    			if(listJobs.getSelectedIndex() == -1){
	    			ShowMessage("Please select a job to save.");
	    		}else{
	    			
	    			Job j = (Job) listJobs.getSelectedValue();
	    			
	    			fc.setFileFilter(objfilter);
	    			
	    			int returnVal = fc.showSaveDialog(frmTitanRoiCalculator);
	    			if (returnVal == JFileChooser.APPROVE_OPTION) {
	    				
	    	            File file = fc.getSelectedFile();
	    	            
	    	            String path = file.getAbsolutePath();
	
	    	            String extension = ".ser";
	
	    	            if(!path.endsWith(extension))
	    	            {
	    	              file = new File(path + extension);
	    	            }
	    	            
	    	            try {
	    	            	FileOutputStream fout = new FileOutputStream(file);
	    	                ObjectOutputStream oos = new ObjectOutputStream(fout);
	    	                oos.writeObject(j);
	    	                oos.close();
	    				} catch (IOException e1) {
	    					e1.printStackTrace();
	    				}
	    			}
	    		}
    		}
    		else if(tabbedPane.getSelectedIndex() == 3){
    			btnSaveToFile.doClick();
    		}
    	}
    }
    private class MntmOpenActionListener implements ActionListener {
    	public void actionPerformed(ActionEvent e) {
    		ResetStatusLabel();
    		
    		if(tabbedPane.getSelectedIndex() == 0){
    			// Machine open
    			formReady = false;
    		
	    		Machine m = null;
	    		int index = listMachines.getSelectedIndex();
				
				fc.setFileFilter(objfilter);
				
				int returnVal = fc.showOpenDialog(frmTitanRoiCalculator);
				if (returnVal == JFileChooser.APPROVE_OPTION) {
					
		            File file = fc.getSelectedFile();
		            
		            /*String path = file.getAbsolutePath();
	
		            String extension = ".ser";
	
		            if(!path.endsWith(extension))
		            {
		              file = new File(path + extension);
		            }*/
		            
		            int size = listModel.getSize();
	    
		            try {
		            	FileInputStream fin = new FileInputStream(file);
		                ObjectInputStream ois = new ObjectInputStream(fin);
		                m = (Machine) ois.readObject();
		                ois.close();
		                
		                if(size >= Consts.MACH_LIST_LIMIT){    // Max list size
		        	    	ShowMessage("Maximum number of machines allocated. Please delete before attempting to add more."); formReady = true;
		        	    	return;
		        	    }
		        	    
		        	    if(machNames.contains(m.name.toLowerCase())){
		        	    	ShowMessage("Duplicate machine names not allowed. Please choose a different name."); formReady = true;
		        	    	return;
		        	    }
		                
		                if (index == -1 || (index+1 == size)){
							listModel.addElement(m);
						}else{
							listModel.insertElementAt( m , index + 1);
						}
		                
		                listMachines.setSelectedIndex((index == -1 || (index+1 == listModel.getSize())) ? listModel.getSize()-1 : index+1);
		                
		                UpdateForm();
		            
		                machNames.add(m.name.toLowerCase());
					
		            } catch (ClassCastException e1){
		            	ShowMessage("Machine file required, job file found.");
					} catch (ClassNotFoundException e1) {
						e1.printStackTrace();
					} catch (FileNotFoundException e1){
						ShowMessage("File not found.");
					} catch (IOException e1) {
						e1.printStackTrace();
					} finally {
						if(!(listModel.getSize() == 0))
								formReady = true;
					}
		            
				}
				if(!(listModel.getSize() == 0))
					formReady = true;
				
	    	}
			
			else if(tabbedPane.getSelectedIndex() == 1){
				// Job open
				//jobFormReady = false;
	    		jobFormReady = true;
	    		
	    		Job j = null;
	    		int index = listJobs.getSelectedIndex();
				
				fc.setFileFilter(objfilter);
				
				int returnVal = fc.showOpenDialog(frmTitanRoiCalculator);
				if (returnVal == JFileChooser.APPROVE_OPTION) {
					
		            File file = fc.getSelectedFile();
		            
		            int size = jobModel.getSize();
	    
		            try {
		            	FileInputStream fin = new FileInputStream(file);
		                ObjectInputStream ois = new ObjectInputStream(fin);
		                j = (Job) ois.readObject();
		                ois.close();
		                
		                if(size >= Consts.MACH_LIST_LIMIT){    // Max list size
		        	    	ShowMessage("Maximum number of jobs allocated. Please delete before attempting to add more."); //jobFormReady = true;
		        	    	return;
		        	    }
		        	    
		        	    if(jobNames.contains(j.getName().toLowerCase())){
		        	    	ShowMessage("Duplicate job names not allowed. Please choose a different name."); //jobFormReady = true;
		        	    	return;
		        	    }
		                
		                if (index == -1 || (index+1 == size)){
							jobModel.addElement(j);
						}else{
							jobModel.insertElementAt( j , index + 1);
						}
		                
		                listJobs.setSelectedIndex((index == -1 || (index+1 == jobModel.getSize())) ? jobModel.getSize()-1 : index+1);
		                
		               // jobFormReady = true;
		                UpdateJobForm(); //jobFormReady = false;
		            
		                jobNames.add(j.getName().toLowerCase());
					
		            } catch (ClassCastException e1){
		            	ShowMessage("Job file required, machine file found.");
					} catch (ClassNotFoundException e1) {
						e1.printStackTrace();
					} catch (FileNotFoundException e1){
						ShowMessage("File not found.");
					} catch (IOException e1) {
						e1.printStackTrace();
					} finally {
						//if(!(jobModel.getSize() == 0))
							//jobFormReady = true;
					}
		            
				}
				//if(!(jobModel.getSize() == 0))
					//jobFormReady = true;
				
			}
    	}
    }

    private void ResetForm(){
    	ResetStatusLabel();
		
		chckbxAlignmentGuide.setSelected(false);
		chckbxAutoCutoff.setSelected(false);
		chckbxAutostripping.setSelected(false);
		chckbxAutoTapeCore.setSelected(false);
		chckbxAutoTapeTail.setSelected(false);
		chckbxExtraRewind.setSelected(false);
		chckbxFlag.setSelected(false);
		chckbxRollConditioning.setSelected(false);
		chckbxSpliceTable.setSelected(false);
		chckbxTurretSupport.setSelected(false);
		cmbCorepos.setSelectedIndex(0);
		cmbKnives.setSelectedIndex(0);
		//cmbRewindCore.setSelectedIndex(0);
		cmbRewindCtrl.setSelectedIndex(0);
		cmbSpeed.setSelectedIndex(0);
		cmbUnloader.setSelectedIndex(0);
		cmbUnwindDrive.setSelectedIndex(0);
		
		//txtMachName.setText("");
    }
 
    public class MachineListSelectionListener implements ListSelectionListener {
	    //Listener method for list selection changes.
	    public void valueChanged(ListSelectionEvent e) {
	    	//if(formReady){
	    	boolean resetForm = false;
	        if (e.getValueIsAdjusting() == false) {
	        	if(! formReady)
	        		resetForm = true;
	        	formReady = false;
	        	
	            if (listMachines.getSelectedIndex() == -1) {
	            //No selection: disable delete, up, and down buttons.
	            	btnMachDelete.setEnabled(false);
	                btnMachUp.setEnabled(false);
	                btnMachDown.setEnabled(false);
	                //txtMachName.setText("");
	                DisableForm();
	                machine = null;
	 
	            } else if (listMachines.getSelectedIndices().length > 1) {
	            //Multiple selection: disable up and down buttons.
	            	btnMachDelete.setEnabled(true);
	                btnMachUp.setEnabled(false);
	                btnMachDown.setEnabled(false);
	 
	            } else {
	            //Single selection: permit all operations.
	                btnMachDelete.setEnabled(true);
	                
	                if(listMachines.getSelectedIndex() == 0)
	                	btnMachUp.setEnabled(false);
	                else
	                	btnMachUp.setEnabled(true);
	                
	                if(listMachines.getSelectedIndex() == listModel.getSize()-1)
	                	btnMachDown.setEnabled(false);
	                else
	                	btnMachDown.setEnabled(true);
	                
	                machine = (Machine) listMachines.getSelectedValue();
	                
	                //txtMachName.setText(listMachines.getSelectedValue().toString());
	                txtMachName.setEnabled(true);
	                lblMachName.setEnabled(true);
	                btnMachReset.setEnabled(true);
	                rdbtnCustom.setEnabled(true);
	                rdbtnER610.setEnabled(true);
	                rdbtnSR800.setEnabled(true);
	                rdbtnSR9DS.setEnabled(true);
	                rdbtnSR9DT.setEnabled(true);
	                
	                switch(machine.model){
		                case ER610: rdbtnClick("ER610"); break;
						case SR9DS: rdbtnClick("SR9DS"); break;
						case SR9DT: rdbtnClick("SR9DT"); break;
						case SR800: rdbtnClick("SR800"); break;
						case OTHER: rdbtnClick("Custom"); break;
	                }
	            }
	            
	            UpdateForm();
	            
	            formReady = true;
	            if(resetForm)
	            	formReady = false;
	        }
	    }
	    //}
    }
    
    public class JobListSelectionListener implements ListSelectionListener {
	    //Listener method for list selection changes.
	    public void valueChanged(ListSelectionEvent e) {
	        if (e.getValueIsAdjusting() == false) {
	        	if(jobFormReady){
	        		jobFormReady = false;
	        	
	            if (listJobs.getSelectedIndex() == -1) {
	            //No selection: disable delete, up, and down buttons.
	            	btnJobDelete.setEnabled(false);
	                btnJobUp.setEnabled(false);
	                btnJobDown.setEnabled(false);
	                listJobs.clearSelection();
	                btnAddAll.setEnabled(false);
	                jobFormReady = false;
	                job = null;
	                //txtMachName.setText("");
	                ResetJobForm();
	                DisableJobForm();
	                job = null;
	                btnAddAll.setEnabled(false);
	 
	            } else if (listJobs.getSelectedIndices().length > 1) {
	            //Multiple selection: disable up and down buttons.
	            	btnJobDelete.setEnabled(true);
	            	btnJobUp.setEnabled(false);
	            	btnJobDown.setEnabled(false);
	 
	            } else {
	            //Single selection: permit all operations.
	            	btnJobDelete.setEnabled(true);
	            	
	            	btnAddAll.setEnabled(true);
	                
	                if(listJobs.getSelectedIndex() == 0)
	                	btnJobUp.setEnabled(false);
	                else
	                	btnJobUp.setEnabled(true);
	                
	                if(listJobs.getSelectedIndex() == jobModel.getSize()-1)
	                	btnJobDown.setEnabled(false);
	                else
	                	btnJobDown.setEnabled(true);
	                
	                job = (Job) listJobs.getSelectedValue();
	                
	                EnableJobForm();
	                jobFormReady = true;
	                UpdateJobForm();
	            }
	            jobIndex = listJobs.getSelectedIndex();
	            jobFormReady = true;
	        	}
	        }
	    }
    }
    
    public class JobAvailSelectionListener implements ListSelectionListener {
	    //Listener method for list selection changes.
	    public void valueChanged(ListSelectionEvent e) {
	        if (e.getValueIsAdjusting() == false) {
	        	
	            if (listJobs.getSelectedIndex() == -1) {
		            btnAddJob.setEnabled(false);
	 
	            } else if (listJobs.getSelectedIndices().length > 1) {
	          
	 
	            } else {
	            	btnAddJob.setEnabled(true);
	            }
	            
	        }
	    }
    }
    
    public class ScheduleSelectionListener implements ListSelectionListener {
	    //Listener method for list selection changes.
	    public void valueChanged(ListSelectionEvent e) {
	        if (e.getValueIsAdjusting() == false) {
	        	//formReady = false;
	        	
	            if (listSchedule.getSelectedIndex() == -1) {
	            //No selection: disable delete, up, and down buttons.
	            	btnClearSchedule.setEnabled(false);
	                btnUpSchedule.setEnabled(false);
	                btnDownSchedule.setEnabled(false);
	                btnRemoveJob.setEnabled(false);
	                btnViewSchedule.setEnabled(false);
	 
	            } else if (listSchedule.getSelectedIndices().length > 1) {
	            //Multiple selection: disable up and down buttons.
	 
	            } else {
	            	if(listSchedule.getSelectedIndex() == 0)
	            		btnUpSchedule.setEnabled(false);
	                else
	                	btnUpSchedule.setEnabled(true);
	                
	                if(listSchedule.getSelectedIndex() == scheduleModel.getSize()-1)
	                	btnDownSchedule.setEnabled(false);
	                else
	                	btnDownSchedule.setEnabled(true);
	            //Single selection: permit all operations.
	            	btnClearSchedule.setEnabled(true);
	                btnRemoveJob.setEnabled(true);
	                btnViewSchedule.setEnabled(true);
	            }
	            
	        }
	    }
    }
    
    private void DisableForm(){
    	lblMachName.setEnabled(false);
    	txtMachName.setEnabled(false);
        btnMachReset.setEnabled(false);
        rdbtnCustom.setEnabled(false);
        rdbtnER610.setEnabled(false);
        rdbtnSR800.setEnabled(false);
        rdbtnSR9DS.setEnabled(false);
        rdbtnSR9DT.setEnabled(false);
        
        chckbxAlignmentGuide.setEnabled(false);
		chckbxAutoCutoff.setEnabled(false);
		chckbxAutostripping.setEnabled(false);
		chckbxAutoTapeCore.setEnabled(false);
		chckbxAutoTapeTail.setEnabled(false);
		chckbxExtraRewind.setEnabled(false);
		chckbxFlag.setEnabled(false);
		chckbxRollConditioning.setEnabled(false);
		chckbxSpliceTable.setEnabled(false);
		chckbxTurretSupport.setEnabled(false);
		
		lblKnifeControl.setEnabled(false);
		cmbKnives.setEnabled(false);
		lblCorePositioning.setEnabled(false);
		cmbCorepos.setEnabled(false);
		lblUnloader.setEnabled(false);
		cmbUnloader.setEnabled(false);
		lblUnwindDrive.setEnabled(false);
		cmbUnwindDrive.setEnabled(false);
		lblRewindControlLoop.setEnabled(false);
		cmbRewindCtrl.setEnabled(false);
		
		lblSpeed.setEnabled(false);
		cmbSpeed.setEnabled(false);
		
		/*chckbxAlignmentGuide.setVisible(true);
		chckbxAutoCutoff.setVisible(true);
		chckbxAutostripping.setVisible(true);
		chckbxAutoTapeCore.setVisible(true);
		chckbxAutoTapeTail.setVisible(true);
		chckbxExtraRewind.setVisible(true);
		chckbxFlag.setVisible(true);
		chckbxRollConditioning.setVisible(true);
		chckbxSpliceTable.setVisible(true);
		chckbxTurretSupport.setVisible(true);*/
		
		btnCustomMachine.setVisible(false);
		
		rdbtnER610.setSelected(true);
    }
    
   /* private void EnableForm(){
    	lblMachName.setEnabled(true);
    	txtMachName.setEnabled(true);
        btnMachReset.setEnabled(true);
        rdbtnCustom.setEnabled(true);
        rdbtnER610.setEnabled(true);
        rdbtnSR800.setEnabled(true);
        rdbtnSR9DS.setEnabled(true);
        rdbtnSR9DT.setEnabled(true);
        
        chckbxAlignmentGuide.setEnabled(false);
		chckbxAutoCutoff.setEnabled(false);
		chckbxAutostripping.setEnabled(false);
		chckbxAutoTapeCore.setEnabled(false);
		chckbxAutoTapeTail.setEnabled(false);
		chckbxExtraRewind.setEnabled(false);
		chckbxFlag.setEnabled(false);
		chckbxRollConditioning.setEnabled(false);
		chckbxSpliceTable.setEnabled(false);
		chckbxTurretSupport.setEnabled(false);
		
		lblKnifeControl.setEnabled(false);
		cmbKnives.setEnabled(false);
		lblCorePositioning.setEnabled(true);
		cmbCorepos.setEnabled(true);
		lblUnloader.setEnabled(false);
		cmbUnloader.setEnabled(false);
		lblUnwindDrive.setEnabled(false);
		cmbUnwindDrive.setEnabled(false);
		lblRewindControlLoop.setEnabled(false);
		cmbRewindCtrl.setEnabled(false);
		
		lblSpeed.setEnabled(true);
		cmbSpeed.setEnabled(true);
		
		chckbxAlignmentGuide.setVisible(true);
		chckbxAutoCutoff.setVisible(true);
		chckbxAutostripping.setVisible(true);
		chckbxAutoTapeCore.setVisible(true);
		chckbxAutoTapeTail.setVisible(true);
		chckbxExtraRewind.setVisible(true);
		chckbxFlag.setVisible(true);
		chckbxRollConditioning.setVisible(true);
		chckbxSpliceTable.setVisible(true);
		chckbxTurretSupport.setVisible(true);
		
		btnCustomMachine.setVisible(false);
		
		rdbtnER610.setSelected(true);
    }*/
    
    public void UpdateAnalysis(){
    	try{
    		ResetStatusLabel();
	    	int[] indices = listCompare.getSelectedIndices();
			if(indices.length > 0){
				btnNone.setEnabled(true);
				
				if(indices.length < listModel.getSize())
					btnAll.setEnabled(true);
				else
					btnAll.setEnabled(false);
				
				Machine[] machines = new Machine[indices.length];
				for(int i=0; i<indices.length; ++i){
					machines[i] = (Machine) listModel.elementAt(indices[i]);
				}
				
				environment.update(window);
				
				if(environment.isValid()){
				
					// Get analysis
					comp = new Comparator(machines, environment, MODEL_VERSION);
					results = comp.getResults();
					// TODO: make sure machines in order on chart/results
				/*	chart = results.getTimeGraph();
					chart.removeLegend();
					chart.setTitle("");*/
					
					/*// Display results graph
					pnlPreview.remove(pnlGraph);
					pnlGraph = new ChartPanel(chart);
					pnlGraph.setBounds(2, 2, 312, 199);
					//pnlGraph.setPreferredSize(new java.awt.Dimension(243, 171));
					pnlPreview.add(pnlGraph);*/
					
					UpdateGraph();
					
					// TODO base on cmbGraphType
					
					// update form components
					EnableProdForm();
					
					// update machine selection combobox
					String[] machineNames = new String[indices.length];
					for(int i=0; i<indices.length; ++i){
						machineNames[i] = ((Machine) listModel.elementAt(indices[i])).model.toString() + ": " + ((Machine) listModel.elementAt(indices[i])).name;
					}
					DefaultComboBoxModel selectedMachines = new DefaultComboBoxModel(machineNames);
					cmbMachines.setModel(selectedMachines);
					if(oldMachineIndex < indices.length)
						cmbMachines.setSelectedIndex(oldMachineIndex); // triggers update of numerical results display
					else
						cmbMachines.setSelectedIndex(0);
					
				}else{
					ShowMessage("Job schedule not valid. Please check valid jobs have been selected.");
					DisableProdForm();
				}
			}
			else{
				ShowMessage("No machines selected.");
				DisableProdForm();
				btnNone.setEnabled(false);
			}
    	}catch(NullPointerException e){
    		// Form isn't initialized
    		// TODO: find a nicer way around this...!
    		//e.printStackTrace();
    	}
    }
    
    private void UpdateGraph(){
    	// TODO
    	
    	if(listCompare.getSelectedIndices().length > 0 && environment.isValid()){
    		
	    	if(cmbGraphType.getSelectedIndex() == 0){
	    		// Schedule time
	    		chart = results.getTimeGraph();
	    	}else if(cmbGraphType.getSelectedIndex() == 1){
	    		// Length/year
	    		chart = results.getProdGraph();
	    	}else if(cmbGraphType.getSelectedIndex() == 2){
	    		// Weight/year
	    		chart = results.getProdWGraph();
	    	}else if(cmbGraphType.getSelectedIndex() == 3){
	    		// Length/hour
	    		chart = results.getRateGraph();
	    	}else if(cmbGraphType.getSelectedIndex() == 4){
	    		// Weight/hour
	    		chart = results.getRateWGraph();
	    	}else if(cmbGraphType.getSelectedIndex() == 5){
	    		// Efficiency
	    		chart = results.getEffGraph();
	    	}
	    	
	    	JFreeChart preview = null;
			try {
				preview = (JFreeChart) chart.clone();
			} catch (CloneNotSupportedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	    	preview.removeLegend();
	    	preview.setTitle("");
			
    		// Display results graph
			try{
				pnlPreview.remove(pnlGraph);
			}catch(Exception e){
				// TODO !!
			}
			pnlGraph = new ChartPanel(preview);
			pnlGraph.setBounds(2, 2, 312, 199);
			pnlPreview.add(pnlGraph);
			
			pnlGraph.repaint();
	    	
    	}

    }
    
    private void DisableProdForm(){
	    pnlGraph.setVisible(false);
		picLabel.setVisible(true);
		btnSaveToFile.setEnabled(false);
		btnShowGraph.setEnabled(false);
		btnShowTimings.setEnabled(false);
		lblPreview.setEnabled(false);
		lblType.setEnabled(false);
		cmbGraphType.setEnabled(false);
		lblMachine.setEnabled(false);
		lblPer.setEnabled(false);
		lblOutputWeight.setEnabled(false);
		lblOutputLength.setEnabled(false);
		lblAverageMmin.setEnabled(false);
		lblEfficiency.setEnabled(false);
		cmbMachines.setEnabled(false);
		cmbTimeRef.setEnabled(false);
		lblNumericsEff.setEnabled(false);
		lblNumericsLength.setEnabled(false);
		lblNumericsWeight.setEnabled(false);
		lblNumericsRate.setEnabled(false);
		cmbMachines.setModel(new DefaultComboBoxModel());
		lblNumericsEff.setText("0.0 %");
		lblNumericsLength.setText((metric ? "0.0 m" : "0.0 ft"));
		lblNumericsWeight.setText((metric ? "0.0 kg" : "0.0 tons"));
		lblNumericsRate.setText((metric ? "0.0 m/hr" : "0.0 ft/hr"));
    }
    
    private void EnableProdForm(){
    	picLabel.setVisible(false);
		pnlGraph.setVisible(true);
		pnlGraph.repaint();
		
		btnSaveToFile.setEnabled(true);
		btnShowGraph.setEnabled(true);
		btnShowTimings.setEnabled(true);
		lblPreview.setEnabled(true);
		lblType.setEnabled(true);
		cmbGraphType.setEnabled(true);
		lblMachine.setEnabled(true);
		lblPer.setEnabled(true);
		lblOutputWeight.setEnabled(true);
		lblOutputLength.setEnabled(true);
		lblAverageMmin.setEnabled(true);
		lblEfficiency.setEnabled(true);
		cmbMachines.setEnabled(true);
		cmbTimeRef.setEnabled(true);
		lblNumericsEff.setEnabled(true);
		lblNumericsLength.setEnabled(true);
		lblNumericsWeight.setEnabled(true);
		lblNumericsRate.setEnabled(true);
    }
    
    private void UpdateNumericalAnalysis(){
    	
    	double numericsLength = 0.;
		double numericsWeight = 0.;
		double numericsRate = 0.;
		double numericsEff = 0.;
		
    	if(! cmbMachines.isEnabled()){
			lblNumericsLength.setText(Double.toString(roundTwoDecimals(numericsLength)) + (metric ? " m" : " ft"));
			lblNumericsWeight.setText(Double.toString(roundTwoDecimals(numericsWeight)) + (metric ? " kg" : " tons"));
			lblNumericsRate.setText(Double.toString(roundTwoDecimals(numericsRate)) + (metric ? " m/hr" : " ft/hr"));
			lblNumericsEff.setText(Double.toString(roundTwoDecimals(numericsEff)) + " %");
			oldMachineIndex = 0;
		}
		
    	else if((results != null) && (! results.isError)){
    		// Get machine selection
    		int machineInd = cmbMachines.getSelectedIndex();
    		oldMachineIndex = machineInd;
    		
    		// Get results for that selection
    		// TODO: check result do come in order!!
    		Result res = results.get(machineInd);
    		
    		// Switch over the selected time domain to update labels
    		switch(cmbTimeRef.getSelectedIndex()){
	    		case 0: // per schedule
	    			numericsLength = res.getResult(ResultType.LENGTH, ResultTime.SCHEDULE);
    				numericsWeight = res.getResult(ResultType.WEIGHT, ResultTime.SCHEDULE);
    				numericsRate = res.getResult(ResultType.RATE, ResultTime.SCHEDULE);
    				numericsEff = res.getResult(ResultType.EFF, ResultTime.SCHEDULE);
    				break;
	    		case 1: // per year
	    			numericsLength = res.getResult(ResultType.LENGTH, ResultTime.YEAR);
    				numericsWeight = res.getResult(ResultType.WEIGHT, ResultTime.YEAR);
    				numericsRate = res.getResult(ResultType.RATE, ResultTime.YEAR);
    				numericsEff = res.getResult(ResultType.EFF, ResultTime.YEAR);
    				break;
	    		case 2: // per hour
	    			numericsLength = res.getResult(ResultType.LENGTH, ResultTime.HOUR);
    				numericsWeight = res.getResult(ResultType.WEIGHT, ResultTime.HOUR);
    				numericsRate = res.getResult(ResultType.RATE, ResultTime.HOUR);
    				numericsEff = res.getResult(ResultType.EFF, ResultTime.HOUR);
    				break;
	    		case 3: // per shift
	    			numericsLength = res.getResult(ResultType.LENGTH, ResultTime.SHIFT);
    				numericsWeight = res.getResult(ResultType.WEIGHT, ResultTime.SHIFT);
    				numericsRate = res.getResult(ResultType.RATE, ResultTime.SHIFT);
    				numericsEff = res.getResult(ResultType.EFF, ResultTime.SHIFT);
    				break;
	    		case 4: // per day
	    			numericsLength = res.getResult(ResultType.LENGTH, ResultTime.DAY);
    				numericsWeight = res.getResult(ResultType.WEIGHT, ResultTime.DAY);
    				numericsRate = res.getResult(ResultType.RATE, ResultTime.DAY);
    				numericsEff = res.getResult(ResultType.EFF, ResultTime.DAY);
    				break;
	    		case 5: // per week
	    			numericsLength = res.getResult(ResultType.LENGTH, ResultTime.WEEK);
    				numericsWeight = res.getResult(ResultType.WEIGHT, ResultTime.WEEK);
    				numericsRate = res.getResult(ResultType.RATE, ResultTime.WEEK);
    				numericsEff = res.getResult(ResultType.EFF, ResultTime.WEEK);
    				break;
	    		default: // otherwise
	    			numericsLength = 0;
    				numericsWeight = 0;
    				numericsRate = 0;
    				numericsEff = 0;
    				break;
    		}
    		
    		if(!metric){
    			numericsLength = Core.MToFt(numericsLength);
    			numericsWeight = Core.KgToTon(numericsWeight);
    			numericsRate = Core.MToFt(numericsRate);
    		}
    		
    		lblNumericsLength.setText(Double.toString(roundTwoDecimals( (numericsLength >= 10000 ? numericsLength/(metric ? 1000 : 5280) : numericsLength ))) + (numericsLength >= 10000 ? (metric ? " km" : " mi") : (metric ? " m" : " ft")));
			lblNumericsWeight.setText(Double.toString(roundTwoDecimals( (numericsWeight >= 10000 ? numericsWeight/(metric ? 1000 : 1) : numericsWeight ))) + (numericsWeight >= 10000 ? (metric ? " tonnes" : " tons") : (metric ? " kg" : " tons")));
			lblNumericsRate.setText(Double.toString(roundTwoDecimals(numericsRate)) + (metric ? " m/hr" : " ft/hr"));
			lblNumericsEff.setText(Double.toString(roundTwoDecimals(numericsEff)) + " %");
			
		}
    }
 
    	
    	private void rdbtnClick(String name){
    		
    		if(name.equals("ER610") /*&& (listModel.getSize()==1 || !(model == Machine.Model.ER610))*/){
				ResetStatusLabel();
				
				chckbxAlignmentGuide.setEnabled(Consts.ER_ALIGN_OPTION);
				chckbxAutoCutoff.setEnabled(Consts.ER_CUTOFF_OPTION);
				chckbxAutostripping.setEnabled(Consts.ER_AUTOSTRIP_OPTION);
				chckbxAutoTapeCore.setEnabled(Consts.ER_TAPECORE_OPTION);
				chckbxAutoTapeTail.setEnabled(Consts.ER_TAPETAIL_OPTION);
				chckbxExtraRewind.setEnabled(Consts.ER_850MM_OPTION);
				chckbxFlag.setEnabled(Consts.ER_FLAG_OPTION);
				chckbxRollConditioning.setEnabled(Consts.ER_ROLL_OPTION);
				chckbxSpliceTable.setEnabled(Consts.ER_SPLICE_OPTION);
				chckbxTurretSupport.setEnabled(Consts.ER_TURRET_OPTION);
				
				lblKnifeControl.setEnabled(false);
				cmbKnives.setEnabled(false);
				//lblCorePositioning.setEnabled(false);
				//cmbCorepos.setEnabled(false);
				lblUnloader.setEnabled(false);
				cmbUnloader.setEnabled(false);
				lblUnwindDrive.setEnabled(false);
				cmbUnwindDrive.setEnabled(false);
				lblRewindControlLoop.setEnabled(false);
				cmbRewindCtrl.setEnabled(false);
				
				lblCorePositioning.setEnabled(true);
				cmbCorepos.setEnabled(true);
				lblSpeed.setEnabled(true);
				cmbSpeed.setEnabled(true);
				
				/*chckbxAlignmentGuide.setVisible(true);
				chckbxAutoCutoff.setVisible(true);
				chckbxAutostripping.setVisible(true);
				chckbxAutoTapeCore.setVisible(true);
				chckbxAutoTapeTail.setVisible(true);
				chckbxExtraRewind.setVisible(true);
				chckbxFlag.setVisible(true);
				chckbxRollConditioning.setVisible(true);
				chckbxSpliceTable.setVisible(true);
				chckbxTurretSupport.setVisible(true);*/
				
				//cmbCorepos.setModel(new DefaultComboBoxModel(FrmMain.CoreposER.values()));
				cmbCorepos.setModel(new DefaultComboBoxModel(new String[] {"Manual", "Laser"}));
				cmbSpeed.setModel(new DefaultComboBoxModel(new String[] {"450", "550"}));
				
				btnCustomMachine.setVisible(false);
				
				model = Machine.Model.ER610;
				
				rdbtnER610.setSelected(true);
			}
    		
    		if(name.equals("SR9DS") /*&& !(model == Machine.Model.SR9DS)*/){
				ResetStatusLabel();
				
				chckbxAlignmentGuide.setEnabled(Consts.SRDS_ALIGN_OPTION);
				chckbxAutoCutoff.setEnabled(Consts.SRDS_CUTOFF_OPTION);
				chckbxAutostripping.setEnabled(Consts.SRDS_AUTOSTRIP_OPTION);
				chckbxAutoTapeCore.setEnabled(Consts.SRDS_TAPECORE_OPTION);
				chckbxAutoTapeTail.setEnabled(Consts.SRDS_TAPETAIL_OPTION);
				chckbxExtraRewind.setEnabled(Consts.SRDS_850MM_OPTION);
				chckbxFlag.setEnabled(Consts.SRDS_FLAG_OPTION);
				chckbxRollConditioning.setEnabled(Consts.SRDS_ROLL_OPTION);
				chckbxSpliceTable.setEnabled(Consts.SRDS_SPLICE_OPTION);
				chckbxTurretSupport.setEnabled(Consts.SRDS_TURRET_OPTION);
				
				lblKnifeControl.setEnabled(true);
				cmbKnives.setEnabled(true);
				lblCorePositioning.setEnabled(true);
				cmbCorepos.setEnabled(true);
				lblUnloader.setEnabled(true);
				cmbUnloader.setEnabled(true);
				lblUnwindDrive.setEnabled(true);
				cmbUnwindDrive.setEnabled(true);
				lblRewindControlLoop.setEnabled(true);
				cmbRewindCtrl.setEnabled(true);
				
				/*chckbxAlignmentGuide.setVisible(true);
				chckbxAutoCutoff.setVisible(true);
				chckbxAutostripping.setVisible(true);
				chckbxAutoTapeCore.setVisible(true);
				chckbxAutoTapeTail.setVisible(true);
				chckbxExtraRewind.setVisible(true);
				chckbxFlag.setVisible(true);
				chckbxRollConditioning.setVisible(true);
				chckbxSpliceTable.setVisible(true);
				chckbxTurretSupport.setVisible(true);*/
				
				lblCorePositioning.setEnabled(true);
				cmbCorepos.setEnabled(true);
				lblSpeed.setEnabled(true);
				cmbSpeed.setEnabled(true);
				
				//cmbCorepos.setModel(new DefaultComboBoxModel(FrmMain.CoreposSR.values()));
				cmbCorepos.setModel(new DefaultComboBoxModel(new String[] {"Manual", "Laser", "Servo"}));
				cmbSpeed.setModel(new DefaultComboBoxModel(new String[] {"1000"}));
				
				btnCustomMachine.setVisible(false);
				
				model = Machine.Model.SR9DS;
				
				rdbtnSR9DS.setSelected(true);
			}
    		
    		if(name.equals("SR9DT")/* && !(model == Machine.Model.SR9DT)*/){
				ResetStatusLabel();
				
				chckbxAlignmentGuide.setEnabled(Consts.SRDT_ALIGN_OPTION);
				chckbxAutoCutoff.setEnabled(Consts.SRDT_CUTOFF_OPTION);
				chckbxAutostripping.setEnabled(Consts.SRDT_AUTOSTRIP_OPTION);
				chckbxAutoTapeCore.setEnabled(Consts.SRDT_TAPECORE_OPTION);
				chckbxAutoTapeTail.setEnabled(Consts.SRDT_TAPETAIL_OPTION);
				chckbxExtraRewind.setEnabled(Consts.SRDT_850MM_OPTION);
				chckbxFlag.setEnabled(Consts.SRDT_FLAG_OPTION);
				chckbxRollConditioning.setEnabled(Consts.SRDT_ROLL_OPTION);
				chckbxSpliceTable.setEnabled(Consts.SRDT_SPLICE_OPTION);
				chckbxTurretSupport.setEnabled(Consts.SRDT_TURRET_OPTION);
				
				lblKnifeControl.setEnabled(true);
				cmbKnives.setEnabled(true);
				lblCorePositioning.setEnabled(true);
				cmbCorepos.setEnabled(true);
				lblUnloader.setEnabled(true);
				cmbUnloader.setEnabled(true);
				lblUnwindDrive.setEnabled(true);
				cmbUnwindDrive.setEnabled(true);
				lblRewindControlLoop.setEnabled(true);
				cmbRewindCtrl.setEnabled(true);
				
				lblCorePositioning.setEnabled(true);
				cmbCorepos.setEnabled(true);
				lblSpeed.setEnabled(true);
				cmbSpeed.setEnabled(true);
				
				
				/*chckbxAlignmentGuide.setVisible(true);
				chckbxAutoCutoff.setVisible(true);
				chckbxAutostripping.setVisible(true);
				chckbxAutoTapeCore.setVisible(true);
				chckbxAutoTapeTail.setVisible(true);
				chckbxExtraRewind.setVisible(true);
				chckbxFlag.setVisible(true);
				chckbxRollConditioning.setVisible(true);
				chckbxSpliceTable.setVisible(true);
				chckbxTurretSupport.setVisible(true);*/
				
				//cmbCorepos.setModel(new DefaultComboBoxModel(FrmMain.CoreposSR.values()));
				cmbCorepos.setModel(new DefaultComboBoxModel(new String[] {"Manual", "Laser", "Servo"}));
				cmbSpeed.setModel(new DefaultComboBoxModel(new String[] {"1000"}));
				
				btnCustomMachine.setVisible(false);
			
				model = Machine.Model.SR9DT;
				
				rdbtnSR9DT.setSelected(true);
			}
    		
    		if(name.equals("SR800")/* && !(model == Machine.Model.SR800)*/){
				ResetStatusLabel();
				
				chckbxAlignmentGuide.setEnabled(false);
				chckbxAutoCutoff.setEnabled(false);
				chckbxAutostripping.setEnabled(false);
				chckbxAutoTapeCore.setEnabled(false);
				chckbxAutoTapeTail.setEnabled(false);
				chckbxExtraRewind.setEnabled(false);
				chckbxFlag.setEnabled(false);
				chckbxRollConditioning.setEnabled(false);
				chckbxSpliceTable.setEnabled(false);
				chckbxTurretSupport.setEnabled(false);
				
				lblSpeed.setEnabled(false);
				cmbSpeed.setEnabled(false);
				lblKnifeControl.setEnabled(false);
				cmbKnives.setEnabled(false);
				lblCorePositioning.setEnabled(false);
				cmbCorepos.setEnabled(false);
				lblUnloader.setEnabled(false);
				cmbUnloader.setEnabled(false);
				lblUnwindDrive.setEnabled(false);
				cmbUnwindDrive.setEnabled(false);
				lblRewindControlLoop.setEnabled(false);
				cmbRewindCtrl.setEnabled(false);
				
				btnCustomMachine.setVisible(false);
			
				model = Machine.Model.SR800;
				
				rdbtnSR800.setSelected(true);
			}
    		
    		if(name.equals("Custom") /*&& !(model == Machine.Model.OTHER)*/){
				
    			chckbxAlignmentGuide.setEnabled(false);
				chckbxAutoCutoff.setEnabled(false);
				chckbxAutostripping.setEnabled(false);
				chckbxAutoTapeCore.setEnabled(false);
				chckbxAutoTapeTail.setEnabled(false);
				chckbxExtraRewind.setEnabled(false);
				chckbxFlag.setEnabled(false);
				chckbxRollConditioning.setEnabled(false);
				chckbxSpliceTable.setEnabled(false);
				chckbxTurretSupport.setEnabled(false);
				
				lblKnifeControl.setEnabled(false);
				cmbKnives.setEnabled(false);
				//lblCorePositioning.setEnabled(false);
				//cmbCorepos.setEnabled(false);
				lblUnloader.setEnabled(false);
				cmbUnloader.setEnabled(false);
				lblUnwindDrive.setEnabled(false);
				cmbUnwindDrive.setEnabled(false);
				lblRewindControlLoop.setEnabled(false);
				cmbRewindCtrl.setEnabled(false);
				lblCorePositioning.setEnabled(false);
				cmbCorepos.setEnabled(false);
				lblSpeed.setEnabled(false);
				cmbSpeed.setEnabled(false);
				
				//cmbCorepos.setModel(new DefaultComboBoxModel(FrmMain.CoreposER.values()));
				//cmbCorepos.setModel(new DefaultComboBoxModel(new String[] {"Manual", "Laser"}));
				//cmbSpeed.setModel(new DefaultComboBoxModel(new String[] {"450", "550"}));
				
				/*MachineBuilder newmach = new MachineBuilder(window listMachines, lblStatus, machNames);
				newmach.setVisible(true);*/
				btnCustomMachine.setVisible(true);
				
				model = Machine.Model.OTHER;
				
				rdbtnCustom.setSelected(true);
			}
    		if(name.equals("Custom")){
    			machine.setCustom(true);
    			if(machine.getCustomMachine() == null)
    				machine.setCustomMachine(machine.new CustomMachine());
    		}else
    			machine.setCustom(false);
    		
    }
    
    ActionListener SaveActionListener = new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			// TODO base on cmbGraphType selection, or not needed with 'chart'?
			fc.setFileFilter(new PNGfilter());
			
			int returnVal = fc.showSaveDialog(pnlCompare);
			if (returnVal == JFileChooser.APPROVE_OPTION) {
				
	            File file = fc.getSelectedFile();
	            
	            String path = file.getAbsolutePath();

	            String extension = ".png";

	            if(!path.endsWith(extension))
	            {
	              file = new File(path + extension);
	            }

	            
	            try {
	            	JFreeChart chartSave = (JFreeChart) chart.clone();
	            	//chartSave.setTitle("Productivity Comparison");
	            	chartSave.removeLegend();
					ChartUtilities.saveChartAsPNG(file, chartSave, 800, 600);
				} catch (IOException e1) {
					e1.printStackTrace();
				} catch (CloneNotSupportedException e1) {
					e1.printStackTrace();
				}
			}
		}
	};
	
	public File addExt(File f, String ext){
		String path = f.getAbsolutePath();
	
	    if(!path.endsWith(ext))
	    {
	      f = new File(path + ext);
	    }
	    
	    return f;
	}
    
	class PNGfilter extends FileFilter {
		@Override
		public String getDescription(){
			return "PNG images";
		}
		
		@Override
		public boolean accept(File f) {
			if (f.isDirectory()) {
		        return true;
		    }

		    String extension = getExtension(f);
		    if (extension != null) {
		        if (extension.equals("png")) {
		                return true;
		        } else {
		            return false;
		        }
		    }

		    return false;
		}

	}
	
	class OBJfilter extends FileFilter {
		@Override
		public String getDescription(){
			return "Machine setting files";//"Java serialized object files";
		}
		
		@Override
		public boolean accept(File f) {
			if (f.isDirectory()) {
		        return true;
		    }

		    String extension = getExtension(f);
		    if (extension != null) {
		        if (extension.equals("ser")) {
		                return true;
		        } else {
		            return false;
		        }
		    }

		    return false;
		}

	}
	
	/*
     * Get the extension of a file.
     */  
    public static String getExtension(File f) {
        String ext = null;
        String s = f.getName();
        int i = s.lastIndexOf('.');

        if (i > 0 &&  i < s.length() - 1) {
            ext = s.substring(i+1).toLowerCase();
        }
        return ext;
    }

    ChangeListener TabChangeListener = new ChangeListener() {
    	@Override
		public void stateChanged(ChangeEvent arg0) {
    		try{
    			ResetStatusLabel();
    		}catch(NullPointerException e){
    			// Form is still initialising
    		}
    		if(tabbedPane.getSelectedIndex() == 0){
    			mntmOpen.setEnabled(true);
				mntmSave.setEnabled(true);
    		}
    		else if(tabbedPane.getSelectedIndex() == 1){
    			mntmOpen.setEnabled(true);
				mntmSave.setEnabled(true);
    		}
    		else if(tabbedPane.getSelectedIndex() == 2){
    			mntmOpen.setEnabled(false);
				mntmSave.setEnabled(false);
    		}
    		else if(tabbedPane.getSelectedIndex() == 3){
				if(listModel.getSize() > 0){
					lblSelect.setEnabled(true);
	    			btnAll.setEnabled(true);
				}else{
	    			lblSelect.setEnabled(false);
	    			btnAll.setEnabled(false);
	    			btnNone.setEnabled(false);
				}
				
				mntmOpen.setEnabled(false);
				mntmSave.setEnabled(true);
    			
				// refresh analyses
				UpdateAnalysis();
			}
    		else if(tabbedPane.getSelectedIndex() == 4){
    			if(listModel.getSize() > 0){
					lblROIselect.setEnabled(true);
					if(listCompareRoi.getSelectedIndices().length != listModel.getSize())
						btnROIselectall.setEnabled(true);
					else
						btnROIselectall.setEnabled(false);
				}else{
					lblROIselect.setEnabled(false);
					btnROIselectall.setEnabled(false);
					btnROIselectnone.setEnabled(false);
				}
    			
    			mntmOpen.setEnabled(false);
				mntmSave.setEnabled(false);
    		}
    		else{
    			mntmOpen.setEnabled(false);
				mntmSave.setEnabled(false);
    		}
		}
	};
	
	public void ShowMessage(String msg){
		lblStatus.setText(" " + msg);
    	lblStatus.setFont(new Font("Tahoma", Font.BOLD, 13));
    	lblStatus.setForeground(Color.RED);
	}
	
	public class JobInputChangeListener implements DocumentListener {
		@Override
		public void changedUpdate(DocumentEvent arg0) {
		}
		@Override
		public void insertUpdate(DocumentEvent arg0) {
			UpdateJob();
		}
		@Override
		public void removeUpdate(DocumentEvent arg0) {
			UpdateJob();
		}
	}
	
	private void ResetJobForm(){
		try{
			ResetStatusLabel();
			
			int selected=0;
			int size=0;
			try{
				selected = listJobs.getSelectedIndex();
				size = jobModel.getSize();
			}catch (NullPointerException e)
			{ jobFormReady = false;
			}
			if((selected < 0) || (size == 0))
				jobFormReady = false;
			
			//txtJobName.setText("");
			//try{
			if(metric){
				cmbRewindCore.setModel(new DefaultComboBoxModel(Consts.REWIND_CORE_MM));
				cmbUnwindCore.setModel(new DefaultComboBoxModel(Consts.UNWIND_CORE_MM));
				
				cmbUnwindType.setModel(new DefaultComboBoxModel(new String[] {"Length (m)", "Weight (kg)", "Diameter (mm)"}));
				cmbRewindType.setModel(new DefaultComboBoxModel(new String[] {"Length (m)", "Weight (kg)", "Diameter (mm)"}));
				cmbTargetTotal.setModel(new DefaultComboBoxModel(new String[] {"Length (m)", "Weight (kg)", "Weight (tonnes)"}));
			}else{
				cmbRewindCore.setModel(new DefaultComboBoxModel(Consts.REWIND_CORE_IN));
				cmbUnwindCore.setModel(new DefaultComboBoxModel(Consts.UNWIND_CORE_IN));
				
				cmbUnwindType.setModel(new DefaultComboBoxModel(new String[] {"Length (ft)", "Weight (ton)", "Diameter (in)"}));
				cmbRewindType.setModel(new DefaultComboBoxModel(new String[] {"Length (ft)", "Weight (ton)", "Diameter (in)"}));
				cmbTargetTotal.setModel(new DefaultComboBoxModel(new String[] {"Length (ft)", "Weight (ton)"}));
			}
			//}catch(IllegalStateException e){
				
			//}
			
			oldUnwindIndex = 0;
			oldRewindIndex = 0;
			oldTotalsIndex = 0;
			SetReelType = 0;
			
			cmbMaterials.setSelectedIndex(0);
			cmbUnwindCore.setSelectedIndex(0);
			cmbRewindCore.setSelectedIndex(1);
			cmbJobDomain.setSelectedIndex(0);
			cmbUnwindType.setSelectedIndex(0);
			cmbRewindType.setSelectedIndex(0);
			cmbTargetTotal.setSelectedIndex(0);
			txtThickness.setText("20");
			txtDensity.setText("0.92");
			chckbxLimitRunSpeed.setSelected(false);
			txtUnwindAmount.setText("10000");
			txtRewindAmount.setText("1000");
			lblTrim.setText("0 mm");
			txtLimitRunSpeed.setText("800");
			txtSlits.setText("1");
			txtSlitWidth.setText("1350");
			txtTargetTotal.setText("10000");
			txtWebWidth.setText("1350");
			txtFlagCount.setText("1");
			txtLimitRunSpeed.setEnabled(false);
			
			if(!metric){
				txtThickness.setText("0.79");
				txtUnwindAmount.setText("32810");
				txtRewindAmount.setText("3281.0");
				txtLimitRunSpeed.setText("2624.8");
				txtTargetTotal.setText("32810");
				txtWebWidth.setText("53.15");
				txtSlitWidth.setText("53.15");
				lblTrim.setText("0 in");
			}
		}
			catch(IllegalStateException e1){
				e1.printStackTrace();
		}
			catch(NullPointerException e){
		}
	}
	
	private void EnableJobForm(){
		ResetStatusLabel();
		
		txtJobName.setEnabled(true);
		txtWebWidth.setEnabled(true);
		cmbMaterials.setEnabled(true);
		cmbUnwindCore.setEnabled(true);
		cmbRewindCore.setEnabled(true);
		cmbJobDomain.setEnabled(true);
		cmbUnwindType.setEnabled(true);
		cmbRewindType.setEnabled(true);
		txtThickness.setEnabled(true);
		txtDensity.setEnabled(true);
		chckbxLimitRunSpeed.setEnabled(true);
		txtUnwindAmount.setEnabled(true);
		txtRewindAmount.setEnabled(true);
		lblTrim.setEnabled(true);
		if(chckbxLimitRunSpeed.isSelected())
			txtLimitRunSpeed.setEnabled(true);

		txtSlits.setEnabled(true);
		txtSlitWidth.setEnabled(true);
		
		btnResetJobs.setEnabled(true);
		//btnJobDelete.setEnabled(true);
		//btnJobUp.setEnabled(true);
		//btnJobDown.setEnabled(true);
		
		lblDensity_1.setEnabled(true);
		lblThickness_1.setEnabled(true);
		lblmicro0.setEnabled(true);
		lblLimitRunSpeed.setEnabled(true);
		lblPer.setEnabled(true);
		lblRewindCoremm.setEnabled(true);
		lblUnwindCoremm.setEnabled(true);
		lblWebWidthmm.setEnabled(true);
		lblTrimtotal.setEnabled(true);
		lblSlitCount.setEnabled(true);
		lblmm0.setEnabled(true);
		lblmm1.setEnabled(true);
		lblmm2.setEnabled(true);
		lblmm3.setEnabled(true);
		lblmmin.setEnabled(true);
		lblPresets.setEnabled(true);
		lblJobName.setEnabled(true);
		lblgm3.setEnabled(true);
		lblTargetRewindLength.setEnabled(true);
		lblUnwindLength.setEnabled(true);
		lblSlitWidth.setEnabled(true);
		lblPer_1.setEnabled(true);
		label_3.setEnabled(true);
		lblTargetOutputFor.setEnabled(true);
		txtTargetTotal.setEnabled(true);
		cmbTargetTotal.setEnabled(true);
		lblPerRoll.setEnabled(true);
		lblAverageFlags.setEnabled(true);
		txtFlagCount.setEnabled(true);
	}
	private void DisableJobForm(){
		ResetStatusLabel();
		txtJobName.setEnabled(false);
		txtWebWidth.setEnabled(false);
		cmbMaterials.setEnabled(false);
		cmbUnwindCore.setEnabled(false);
		cmbRewindCore.setEnabled(false);
		cmbJobDomain.setEnabled(false);
		cmbUnwindType.setEnabled(false);
		cmbRewindType.setEnabled(false);
		txtThickness.setEnabled(false);
		txtDensity.setEnabled(false);
		chckbxLimitRunSpeed.setEnabled(false);
		txtUnwindAmount.setEnabled(false);
		txtRewindAmount.setEnabled(false);
		lblTrim.setEnabled(false);
		txtLimitRunSpeed.setEnabled(false);
		txtSlits.setEnabled(false);
		txtSlitWidth.setEnabled(false);
		
		btnResetJobs.setEnabled(false);
		btnJobDelete.setEnabled(false);
		btnJobUp.setEnabled(false);
		btnJobDown.setEnabled(false);
		
		lblDensity_1.setEnabled(false);
		lblThickness_1.setEnabled(false);
		lblmicro0.setEnabled(false);
		lblLimitRunSpeed.setEnabled(false);
		lblPer.setEnabled(false);
		lblRewindCoremm.setEnabled(false);
		lblUnwindCoremm.setEnabled(false);
		lblWebWidthmm.setEnabled(false);
		lblTrimtotal.setEnabled(false);
		lblSlitCount.setEnabled(false);
		lblmm0.setEnabled(false);
		lblmm1.setEnabled(false);
		lblmm2.setEnabled(false);
		lblmm3.setEnabled(false);
		lblmmin.setEnabled(false);
		lblPresets.setEnabled(false);
		lblJobName.setEnabled(false);
		lblgm3.setEnabled(false);
		lblTargetRewindLength.setEnabled(false);
		lblUnwindLength.setEnabled(false);
		lblSlitWidth.setEnabled(false);
		lblPer_1.setEnabled(false);
		label_3.setEnabled(false);
		lblTargetOutputFor.setEnabled(false);
		txtTargetTotal.setEnabled(false);
		cmbTargetTotal.setEnabled(false);
		lblPerRoll.setEnabled(false);
		lblAverageFlags.setEnabled(false);
		txtFlagCount.setEnabled(false);
	}
	
	private void UpdateJobForm(){
		
		
    	if ((listJobs.getSelectedIndex() < 0) || (!jobFormReady)) {
    		
    		
    	}else{
    	
    		jobFormReady = false;
    	
	    	ResetJobForm();
			
			int selected = -1;
			int size = 0;
			try{
				selected = listJobs.getSelectedIndex();
				size = jobModel.getSize();
			}catch (NullPointerException e)
			{ jobFormReady = true;
				return; 
			}
			if((selected < 0) || (size == 0)){
				jobFormReady = true;ResetJobForm();
				return;
			}
			
			Job j = (Job) listJobs.getSelectedValue();
			
			txtJobName.setText(j.getName());
			cmbMaterials.setSelectedItem(j.getMaterial());
			txtThickness.setText(Double.toString(roundTwoDecimals((metric ? j.getMaterial().thickness : Core.MicroToMil(j.getMaterial().thickness)))));
			txtDensity.setText(Double.toString(roundTwoDecimals(j.getMaterial().density)));
			cmbUnwindType.setSelectedIndex(j.getUnwindType());
			cmbRewindType.setSelectedIndex(j.getRewindType());
			cmbTargetTotal.setSelectedIndex( ((!metric && j.getTotalType()==2) ? 1 : j.getTotalType()));
			oldRewindIndex = cmbRewindType.getSelectedIndex();
			oldUnwindIndex = cmbUnwindType.getSelectedIndex();
			oldTotalsIndex = cmbTargetTotal.getSelectedIndex();
			
			if(j.getUnwindType() == 0)
				txtUnwindAmount.setText(Double.toString(roundTwoDecimals((metric ? j.getUnwindLength() : Core.MToFt(j.getUnwindLength())))));
			else if(j.getUnwindType() == 1)
				txtUnwindAmount.setText(Double.toString(roundTwoDecimals((metric ? j.getUnwindWeight() : Core.KgToTon(j.getUnwindWeight())))));
			else if(j.getUnwindType() == 2)
				txtUnwindAmount.setText(Double.toString(roundTwoDecimals((metric ? j.getUnwindDiam() : Core.MMToIn(j.getUnwindDiam())))));
			
			if(j.getRewindType() == 0)
				txtRewindAmount.setText(Double.toString(roundTwoDecimals((metric ? j.getRewindLength() : Core.MToFt(j.getRewindLength())))));
			else if(j.getRewindType() == 1)
				txtRewindAmount.setText(Double.toString(roundTwoDecimals((metric ? j.getRewindWeight() : Core.KgToTon(j.getRewindWeight())))));
			else if(j.getRewindType() == 2)
				txtRewindAmount.setText(Double.toString(roundTwoDecimals((metric ? j.getRewindDiam() : Core.MMToIn(j.getRewindDiam())))));
			
			if(j.getTotalType() == 0)
				txtTargetTotal.setText(Double.toString(roundTwoDecimals((metric ? j.getTotLength() : Core.MToFt(j.getTotLength())))));
			else if(j.getTotalType() == 1)
				txtTargetTotal.setText(Double.toString(roundTwoDecimals((metric ? j.getTotWeight() : Core.KgToTon(j.getTotWeight())))));
			else if(j.getTotalType() == 2)
				txtTargetTotal.setText(Double.toString(roundTwoDecimals((metric ? Core.KgToTonne(j.getTotWeight()) : Core.KgToTon(j.getTotWeight())))));
			
			txtFlagCount.setText(Double.toString(roundTwoDecimals(j.getFlagRate())));
			
			txtSlits.setText(Integer.toString(j.getSlits()));
			txtSlitWidth.setText(Double.toString(roundTwoDecimals((metric ? j.getSlitWidth() : Core.MMToIn(j.getSlitWidth())))));
			txtWebWidth.setText(Double.toString(roundTwoDecimals((metric ? j.getWebWidth() : Core.MMToIn(j.getWebWidth())))));
			
			chckbxLimitRunSpeed.setSelected(j.isSpeedLimited());
			txtLimitRunSpeed.setText(Double.toString(roundTwoDecimals((metric ? j.getSpeedLimit() : Core.MToFt(j.getSpeedLimit())))));
			if(j.isSpeedLimited()){
				txtLimitRunSpeed.setEnabled(true);
			}else{
				txtLimitRunSpeed.setEnabled(false);
			}
			
			cmbRewindCore.setSelectedItem(Double.toString(roundTwoDecimals((metric ? j.getRewindCore() : Core.MMToIn(j.getRewindCore())))));
			cmbUnwindCore.setSelectedItem(Double.toString(roundTwoDecimals((metric ? j.getUnwindCore() : Core.MMToIn(j.getUnwindCore())))));
			
			UpdateTrim();
			
			jobFormReady = true;
		
		}
		
	}
	
	private void UpdateJobName(){
		if(jobFormReady){
			jobFormReady = false;
		
			ResetStatusLabel();
			int selected = -1;
			int size = 0;
			try{
				selected = listJobs.getSelectedIndex();
				size = jobModel.getSize();
			}catch (NullPointerException e)
			{ jobFormReady = true;
				return; 
			}
			if((selected < 0) || (size == 0)){
				jobFormReady = true;ResetJobForm();
				return;
			}
			
			String input = txtJobName.getText();
	    	ResetStatusLabel();
			if(input.equals("")){
				ShowMessage("Please enter a job name.");
				jobFormReady = true;
		    	return;
			}
			
			if(jobNames.contains(input.toLowerCase()) && (!(((Job)listJobs.getSelectedValue()).getName().equals(input)))){
		    	ShowMessage("Duplicate job names not allowed. Please choose a different name.");
		    	jobFormReady = true;
		    	return;
		    }
			jobNames.remove(((Job)listJobs.getSelectedValue()).getName().toLowerCase());
			jobNames.add(input.toLowerCase());
		    
			((Job)listJobs.getSelectedValue()).setName(input);
			listJobs.repaint();
			jobFormReady = true;
		}
	}
	
	private void UpdateJob(){
		
		if(jobFormReady){

			jobFormReady = false;
			
			int selected = -1;
			int size = 0;
			try{
				selected = listJobs.getSelectedIndex();
				size = jobModel.getSize();
			}catch (NullPointerException e)
			{ jobFormReady = true;
				return; 
			}
			if((selected < 0) || (size == 0)){
				jobFormReady = false;
				ResetJobForm();
				return;
			}
			
			Double WebWidth;
			Double UnwindCore;
			Double UnwindAmount;
			Double FlagRate;
			Double TotalAmount;
			Double RewindCore;
			Double RewindAmount;
			Double SlitWidth;
			Double speed_limit;
			int Slits;
			
			// Get selected
			Job j = (Job) listJobs.getSelectedValue();
			//Job j = (Job) jobModel.getElementAt(job_index);
			
			// Update name
			UpdateJobName();
			
			// Update material
			Material material = new Material((Material) cmbMaterials.getSelectedItem());
			try{
				material.density = Double.parseDouble(txtDensity.getText());
				material.thickness = (metric ? Double.parseDouble(txtThickness.getText()) : Core.MilToMicro(Double.parseDouble(txtThickness.getText())));
			}catch (NumberFormatException e){
				material.density = 0;
				material.thickness = 0;
			}
			
			// Update unwind
			try{
				WebWidth = (metric ? Double.parseDouble(txtWebWidth.getText()) : Core.InToMM(Double.parseDouble(txtWebWidth.getText())));
				UnwindCore = (metric ? Double.parseDouble((((JTextField) cmbUnwindCore.getEditor().getEditorComponent()).getText())) : Core.InToMM(Double.parseDouble((((JTextField) cmbUnwindCore.getEditor().getEditorComponent()).getText()))));
				//WebWidth = Double.parseDouble(cmbWebWidth.getSelectedItem().toString());
				//UnwindCore = Double.parseDouble(cmbUnwindCore.getSelectedItem().toString());
				UnwindAmount = Double.parseDouble(txtUnwindAmount.getText());
				FlagRate = Double.parseDouble(txtFlagCount.getText());
			}catch (NumberFormatException e){
				WebWidth = 0.;
				UnwindCore = 0.;
				UnwindAmount = 0.;
				FlagRate = 0.;
			}
			
			Double UnwindLength = 0., UnwindWeight = 0., UnwindDiam = 0.;
			
			if(cmbUnwindType.getSelectedIndex() == 0){
				// Length
				UnwindLength = (metric ? UnwindAmount : Core.FtToM(UnwindAmount));
				UnwindWeight = Core.LengthToWeight(UnwindLength, 0.000001*material.thickness, 0.001*WebWidth, 1000*material.density);
				UnwindDiam = 1000*Core.LengthToDiam(UnwindLength, 0.000001*material.thickness, 0.001*UnwindCore);
			}
			else if(cmbUnwindType.getSelectedIndex() == 1){
				// Weight
				UnwindWeight = (metric ? UnwindAmount : Core.TonToKg(UnwindAmount));
				UnwindLength = Core.WeightToLength(UnwindWeight,0.000001*material.thickness, 0.001*WebWidth, 1000*material.density);
				UnwindDiam = 1000*Core.LengthToDiam(UnwindLength, 0.000001*material.thickness, 0.001*UnwindCore);
			}
			else if (cmbUnwindType.getSelectedIndex() == 2){
				// Diameter
				UnwindDiam = (metric ? UnwindAmount : Core.InToMM(UnwindAmount));;
				UnwindLength = Core.DiamToLength(0.001*UnwindDiam, 0.000001*material.thickness, 0.001*UnwindCore);
				UnwindWeight = Core.LengthToWeight(UnwindLength,  0.000001*material.thickness, 0.001*WebWidth, 1000*material.density);
			}
			
			// Update totals
			try{
				TotalAmount = Double.parseDouble(txtTargetTotal.getText());
			}catch(NumberFormatException e){
				TotalAmount = 0.;
			}
			Double TotalLength = 0., TotalWeight = 0.;
			if(cmbTargetTotal.getSelectedIndex() == 0){
				// Length
				TotalLength = (metric ? TotalAmount : Core.FtToM(TotalAmount));
				TotalWeight = Core.LengthToWeight(TotalLength, 0.000001*material.thickness, 0.001*WebWidth, 1000*material.density);
			}
			else if(cmbTargetTotal.getSelectedIndex() == 1){
				// Weight kg
				TotalWeight = (metric ? TotalAmount : Core.TonToKg(TotalAmount));
				TotalLength = Core.WeightToLength(TotalWeight, 0.000001*material.thickness, 0.001*WebWidth, 1000*material.density);
			}
			else if (cmbTargetTotal.getSelectedIndex() == 2){
				// Weight tonnes
				TotalWeight = (metric ? Core.TonneToKg(TotalAmount) : Core.TonToKg(TotalAmount));
				TotalLength = Core.WeightToLength(TotalWeight, 0.000001*material.thickness, 0.001*WebWidth, 1000*material.density);
			}
			
			// Update slits
			try{
				Slits = Integer.parseInt(txtSlits.getText());
				SlitWidth = (metric ? Double.parseDouble(txtSlitWidth.getText()) : Core.InToMM(Double.parseDouble(txtSlitWidth.getText())));
			}catch(NumberFormatException e){
				Slits = 0;
				SlitWidth = 0.;
			}
			
			// Update rewind
			try{
				RewindCore = (metric ? Double.parseDouble((((JTextField) cmbRewindCore.getEditor().getEditorComponent()).getText())) : Core.InToMM(Double.parseDouble((((JTextField) cmbRewindCore.getEditor().getEditorComponent()).getText()))));
				//RewindCore = Double.parseDouble(cmbRewindCore.getSelectedItem().toString());
				RewindAmount = Double.parseDouble(txtRewindAmount.getText());
			}catch(NumberFormatException e){
				RewindCore = 0.;
				RewindAmount = 0.;
			}
			Double RewindLength = 0., RewindWeight = 0., RewindDiam = 0.;
			if(cmbRewindType.getSelectedIndex() == 0){
				// Length
				if(cmbJobDomain.getSelectedItem().toString().equals("Reel"))
					RewindLength = (metric ? RewindAmount : Core.FtToM(RewindAmount));
				else if(cmbJobDomain.getSelectedItem().toString().equals("Set"))
					RewindLength = (metric ? RewindAmount : Core.FtToM(RewindAmount)) / Slits;
				RewindWeight = Core.LengthToWeight(RewindLength, 0.000001*material.thickness, 0.001*WebWidth, 1000*material.density);
				RewindDiam = 1000*Core.LengthToDiam(RewindLength, 0.000001*material.thickness, 0.001*RewindCore);
			}
			else if(cmbRewindType.getSelectedIndex() == 1){
				// Weight
				if(cmbJobDomain.getSelectedItem().toString().equals("Reel"))
					RewindWeight = (metric ? RewindAmount : Core.TonToKg(RewindAmount));
				else if(cmbJobDomain.getSelectedItem().toString().equals("Set"))
					RewindWeight = (metric ? RewindAmount : Core.TonToKg(RewindAmount)) / Slits;
				RewindLength = Core.WeightToLength(RewindWeight, 0.000001*material.thickness, 0.001*WebWidth, 1000*material.density);
				RewindDiam = 1000*Core.LengthToDiam(RewindLength, 0.000001*material.thickness, 0.001*RewindCore);
			}
			else if(cmbRewindType.getSelectedIndex() == 2){
				// Diameter
				RewindDiam = (metric ? RewindAmount : Core.InToMM(RewindAmount));
				RewindLength = Core.DiamToLength(0.001*RewindDiam, 0.000001*material.thickness, 0.001*RewindCore);
				RewindWeight = Core.LengthToWeight(RewindLength, 0.000001*material.thickness, 0.001*WebWidth, 1000*material.density);
			}
			
			// Update speed limiting
			boolean limit_speed = chckbxLimitRunSpeed.isSelected();
			try{
				speed_limit = (metric ? Double.parseDouble(txtLimitRunSpeed.getText()) : Core.FtToM(Double.parseDouble(txtLimitRunSpeed.getText())));
			}catch(NumberFormatException e){
				speed_limit = 0.;
				limit_speed = false;
			}
			
			j.update(
					material, 
					WebWidth, 
					UnwindCore, 
					UnwindLength, 
					UnwindWeight, 
					UnwindDiam, 
					FlagRate,
					Slits, 
					SlitWidth, 
					RewindCore, 
					RewindLength, 
					RewindWeight, 
					RewindDiam, 
					TotalLength, 
					TotalWeight, 
					limit_speed, 
					speed_limit,
					cmbUnwindType.getSelectedIndex(),
					cmbRewindType.getSelectedIndex(),
					cmbTargetTotal.getSelectedIndex()
					);
			
			UpdateTrim();
			
			jobFormReady = true;
		}
	}
	
    MouseListener mouseListener = new MouseAdapter() 
    {
    	@Override
        public void mouseClicked(MouseEvent e) 
        {
        	if(e.getClickCount() == 1){
                int position = listCompare.locationToIndex(e.getPoint());
                if(listCompare.isSelectedIndex(position))
                	listCompare.removeSelectionInterval(position, position);
                else
                	listCompare.addSelectionInterval(position, position);
        	}
        }
    	
    	@Override
    	public void mousePressed(MouseEvent e){ }
    	@Override
    	public void mouseReleased(MouseEvent e){ }
    };
    
    public String getUniqueName(String s){
    	String str = s;
    	int i = 1;
    	while(machNames.contains(str.toLowerCase())){
    		str = s + " (" + Integer.toString(i++) + ")";
    	}
    	return str;
    }
    
    public String getUniqueJobName(String s){
    	String str = s;
    	int i = 1;
    	while(jobNames.contains(str.toLowerCase())){
    		str = s + " (" + Integer.toString(i++) + ")";
    	}
    	return str;
    }
 
    private void UpdateMachineName(){
	    if(formReady){
	    	String input = txtMachName.getText();
	    	ResetStatusLabel();
			if(input.equals("")){
				ShowMessage("Please enter a machine name.");
		    	return;
			}
			
			if(machNames.contains(input.toLowerCase()) && (!(machine.name.equals(input)))){
		    	ShowMessage("Duplicate machine names not allowed. Please choose a different name.");
		    	return;
		    }
		    machNames.remove(machine.name.toLowerCase());
		    machNames.add(input.toLowerCase());
		    
		    machine.name = input;
			listMachines.repaint();
		}
	}
    
    private void UpdateForm(){
    	ResetForm();
    	if (listMachines.getSelectedIndex() == -1) {
    		
    		
    	}else{
			
			Machine selected = (Machine) listMachines.getSelectedValue();
			txtMachName.setText(selected.name);
			switch(selected.model){
				case ER610: rdbtnClick("ER800"); break;
				case SR9DS: rdbtnClick("SR9DS"); break;
				case SR9DT: rdbtnClick("SR9DT"); break;
				case SR800: rdbtnClick("SR800"); break;
				case OTHER: rdbtnClick("Custom"); break;
			}
			if(!(model == Machine.Model.OTHER)){
				if(cmbSpeed.isEnabled())
					cmbSpeed.setSelectedItem(Integer.toString((int)Math.round(selected.speed.orig_speed)));
				if(cmbCorepos.isEnabled())
					cmbCorepos.setSelectedItem(WordUtils.capitalizeFully(selected.corepos.toString()));
				if(cmbKnives.isEnabled())
					cmbKnives.setSelectedItem(selected.knives.toString());
				if(cmbUnloader.isEnabled())
					cmbUnloader.setSelectedItem(WordUtils.capitalizeFully(selected.unloader.toString()));
				if(cmbUnwindDrive.isEnabled())
					cmbUnwindDrive.setSelectedItem(WordUtils.capitalizeFully(selected.unwind.toString()));
				if(cmbRewindCtrl.isEnabled())
					cmbRewindCtrl.setSelectedItem(WordUtils.capitalizeFully(selected.rewind.toString()));
				chckbxAlignmentGuide.setSelected(selected.alignment);
				chckbxAutoCutoff.setSelected(selected.cutoff);
				chckbxAutostripping.setSelected(selected.autostrip);
				chckbxAutoTapeCore.setSelected(selected.tapecore);
				chckbxAutoTapeTail.setSelected(selected.tapetail);
				chckbxExtraRewind.setSelected(selected.extrarewind);
				chckbxFlag.setSelected(selected.flags);
				chckbxRollConditioning.setSelected(selected.roll_cond);
				chckbxSpliceTable.setSelected(selected.splice_table);
				chckbxTurretSupport.setSelected(selected.turret);
			}
    	}
    }
    
    private JButton btnSaveToFile;
    private JPanel pnlPreview;
    private JLabel lblPreview;
    private JLabel lblAverageMmin;
    private JPanel pnlROI;
    private JPanel pnlCompare;
    private JPanel pnlEnviron;
    private JPanel pnlJob;
    private JPanel pnlMachine;
    private JButton btnAll;
    private JButton btnNone;
    private JLabel lblSelect;
    private JLabel lblNumericsWeight;
    private JLabel lblNumericsLength;
    private JLabel lblNumericsRate;
    private JLabel lblType;
    public JComboBox cmbGraphType;
    private JTabbedPane tabbedPane;
    
    JLabel[] labs;
    private JButton btnShowGraph;
    public JButton btnShowTimings;
    public JList listJobsAvail;
    public JList listSchedule;
    public JButton btnAddAll;
    public JTextField txtLimitRunSpeed;
    public JButton btnViewSchedule;
    public JButton btnAddJob;
    public JButton btnRemoveJob;
    public JList listJobs;
    public JComboBox cmbRewindType;
    public JCheckBox chckbxLimitRunSpeed;
    public JLabel lblLimitRunSpeed;
    public JComboBox cmbUnwindType;
    public JButton btnJobUp;
    public JButton btnJobDown;
    public JButton btnNewJob;
    public JButton btnNewMachine;
    public JRadioButton rdbtnSR800;
    public JRadioButton rdbtnCustom;
    public JLabel lblMachineConfiguration;
    public JLabel lblAddNewMachines;
    public JLabel lblJobConfiguration;
    public JButton btnJobDelete;
    public JLabel lblAddNewJobs;
    public JButton btnResetJobs;
    public JTextField txtJobName;
    public JLabel lblJobName;
    public JLabel lblJobSchedule_1;
    public JLabel lblScheduleJobsTo;
    public JLabel lblJobs;
    public JLabel lblAvailableJobs_1;
    public JLabel lblJobSchedule_2;
    public JPanel panel;
    private JLabel lblSlitWidth;
    private JLabel lblUnwindLength;
    private JLabel lblTargetRewindLength;
    public JButton btnUpSchedule;
    public JButton btnDownSchedule;
    public JButton btnClearSchedule;
    public JPanel panel_1;
    public JLabel lblTargetOutputFor;
    public JTextField txtTargetTotal;
    public JComboBox cmbTargetTotal;
    public JPanel panel_2;
    public JLabel lblProductivityComparison;
    public JLabel lblSelectMultipleMachines;
    public JLabel label_2;
    public JScrollPane scrlSchedule;
    public JPanel panel_3;
    public JLabel lblReturnOnInvestment;
    public JLabel lblSelectMultipleMachines_1;
    public JLabel lblCompareroiList;
    public JList listCompareRoi;
    public JPanel panel_4;
    public JButton btnROIselectnone;
    public JButton btnROIselectall;
    public JLabel lblROIselect;
    public JTextField txtWebWidth;
    public JMenuItem mntmUnitConverter;
    public JButton btnOptions;
    public JLabel lblEfficiency;
    public JComboBox cmbMachines;
    public JLabel lblMachine;
    public JLabel lblAverageFlags;
    public JTextField txtFlagCount;
    public JLabel lblPerRoll;
    public JLabel lblNumericsEff;
    private JMenuItem mntmOpen;
    private JMenuItem mntmSave;
    public JTabbedPane tabsROI;
    public JPanel pnlProdROI;
    public JPanel pnlEnergy;
    public JPanel pnlWaste;
    public JPanel pnlQuality;
    public JLabel lblThisToolIlllustrates;
    public JLabel lblInTermsOf;
    public JLabel lblThisToolHighlights;
    public JLabel lblImpactOnFinancial;
    public JLabel lblThisToolDemonstrates;
    public JLabel lblThisToolCompares;
    public JButton btnRefreshAnalysis;
    public JPanel pnlMaint;
    public JLabel lblThisToolDemonstrates_1;


    
    public void ResetStatusLabel(){
    	lblStatus.setText(" Ready.");
    	lblStatus.setFont(new Font("Tahoma", Font.PLAIN, 12));
    	lblStatus.setForeground(Color.BLACK);
    }
    
    public enum Model{
    	ER610("ER610"), SR9DS("SR9-DS"), SR9DT("SR9-DT"), OTHER("Other");
    	String m;
    	Model(String m){
    		this.m = m;
    	}
    }
    public enum Speed{
    	A(450), B(550), C(1000);
    	int s;
    	Speed(int j){
    		s = j;
    	}
    }
    public enum Knives{
    	Auto("Auto"),  Stacked("Manual (Stacked)"), Inflatable("Manual (Inflatable)");
    	String k;
    	Knives(String l){
    		k = l;
    	}
    }
    public enum CoreposER{
    	Manual, Laser
    }
    public enum CoreposSR{
    	Manual, Laser, Servo
    }
    public enum Unloader{
    	Manual, Pneumatic, Electric
    }
    public enum Unwind{
    	Single, Double
    }
    public enum Rewind{
    	Open, Closed
    }
}