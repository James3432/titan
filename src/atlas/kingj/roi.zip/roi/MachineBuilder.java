package atlas.kingj.roi;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.text.DecimalFormat;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.TitledBorder;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

public class MachineBuilder extends JDialog {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JButton btnApply;
	private JButton btnCancel;
	private JLabel lblUseThisForm;
	private JTextField txtaccel;
	private JTextField txtspeed;
	private JTextField txtmother;
	private JLabel lblA;
	private JLabel lblC;
	private JLabel lblD;
	
	Machine machine;
	private JLabel lblNewLabel;
	private JLabel lblMs;
	private JPanel grpOptions;
	public JTextField txtdiam;
	public JLabel label_1;
	public JCheckBox chckbxShaftlessUnwind;
	public JCheckBox chckbxDualTurretRewind;
	public JCheckBox chckbxDifferentialRewind;
	public JCheckBox chckbxLockCoreRewind;
	public JCheckBox chckbxQuickLockRewind;
	public JCheckBox chckbxSettingsRecall;
	public JLabel lblMotherChange;
	public JLabel lblTotalJobChange;
	public JCheckBox chckbxFlagDetect;
	public JLabel lblSpliceTime;
	public JCheckBox chckbxAutoTape;
	public JCheckBox chckbxAutoCut;
	public JCheckBox chckbxAutoRewindLoad;
	public JCheckBox chckbxAutoRewindUnload;
	public JLabel lblRewindAlignTime;
	public JLabel lblChangeRewindDiam;
	public JTextField txtjob;
	public JLabel label;
	public JLabel label_2;
	public JLabel label_3;
	public JTextField txtsplice;
	public JTextField txtalign;
	public JPanel panel;
	public JPanel panel_1;
	public JCheckBox chckbxAutoTapeCores;
	public JButton btnReset;

	/**
	 * Create the dialog.
	 */
	public MachineBuilder(Machine machine) {
		getContentPane().setBackground(Color.WHITE);
		setResizable(false);
		this.machine = machine;
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setTitle("Custom Machine Builder");
		try{
		setIconImage(ImageIO.read(FrmMain.class.getResourceAsStream("/atlas/logo.png")));
		}catch(NullPointerException e){
			System.out.println("Image load error");
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		setBounds(100, 100, 427, 446);
		setLocationRelativeTo(null);
		setModal(true);
		getContentPane().setLayout(null);
		
		lblUseThisForm = new JLabel("Use this form to add details about an existing machine not modelled by this tool.");
		lblUseThisForm.setForeground(Color.DARK_GRAY);
		lblUseThisForm.setBounds(13, 11, 401, 14);
		getContentPane().add(lblUseThisForm);
		
		grpOptions = new JPanel();
		grpOptions.setBounds(13, 97, 398, 127);
		getContentPane().add(grpOptions);
		grpOptions.setBackground(Color.WHITE);
		grpOptions.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Machine Timings", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		grpOptions.setLayout(null);
		
		txtaccel = new JTextField();
		txtaccel.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				txtaccel.selectAll();
			}
		});
		txtaccel.setToolTipText("The time taken for the machine to accelerate to its given top speed");
		txtaccel.setText("50");
		txtaccel.setBounds(123, 28, 46, 20);
		grpOptions.add(txtaccel);
		txtaccel.setColumns(10);
		
		txtmother = new JTextField();
		txtmother.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				txtmother.selectAll();
			}
		});
		txtmother.setToolTipText("The total time taken to change a mother reel");
		txtmother.setText("300");
		txtmother.setBounds(123, 59, 46, 20);
		grpOptions.add(txtmother);
		txtmother.setColumns(10);
		
		lblC = new JLabel("Reach top speed:");
		lblC.setToolTipText("The time taken for the machine to accelerate to its given top speed");
		lblC.setBounds(15, 31, 107, 14);
		grpOptions.add(lblC);
		
		lblD = new JLabel("s");
		lblD.setBounds(174, 61, 11, 14);
		grpOptions.add(lblD);
		
		lblNewLabel = new JLabel("s");
		lblNewLabel.setBounds(174, 30, 11, 14);
		grpOptions.add(lblNewLabel);
		
		txtdiam = new JTextField();
		txtdiam.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				txtdiam.selectAll();
			}
		});
		txtdiam.setToolTipText("The time taken to adjust core diameters on the rewind shafts");
		txtdiam.setText("300");
		txtdiam.setColumns(10);
		txtdiam.setBounds(123, 90, 46, 20);
		grpOptions.add(txtdiam);
		
		label_1 = new JLabel("s");
		label_1.setBounds(174, 92, 11, 14);
		grpOptions.add(label_1);
		
		lblMotherChange = new JLabel("Change mother:");
		lblMotherChange.setToolTipText("The total time taken to change a mother reel");
		lblMotherChange.setBounds(15, 62, 86, 14);
		grpOptions.add(lblMotherChange);
		
		lblTotalJobChange = new JLabel("Change job:");
		lblTotalJobChange.setToolTipText("The total time taken to change between jobs (including unwind & rewind changes)");
		lblTotalJobChange.setBounds(208, 31, 69, 14);
		grpOptions.add(lblTotalJobChange);
		
		lblSpliceTime = new JLabel("Detect flag & splice:");
		lblSpliceTime.setToolTipText("Total time taken to detect a flag, stop the machine and perform a splice");
		lblSpliceTime.setBounds(208, 62, 98, 14);
		grpOptions.add(lblSpliceTime);
		
		lblRewindAlignTime = new JLabel("Align rewind reels:");
		lblRewindAlignTime.setToolTipText("Time taken to align reels on the rewind shaft before starting a run");
		lblRewindAlignTime.setBounds(208, 93, 98, 14);
		grpOptions.add(lblRewindAlignTime);
		
		lblChangeRewindDiam = new JLabel("Change rewind diam:");
		lblChangeRewindDiam.setToolTipText("The time taken to adjust core diameters on the rewind shafts");
		lblChangeRewindDiam.setBounds(15, 93, 119, 14);
		grpOptions.add(lblChangeRewindDiam);
		
		txtjob = new JTextField();
		txtjob.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				txtjob.selectAll();
			}
		});
		txtjob.setToolTipText("The total time taken to change between jobs (including unwind & rewind changes)");
		txtjob.setText("600");
		txtjob.setColumns(10);
		txtjob.setBounds(318, 28, 46, 20);
		grpOptions.add(txtjob);
		
		label = new JLabel("s");
		label.setBounds(368, 31, 11, 14);
		grpOptions.add(label);
		
		label_2 = new JLabel("s");
		label_2.setBounds(368, 62, 11, 14);
		grpOptions.add(label_2);
		
		label_3 = new JLabel("s");
		label_3.setBounds(368, 93, 11, 14);
		grpOptions.add(label_3);
		
		txtsplice = new JTextField();
		txtsplice.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				txtsplice.selectAll();
			}
		});
		txtsplice.setToolTipText("Total time taken to detect a flag, stop the machine and perform a splice");
		txtsplice.setText("300");
		txtsplice.setColumns(10);
		txtsplice.setBounds(318, 59, 46, 20);
		grpOptions.add(txtsplice);
		
		txtalign = new JTextField();
		txtalign.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				txtalign.selectAll();
			}
		});
		txtalign.setToolTipText("Time taken to align reels on the rewind shaft before starting a run");
		txtalign.setText("50");
		txtalign.setColumns(10);
		txtalign.setBounds(318, 90, 46, 20);
		grpOptions.add(txtalign);
		
		btnCancel = new JButton("Cancel");
		btnCancel.setToolTipText("Cancel and close");
		btnCancel.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnCancel.setBounds(322, 386, 89, 23);
		getContentPane().add(btnCancel);
		
		btnApply = new JButton("OK");
		btnApply.setToolTipText("Save and close");
		btnApply.setBounds(223, 386, 89, 23);
		getContentPane().add(btnApply);
		btnApply.addActionListener(new AddButtonListener());
		
		
		
		btnApply.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnApply.setForeground(Color.BLACK);
		
		panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Machine Options", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.setBackground(Color.WHITE);
		panel.setBounds(13, 235, 398, 144);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		chckbxShaftlessUnwind = new JCheckBox("Shaftless unwind");
		chckbxShaftlessUnwind.setToolTipText("Whether a shaftless unwind is used");
		chckbxShaftlessUnwind.setBounds(263, 100, 131, 23);
		panel.add(chckbxShaftlessUnwind);
		chckbxShaftlessUnwind.setBackground(Color.WHITE);
		
		chckbxDualTurretRewind = new JCheckBox("Dual turret rewind");
		chckbxDualTurretRewind.setToolTipText("Whether a dual turret system is present");
		chckbxDualTurretRewind.setBounds(132, 22, 131, 23);
		panel.add(chckbxDualTurretRewind);
		chckbxDualTurretRewind.setBackground(Color.WHITE);
		
		chckbxDifferentialRewind = new JCheckBox("Differential rewind");
		chckbxDifferentialRewind.setToolTipText("Differential rewind supported");
		chckbxDifferentialRewind.setBounds(263, 22, 131, 23);
		panel.add(chckbxDifferentialRewind);
		chckbxDifferentialRewind.setBackground(Color.WHITE);
		
		chckbxLockCoreRewind = new JCheckBox("Lock core rewind");
		chckbxLockCoreRewind.setToolTipText("Lock core type rewind");
		chckbxLockCoreRewind.setBounds(263, 48, 117, 23);
		panel.add(chckbxLockCoreRewind);
		chckbxLockCoreRewind.setBackground(Color.WHITE);
		
		chckbxQuickLockRewind = new JCheckBox("Quick lock rewind");
		chckbxQuickLockRewind.setToolTipText("Quick lock type rewind");
		chckbxQuickLockRewind.setBounds(263, 74, 117, 23);
		panel.add(chckbxQuickLockRewind);
		chckbxQuickLockRewind.setBackground(Color.WHITE);
		
		chckbxSettingsRecall = new JCheckBox("Settings recall");
		chckbxSettingsRecall.setToolTipText("Whether the machine can save and restore settings to speed up job changes");
		chckbxSettingsRecall.setBounds(16, 22, 97, 23);
		panel.add(chckbxSettingsRecall);
		chckbxSettingsRecall.setBackground(Color.WHITE);
		
		chckbxFlagDetect = new JCheckBox("Flag detect");
		chckbxFlagDetect.setToolTipText("Whether automatic flag detection is supported");
		chckbxFlagDetect.setBounds(16, 48, 97, 23);
		panel.add(chckbxFlagDetect);
		chckbxFlagDetect.setBackground(Color.WHITE);
		
		chckbxAutoTape = new JCheckBox("Auto tape tails");
		chckbxAutoTape.setToolTipText("Whether rewind reels are automatically taped when complete");
		chckbxAutoTape.setBounds(16, 74, 97, 23);
		panel.add(chckbxAutoTape);
		chckbxAutoTape.setBackground(Color.WHITE);
		
		chckbxAutoCut = new JCheckBox("Auto cut");
		chckbxAutoCut.setToolTipText("Whether the web is automatically cut after a run");
		chckbxAutoCut.setBounds(132, 48, 97, 23);
		panel.add(chckbxAutoCut);
		chckbxAutoCut.setBackground(Color.WHITE);
		
		chckbxAutoRewindLoad = new JCheckBox("Auto rewind load");
		chckbxAutoRewindLoad.setToolTipText("Automatic rewind reel loading system present");
		chckbxAutoRewindLoad.setBounds(132, 74, 119, 23);
		panel.add(chckbxAutoRewindLoad);
		chckbxAutoRewindLoad.setBackground(Color.WHITE);
		
		chckbxAutoRewindUnload = new JCheckBox("Auto rewind unload");
		chckbxAutoRewindUnload.setToolTipText("Automatic rewind reel unloading system present");
		chckbxAutoRewindUnload.setBounds(132, 100, 119, 23);
		panel.add(chckbxAutoRewindUnload);
		chckbxAutoRewindUnload.setBackground(Color.WHITE);
		
		panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(null, "Machine Speed", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(13, 36, 398, 50);
		getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		lblA = new JLabel("Top speed:");
		lblA.setToolTipText("Top speed of machine");
		lblA.setBounds(91, 19, 59, 14);
		panel_1.add(lblA);
		
		txtspeed = new JTextField();
		txtspeed.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent arg0) {
				txtspeed.selectAll();
			}
		});
		txtspeed.setToolTipText("Top speed of machine");
		txtspeed.setBounds(155, 16, 86, 20);
		panel_1.add(txtspeed);
		txtspeed.setText("500");
		txtspeed.setColumns(10);
		
		lblMs = new JLabel("m/min");
		lblMs.setBounds(245, 19, 46, 14);
		panel_1.add(lblMs);
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		
		chckbxAutoTapeCores = new JCheckBox("Auto tape cores");
		chckbxAutoTapeCores.setToolTipText("Whether rewind reel cores are automatically taped");
		chckbxAutoTapeCores.setBackground(Color.WHITE);
		chckbxAutoTapeCores.setBounds(16, 100, 114, 23);
		panel.add(chckbxAutoTapeCores);
		
		try{
			txtspeed.setText(Double.toString(roundTwoDecimals(machine.getCustomMachine().speed * 60)));
			txtaccel.setText(Double.toString(roundTwoDecimals(machine.getCustomMachine().speed / machine.getCustomMachine().accel)));
	        txtalign.setText(Double.toString(roundTwoDecimals(machine.getCustomMachine().align_rewind)));
	        txtdiam.setText(Double.toString(roundTwoDecimals(machine.getCustomMachine().change_diam)));
	        txtjob.setText(Double.toString(roundTwoDecimals(machine.getCustomMachine().change_job)));
	        txtmother.setText(Double.toString(roundTwoDecimals(machine.getCustomMachine().change_mother)));
	        txtsplice.setText(Double.toString(roundTwoDecimals(machine.getCustomMachine().splice)));
	        // options: SettingRecall FlagDetect AutoTape AutoTapeCore DualTurret AutoCut  AutoLoad AutoUnload  DiffRewind LockCore QuickLock SlessUnwind 
	        chckbxSettingsRecall.setSelected(machine.getCustomMachine().options[0]);
	        chckbxFlagDetect.setSelected(machine.getCustomMachine().options[1]);
	        chckbxAutoTape.setSelected(machine.getCustomMachine().options[2]);
			chckbxAutoTapeCores.setSelected(machine.getCustomMachine().options[3]);
			chckbxDualTurretRewind.setSelected(machine.getCustomMachine().options[4]);
			chckbxAutoCut.setSelected(machine.getCustomMachine().options[5]);
			chckbxAutoRewindLoad.setSelected(machine.getCustomMachine().options[6]);
			chckbxAutoRewindUnload.setSelected(machine.getCustomMachine().options[7]);
			chckbxDifferentialRewind.setSelected(machine.getCustomMachine().options[8]);
			chckbxLockCoreRewind.setSelected(machine.getCustomMachine().options[9]);
			chckbxQuickLockRewind.setSelected(machine.getCustomMachine().options[10]);
			chckbxShaftlessUnwind.setSelected(machine.getCustomMachine().options[11]);
			
			btnReset = new JButton("Reset");
			btnReset.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					ResetForm();
				}
			});
			btnReset.setToolTipText("Reset the form");
			btnReset.setFont(new Font("Tahoma", Font.PLAIN, 12));
			btnReset.setBounds(13, 387, 89, 23);
			getContentPane().add(btnReset);
		}catch(NumberFormatException e){
			ResetForm();
		}

	}
	
	private void ResetForm(){
		txtspeed.setText("500.0");
		txtaccel.setText("50.0");
        txtalign.setText("50.0");
        txtdiam.setText("300.0");
        txtjob.setText("300.0");
        txtmother.setText("300.0");
        txtsplice.setText("300.0");
        chckbxAutoCut.setSelected(false);
        chckbxAutoRewindLoad.setSelected(false);
        chckbxAutoRewindUnload.setSelected(false);
        chckbxAutoTape.setSelected(false);
        chckbxAutoTapeCores.setSelected(false);
        chckbxDifferentialRewind.setSelected(false);
        chckbxDualTurretRewind.setSelected(false);
        chckbxFlagDetect.setSelected(false);
        chckbxLockCoreRewind.setSelected(false);
        chckbxQuickLockRewind.setSelected(false);
        chckbxSettingsRecall.setSelected(false);
        chckbxShaftlessUnwind.setSelected(false);
	}
	
	class AddButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			
			machine.getCustomMachine().speed = Double.parseDouble(txtspeed.getText()) / 60.;
			machine.getCustomMachine().accel = machine.getCustomMachine().speed / Double.parseDouble(txtaccel.getText());
            machine.getCustomMachine().align_rewind = Double.parseDouble(txtalign.getText());
            machine.getCustomMachine().change_diam = Double.parseDouble(txtdiam.getText());
            machine.getCustomMachine().change_job = Double.parseDouble(txtjob.getText());
            machine.getCustomMachine().change_mother = Double.parseDouble(txtmother.getText());
            machine.getCustomMachine().splice = Double.parseDouble(txtsplice.getText());
            // options: SettingRecall FlagDetect AutoTape AutoTapeCore DualTurret AutoCut  AutoLoad AutoUnload  DiffRewind LockCore QuickLock SlessUnwind 
            machine.getCustomMachine().options = new boolean[]{ chckbxSettingsRecall.isSelected(),     chckbxFlagDetect.isSelected(),     chckbxAutoTape.isSelected(),        chckbxAutoTapeCores.isSelected(), 
            													chckbxDualTurretRewind.isSelected(),   chckbxAutoCut.isSelected(),        chckbxAutoRewindLoad.isSelected(),  chckbxAutoRewindUnload.isSelected(), 
            													chckbxDifferentialRewind.isSelected(), chckbxLockCoreRewind.isSelected(), chckbxQuickLockRewind.isSelected(), chckbxShaftlessUnwind.isSelected()
            												  };
			
			dispose();
		}
	}
	
	double roundTwoDecimals(double d) {
        DecimalFormat twoDForm = new DecimalFormat("#.##");
	    return Double.valueOf(twoDForm.format(d));
	}
}
